<!-- 
 Página declaración de accesibilidad
-->
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>

    
       <main>
       <?php include 'search.php'; ?>
            <div class="titulospaginas3">
            <h2>Declaración de Accesibilidad</h2>
            <p>
                En nuestro sitio web, nos comprometemos a garantizar que el contenido sea accesible para todas las personas, independientemente de sus capacidades. Esta declaración de accesibilidad describe las medidas que hemos implementado para hacer nuestro sitio web más inclusivo.
            </p></div>
    
            <section class="declaracion">
        
                <h3>1. Etiquetado semántico</h3>
                <p>
                    Hemos utilizado un marcado semántico correcto, utilizando las etiquetas HTML5 apropiadas para cada sección de la página (<code>&lt;header&gt;</code>, <code>&lt;main&gt;</code>, <code>&lt;footer&gt;</code>, etc.), con el objetivo de mejorar la navegabilidad y la interpretación del contenido por los lectores de pantalla.
                </p>
        
                <h3>2. Texto alternativo en imágenes</h3>
                <p>
                    Todas las imágenes del sitio web incluyen atributos <code>alt</code> descriptivos para que las personas con discapacidad visual puedan comprender el contenido visual mediante herramientas de lectura de pantalla.
                </p>
        
                <h3>3. Contraste de colores y diseño</h3>
                <p>
                    Los colores utilizados han sido seleccionados para cumplir con las directrices de accesibilidad, asegurando un contraste adecuado entre el fondo y el texto, facilitando la lectura para personas con baja visión o con daltonismo.
                </p>
                <p>
                    También hemos incluido un estilo de "alto contraste" que se puede activar desde el menú de accesibilidad del sitio. Este estilo proporciona una mayor legibilidad mediante la combinación de colores oscuros y claros con alto contraste.
                </p>
        
                <h3>4. Tamaño de fuente y accesibilidad</h3>
                <p>
                    Los usuarios pueden ajustar el tamaño de la fuente a través del estilo accesible de "texto grande", que facilita la lectura a las personas con baja visión. Para activarlo, se puede acceder al menú de accesibilidad en la parte superior de la página.
                </p>
        
                <h3>5. Modo Noche</h3>
                <p>
                    Para reducir la fatiga visual en entornos con poca luz, el sitio incluye un "modo noche", que invierte los colores del sitio, proporcionando un fondo oscuro y un texto claro.
                </p>
        
                <h3>6. Hoja de estilo para impresión</h3>
                <p>
                    Hemos implementado una hoja de estilo especial para la impresión, asegurando que las páginas importantes del sitio se impriman de manera correcta, optimizando la disposición del contenido y eliminando elementos que no son necesarios en una versión impresa, como los menús de navegación.
                </p>
        
                <h3>7. Cómo activar las hojas de estilo accesibles</h3>
                <p>
                    Los estilos accesibles, como el modo noche, alto contraste y el aumento del tamaño de fuente, se pueden activar desde el menú de accesibilidad en la parte superior del sitio. Simplemente selecciona la opción que mejor se adapte a tus necesidades.
                </p>
        
                <h3>8. Enlaces y navegación</h3>
                <p>
                    Los enlaces han sido diseñados para ser fácilmente visibles y tienen suficiente área de clic para facilitar su interacción. Además, el sitio es completamente navegable mediante el teclado, lo que mejora la accesibilidad para personas con discapacidades motoras.
                </p>
            </section>

    </main>
    <?php include 'panel_anuncios.php'; ?>
    <?php include 'footer.php'; ?>