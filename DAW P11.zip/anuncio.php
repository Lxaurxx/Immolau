<!-- 
 Página detalle de un anuncio
-->
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?>
<?php include 'db.php'; ?>
<body>
<?php include 'search.php'; ?>
<div class="anuncio">
    <h1 class="titulospaginas3"> Detalle del Anuncio</h1>

    <?php
// Captura el parámetro 'id' de la URL
$idAnuncio = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Usa 0 como valor predeterminado

// Consulta principal para obtener la información del anuncio
$queryAnuncio = "
    SELECT a.Titulo, a.Precio, a.Texto, a.Ciudad, p.NomPais AS Pais, a.Superficie, 
           a.Nhabitaciones, a.Nbanyos, a.Planta, a.Anyo, a.FRegistro, 
           t.NomTAnuncio AS TipoAnuncio, v.NomTVivienda AS TipoVivienda, 
           u.NomUsuario AS Usuario, u.IdUsuario AS UsuarioId 
    FROM Anuncios a
    LEFT JOIN Paises p ON a.Pais = p.IdPais
    LEFT JOIN TiposAnuncios t ON a.TAnuncio = t.IdTAnuncio
    LEFT JOIN TiposViviendas v ON a.TVivienda = v.IdTVivienda
    LEFT JOIN Usuarios u ON a.Usuario = u.IdUsuario
    WHERE a.IdAnuncio = ?";
$stmt = $conn->prepare($queryAnuncio);
$stmt->bind_param("i", $idAnuncio);
$stmt->execute();
$resultAnuncio = $stmt->get_result();

if ($resultAnuncio->num_rows > 0) {
    $anuncio = $resultAnuncio->fetch_assoc();

    // Consulta para obtener las fotos del anuncio
    $queryFotos = "SELECT Fichero, Alternativo FROM Fotos WHERE Anuncio = ? ORDER BY IdFoto ASC";
    $stmtFotos = $conn->prepare($queryFotos);
    $stmtFotos->bind_param("i", $idAnuncio);
    $stmtFotos->execute();
    $resultFotos = $stmtFotos->get_result();

    $fotos = [];
    while ($foto = $resultFotos->fetch_assoc()) {
        $fotos[] = $foto;
    }

    // Determina la foto principal (primera de la lista)
    $fotoPrincipal = count($fotos) > 0 ? $fotos[0] : null;

    // Muestra detalles del anuncio
    echo "<h2>Tipo de Anuncio: {$anuncio['TipoAnuncio']}</h2>";
    echo "<h3>Tipo de Vivienda: {$anuncio['TipoVivienda']}</h3>";

    // Muestra la foto principal si existe
    if ($fotoPrincipal) {
        echo "<div><img src='{$fotoPrincipal['Fichero']}' alt='{$fotoPrincipal['Alternativo']}' width='600'></div>";
    }

    echo "<h2>{$anuncio['Titulo']}</h2>";
    echo "<p>{$anuncio['Texto']}</p>";
    echo "<p><strong>Fecha:</strong> {$anuncio['FRegistro']}</p>";
    echo "<p><strong>Ciudad:</strong> {$anuncio['Ciudad']}</p>";
    echo "<p><strong>País:</strong> {$anuncio['Pais']}</p>";
    echo "<p><strong>Precio:</strong> {$anuncio['Precio']} €</p>";
    echo "<h3>Características:</h3>";
    echo "<ul>";
    echo "<li>Superficie: {$anuncio['Superficie']} m²</li>";
    echo "<li>Habitaciones: {$anuncio['Nhabitaciones']}</li>";
    echo "<li>Baños: {$anuncio['Nbanyos']}</li>";
    echo "<li>Planta: {$anuncio['Planta']}</li>";
    echo "<li>Año: {$anuncio['Anyo']}</li>";
    echo "</ul>";

    // Muestra las miniaturas de las fotos
    echo "<h3><a href='ver-fotos.php?id={$idAnuncio}'>Galería de Fotos</a></h3>";
    echo "<div>";
    foreach ($fotos as $foto) {
        echo "<img src='{$foto['Fichero']}' alt='{$foto['Alternativo']}' width='150'>";
    }
    echo "</div>";

    echo "<p><strong>Publicado por:</strong> <a href='ver-perfil.php?usuario={$anuncio['Usuario']}'>{$anuncio['Usuario']}</a></p>";

    echo "<a href='mensaje.php?id={$idAnuncio}&usuarioDestino={$anuncio['UsuarioId']}'>Enviar mensaje al propietario</a>";



    // Configuración de la cookie de "Últimos anuncios visitados"
    $historialVisitas = isset($_COOKIE['ultimos_anuncios']) ? json_decode($_COOKIE['ultimos_anuncios'], true) : [];
    $nuevoAnuncio = [
        "id" => $idAnuncio,
        "titulo" => $anuncio['Titulo'],
        "ciudad" => $anuncio['Ciudad'],
        "pais" => $anuncio['Pais'],
        "precio" => $anuncio['Precio'],
        "img" => $fotoPrincipal ? $fotoPrincipal['Fichero'] : 'default.jpg' // Usa la foto principal
    ];

    // Verifica si el anuncio ya está en el historial y lo elimina si existe
    foreach ($historialVisitas as $key => $item) {
        if ($item['id'] == $idAnuncio) {
            unset($historialVisitas[$key]);
        }
    }

    // Añade el anuncio al inicio del historial
    array_unshift($historialVisitas, $nuevoAnuncio);

    // Mantiene solo los últimos 4 anuncios
    if (count($historialVisitas) > 4) {
        $historialVisitas = array_slice($historialVisitas, 0, 4);
    }

    // Guarda el historial de visitas en una cookie durante 1 semana
    setcookie('ultimos_anuncios', json_encode($historialVisitas), time() + (7 * 24 * 60 * 60), "/");

} else {
    echo "<p>Anuncio no encontrado.</p>";
}

// Cierra las conexiones
$stmt->close();
$conn->close();
?>

</div>

<?php include 'panel_anuncios.php'; ?>
<?php include 'footer.php'; ?>





