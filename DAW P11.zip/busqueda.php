<!-- 
 Página formulario de búsqueda
-->
<?php include 'consulta1.php'; ?>

<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>

<body>
<?php include 'search.php'; ?>


<h2 class="titulospaginas3">Búsqueda de Anuncios 🔎</h2>
    
    <!-- Formulario de búsqueda -->
    <form action="resultadobusqueda.php" method="get" enctype="multipart/form-data" class="formulario-centrado">
        
         <!-- Tipo de anuncio (venta o alquiler) -->
         <label for="tipo-anuncio">Tipo de anuncio:</label><br>
        <select id="tipo-anuncio" name="tipo-anuncio">
            <option value="">Seleccione</option>
            <?php
            // Utilizar la función definida en comun.php para obtener los tipos de anuncios
            $resultTipoAnuncio = obtenerTiposAnuncios();

            if ($resultTipoAnuncio->num_rows > 0) {
                while ($row = $resultTipoAnuncio->fetch_assoc()) {
                    echo '<option value="' . htmlspecialchars($row['IdTAnuncio']) . '">' . htmlspecialchars($row['NomTAnuncio']) . '</option>';
                }
            } else {
                echo '<option value="">No hay tipos de anuncio disponibles</option>';
            }
            ?>
        </select><br><br>

        <!-- Tipo de vivienda -->
        <label for="tipo-vivienda">Tipo de vivienda:</label><br>
        <select id="tipo-vivienda" name="tipo-vivienda">
            <option value="">Seleccione</option>
            <?php
            // Utilizar la función definida en comun.php para obtener los tipos de viviendas
            $resultTipoVivienda = obtenerTiposViviendas();

            if ($resultTipoVivienda->num_rows > 0) {
                while ($row = $resultTipoVivienda->fetch_assoc()) {
                    echo '<option value="' . htmlspecialchars($row['IdTVivienda']) . '">' . htmlspecialchars($row['NomTVivienda']) . '</option>';
                }
            } else {
                echo '<option value="">No hay tipos de vivienda disponibles</option>';
            }
            ?>
        </select><br><br>

        <!-- Ciudad -->
        <label for="ciudad">Ciudad:</label><br>
        <input type="text" id="ciudad" name="ciudad"><br><br>

        <!-- País -->
        <label for="pais">País:</label><br>
        <select id="pais" name="pais">
            <option value="">Seleccione su país</option>
            <?php
            // Utilizar la función definida en comun.php para obtener los países
            $resultPais = obtenerPaises();

            if ($resultPais->num_rows > 0) {
                while ($row = $resultPais->fetch_assoc()) {
                    echo '<option value="' . htmlspecialchars($row['IdPais']) . '">' . htmlspecialchars($row['NomPais']) . '</option>';
                }
            } else {
                echo '<option value="">No hay países disponibles</option>';
            }
            ?>
        </select><br><br>

        <!-- Precio de la vivienda -->
        <label for="precio">Precio máximo:</label><br>
        <input type="number" id="precio" name="precio" min="1" step="1" placeholder="Ingrese el precio máximo"><br><br>

        <!-- Fecha de publicación del anuncio -->
        <label for="fecha-publicacion">Fecha de publicación del anuncio:</label><br>
        <input type="date" id="fecha-publicacion" name="fecha-publicacion"><br><br>

        <!-- Botón de búsqueda -->
        <input type="submit" value="Buscar">

    </form>

    <?php $conn->close(); ?>
    <?php include 'panel_anuncios.php'; ?>
<?php include 'footer.php'; ?>
