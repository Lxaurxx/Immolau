<?php
include 'db.php';

// Función para obtener los tipos de anuncios
function obtenerTiposAnuncios() {
    global $conn;
    $sql = "SELECT IdTAnuncio, NomTAnuncio FROM TiposAnuncios";
    return $conn->query($sql);
}

// Función para obtener los tipos de viviendas
function obtenerTiposViviendas() {
    global $conn;
    $sql = "SELECT IdTVivienda, NomTVivienda FROM TiposViviendas";
    return $conn->query($sql);
}

// Función para obtener los países
function obtenerPaises() {
    global $conn;
    $sql = "SELECT IdPais, NomPais FROM Paises";
    return $conn->query($sql);
}
?>
