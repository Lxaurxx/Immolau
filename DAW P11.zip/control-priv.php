<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['usuario'])) {
    // Redirigir al inicio si no hay sesión activa
    header("Location: index.php");
    exit();
}
?>