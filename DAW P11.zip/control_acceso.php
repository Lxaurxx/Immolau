<?php
session_start();

include 'db.php';

// Verificar si se enviaron los datos del formulario
if (isset($_POST['usuario']) && isset($_POST['contra'])) {
    $usuario = $_POST['usuario'];
    $contra = $_POST['contra'];

    // Consultar la base de datos para verificar el usuario y la contraseña
    $stmt = $conn->prepare("SELECT IdUsuario, NomUsuario, Clave, Estilo FROM Usuarios WHERE NomUsuario = ?");
    $stmt->bind_param("s", $usuario); // Asigna el valor de $usuario
    $stmt->execute();
    $result = $stmt->get_result();

    // Verificar si se encontró un usuario
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // Verificar la contraseña
        if ($row['Clave'] === $contra) {
            // Establecer variables de sesión
            $_SESSION['usuario'] = $row['NomUsuario'];  // Usuario
            $_SESSION['estilo'] = $row['Estilo'];  // Estilo del usuario
            $_SESSION['user_id'] = $row['IdUsuario'];

            // Si el usuario seleccionó "Recordarme"
            if (isset($_POST['recordarme']) && $_POST['recordarme'] == 'on') {
                // Establecer cookies por 90 días
                setcookie('usuario', $row['NomUsuario'], time() + (90 * 24 * 60 * 60), "/");
                setcookie('ultima_visita', date("Y-m-d H:i:s"), time() + (90 * 24 * 60 * 60), "/");
                setcookie('estilo', $row['Estilo'], time() + (90 * 24 * 60 * 60), "/");
            } else {
                // Eliminar cookies si no seleccionó "Recordarme"
                setcookie('usuario', '', time() - 3600, "/");
                setcookie('ultima_visita', '', time() - 3600, "/");
                setcookie('estilo', '', time() - 3600, "/");
            }

            // Redirigir al menú de usuario registrado
            header("Location: index.php");
            exit();
        } else {
            // Contraseña incorrecta
            $_SESSION['flashdata'] = "Error: Contraseña incorrecta. Inténtalo de nuevo.";
            header("Location: index.php");
            exit();
        }
    } else {
        // Usuario no encontrado
        $_SESSION['flashdata'] = "Error: Usuario o contraseña incorrectos. Inténtalo de nuevo.";
        header("Location: index.php");
        exit();
    }
} else {
    // Si no se enviaron datos, redirigir al formulario de inicio de sesión
    header("Location: index.php");
    exit();
}

// Cerrar conexión
$conn->close();
?>
