<?php
include 'db.php';
include 'head.php';
include 'header1.php';
include 'control-priv.php';

// Obtener el ID del usuario desde la sesión (asume que está autenticado)
$idUsuario = $_SESSION['user_id'];

// Comprobar si existe el usuario en la base de datos
$queryUsuario = $conn->prepare("SELECT * FROM Usuarios WHERE IdUsuario = ?");
$queryUsuario->bind_param("i", $idUsuario);
$queryUsuario->execute();
$resultUsuario = $queryUsuario->get_result();

if ($resultUsuario->num_rows === 0) {
    echo "Error: Usuario no encontrado.";
    exit;
}

$usuario = $resultUsuario->fetch_assoc();

// Resumen de información
$queryResumen = $conn->prepare("
    SELECT 
        Anuncios.IdAnuncio, Anuncios.Titulo, 
        COUNT(Fotos.IdFoto) AS NumFotos
    FROM Anuncios
    LEFT JOIN Fotos ON Anuncios.IdAnuncio = Fotos.Anuncio
    WHERE Anuncios.Usuario = ?
    GROUP BY Anuncios.IdAnuncio
");
$queryResumen->bind_param("i", $idUsuario);
$queryResumen->execute();
$resumen = $queryResumen->get_result();

// Calcular totales
$numAnuncios = 0;
$numFotos = 0;
while ($fila = $resumen->fetch_assoc()) {
    $numAnuncios++;
    $numFotos += $fila['NumFotos'];
}

// Mostrar formulario de confirmación
?>
<h1>Darme de baja</h1>
<p>Estás a punto de eliminar tu cuenta. Esta acción no se puede deshacer.</p>
<h2>Resumen de tu información:</h2>
<ul>
    <li>Número total de anuncios: <?php echo $numAnuncios; ?></li>
    <li>Número total de fotos: <?php echo $numFotos; ?></li>
</ul>
<table>
    <tr>
        <th>Título del anuncio</th>
        <th>Número de fotos</th>
    </tr>
    <?php
    // Reiniciar resultado para mostrar en tabla
    $queryResumen->execute();
    $resumen = $queryResumen->get_result();
    while ($fila = $resumen->fetch_assoc()): ?>
        <tr>
            <td><?php echo htmlspecialchars($fila['Titulo']); ?></td>
            <td><?php echo $fila['NumFotos']; ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<h3>Confirma tu baja introduciendo tu contraseña:</h3>
<form action="procesar-baja.php" method="post">
    <label for="password">Contraseña actual:</label>
    <input type="password" name="password" id="password" required>
    <br>
    <button type="submit" style="color: red;">Confirmar baja</button>
</form>

<?php
include 'footer.php';
?>
