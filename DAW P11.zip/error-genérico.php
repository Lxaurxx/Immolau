<!-- 
 Página de error genérico (demomento en zonas no implementadas)
-->
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>

<body>
<?php include 'search.php'; ?>
    <h2 class="error">Error de Acceso</h2><br>
    <h4>Atención: No puedes acceder a los detalles de esta página porque aún no están implementados.</h4><br>
    <?php include 'panel_anuncios.php'; ?>
 <?php include 'footer.php'; ?>
