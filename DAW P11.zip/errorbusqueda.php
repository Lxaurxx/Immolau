<!-- 
 Página error por no tener la sesión iniciada
-->
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>

<body>
<?php include 'search.php'; ?>
    <h2 class="error">Error de Acceso</h2>
    <p><strong>Atención:</strong> No puedes acceder a los detalles de este anuncio porque no estás registrado.</p>
    <p>Por favor, <a href="registro.php">regístrate</a> o <a href="index.php">inicia sesión</a> para ver más detalles.</p>
    <?php include 'panel_anuncios.php'; ?>
    <?php include 'footer.php'; ?>