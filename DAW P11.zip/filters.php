<?php
// Función para validar los datos de registro o modificación
function validarDatosUsuario($datos) {
    $errores = [];

    // Extraer los datos del array
    $username = $datos['username'] ?? '';
    $password = $datos['password'] ?? '';
    $password2 = $datos['password2'] ?? '';
    $email = $datos['email'] ?? '';
    $sexo = $datos['sexo'] ?? '';
    $birthdate = $datos['birthdate'] ?? '';

    // 1. Validar nombre de usuario
    if (!preg_match('/^[a-zA-Z][a-zA-Z0-9]{2,14}$/', $username)) {
        $errores['username'] = "El nombre de usuario debe tener entre 3 y 15 caracteres, comenzar con una letra y solo contener letras y números.";
    }

    // 2. Validar contraseña
    if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z0-9_-]{6,15}$/', $password)) {
        $errores['password'] = "La contraseña debe tener entre 6 y 15 caracteres, incluir al menos una mayúscula, una minúscula y un número.";
    }

    // 3. Validar repetir contraseña
    if ($password !== $password2) {
        $errores['password2'] = "Las contraseñas no coinciden.";
    }

    // 4. Validar email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254) {
        $errores['email'] = "El correo electrónico no es válido.";
    }

    // 5. Validar sexo
    if (empty($sexo)) {
        $errores['sexo'] = "Debe seleccionar un sexo.";
    }

    // 6. Validar fecha de nacimiento
    $dateParts = explode('-', $birthdate);
    if (count($dateParts) === 3 && checkdate($dateParts[1], $dateParts[2], $dateParts[0])) {
        $dateTimeBirth = new DateTime($birthdate);
        $dateTimeNow = new DateTime();
        $age = $dateTimeNow->diff($dateTimeBirth)->y;
        if ($age < 18) {
            $errores['birthdate'] = "Debes tener al menos 18 años para registrarte.";
        }
    } else {
        $errores['birthdate'] = "La fecha de nacimiento no es válida.";
    }

    return $errores;
}
