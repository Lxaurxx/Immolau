<!-- footer.php -->
<footer>
    <a class="textoblanco" href="accesibilidad.php"><strong><u>Accesibilidad</u></strong></a>
    <p>&copy; 2024 Laura y Pablo </p>
</footer>
<!-- 
<script src="validation.js"></script>
<script src="solalbum.js"></script>
 -->
</body>
</html>
