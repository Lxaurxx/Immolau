<?php
if ($resultFotos->num_rows > 0) {
    // Mostrar las miniaturas de las fotos
    echo "<h3>Galería de Fotos</h3>";
    echo "<div class='galeria'>";
    while ($foto = $resultFotos->fetch_assoc()) {
        $fotoId = $foto['IdFoto']; // Obtener el ID de la foto
        echo "<div class='foto-item'>";
        echo "<img src='{$foto['Fichero']}' alt='{$foto['Alternativo']}' width='550' class='foto-galeria'>";
        echo "<br>";
        // Enlace al archivo de confirmación de eliminación de foto
        echo "<a href='respuesta-eliminar-foto.php?idAnuncio={$idAnuncio}&idFoto={$fotoId}' style='color: red;'>Eliminar Foto</a>";
        echo "</div>";
    }
    echo "</div>";
} else {
    echo "<p>No hay fotos disponibles para este anuncio.</p>";
}
?>
