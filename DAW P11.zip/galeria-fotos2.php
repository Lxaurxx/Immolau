<?php
if ($resultFotos->num_rows > 0) {
    // Mostrar las miniaturas de las fotos
    echo "<h3>Galería de Fotos</h3>";
    echo "<div class='galeria'>";
    while ($foto = $resultFotos->fetch_assoc()) {
        echo "<img src='{$foto['Fichero']}' alt='{$foto['Alternativo']}' width='550' class='foto-galeria'>";
    }
    echo "</div>";
} else {
    echo "<p>No hay fotos disponibles para este anuncio.</p>";
}
?>
