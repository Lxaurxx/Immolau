<?php
// Verifica si la sesión no está iniciada antes de iniciarla
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verifica si el usuario está logueado, ya sea por sesión o por cookies
if (isset($_COOKIE['usuario']) && !isset($_SESSION['usuario'])) {
    $_SESSION['usuario'] = $_COOKIE['usuario']; // Restaura la sesión desde la cookie
    // También puedes restaurar otros datos de la cookie si es necesario
    if (isset($_COOKIE['estilo'])) {
        $_SESSION['estilo'] = $_COOKIE['estilo'];
    }
}
?>
<body>
    <header>
        <a href="index.php">
            <h1><img class="titulo" src="logo.png" width="100" height="100">Pictures &amp; Images</h1>
        </a>
        
        <div class="login">
            <?php if (!isset($_SESSION['usuario'])): ?>
                <!-- Formulario de login -->
                <form id="loginForm" action="control_acceso.php" method="post">
                    <label for="usuario">Usuario:</label>
                    <input type="text" id="usuario" name="usuario">
                    <label for="contra">Contraseña:</label>
                    <input type="password" id="contra" name="contra">
                    <label for="recordarme">Recordarme en este equipo</label>
                    <input type="checkbox" id="recordarme" name="recordarme">
                    <input type="submit" id="submitBtn" value="Entrar">
                </form>
                <nav>
                    <ul>
                        <li><a href="index.php"><i class="fa fa-home"></i>Inicio</a></li>
                        <li><a href="registro.php"><i class="fa fa-pencil"></i>Regístrate</a></li>
                    </ul>
                </nav>
            <?php else: ?>
                <!-- Menú de usuario -->
                <nav>
                    <ul>
                        <li><a href="index.php"><i class="fa fa-home"></i>Inicio</a></li> 
                        <li><a href="perfil.php"><i class="fa fa-user"></i> Perfil usuario</a></li>
                        <li><a href="logout.php"><i class="fa fa-x"></i> Salir </a></li>
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </header>
</body>
