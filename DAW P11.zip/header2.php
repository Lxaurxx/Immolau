<body>

    <header>
     <a href="index.php"> <h1><img class="titulo" src="logo.png" width="100" height="100">Pictures &amp; Images</h1></a>
     <nav>
        <ul>
        <li><a href="index.php"><i class="fa fa-home"></i>Inicio</a></li> 
        <li><a href="perfil.php"><i class="fa fa-user"></i>Perfil usario</a></li>
        <li><a href="logout.php"><i class="fa fa-x"></i>Salir </a> </li>  
        </ul>
        </nav>
       </header>