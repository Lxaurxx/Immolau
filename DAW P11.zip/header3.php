<?php 
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['usuario'])) {
    // Redirigir al inicio si no hay sesión activa
    header("Location: index.php");
    exit();
}

// Saludo personalizado
date_default_timezone_set("Europe/Madrid");
$hora_actual = date("H");
$usuario = $_SESSION['usuario'];

if ($usuario) {
    if ($hora_actual >= 6 && $hora_actual < 12) {
        $saludo = "Buenos días";
    } elseif ($hora_actual >= 12 && $hora_actual < 16) {
        $saludo = "Hola";
    } elseif ($hora_actual >= 16 && $hora_actual < 20) {
        $saludo = "Buenas tardes";
    } else {
        $saludo = "Buenas noches";
    }
}

?>


<header>
        <a href="index.php"> 
            <h1><img src="logo.png" width="100" height="100">Pictures &amp; Images</h1>
        </a>
        <nav>
            <!-- Saludo personalizado con nombre de usuario -->
            <p class="bienvenido"><?php echo "$saludo, $usuario"; ?></p> <!-- Aquí sale el saludo y el nombre del usuario -->
            <ul>
                <li><a href="index.php"><i class="fa fa-home"></i>Inicio</a></li> 
                <li><a href="mis-datos.php"><i class="fa-solid fa-pen-to-square"></i>Modificar datos</a></li> 
                <li><a href="dar-baja.php"><i class="fa-regular fa-rectangle-xmark"></i>Darse de baja</a></li> 
                <li><a href="crear-anuncio.php"><i class="fa-solid fa-plus"></i>Crear anuncio</a></li> 
                <li><a href="anadir-foto.php"><i class="fa-solid fa-image"></i>Añadir fotos a anuncios</a></li> 
                <li><a href="mis-anuncios.php"><i class="fa fa-list"></i>Mis anuncios</a></li> 
                <li><a href="mismensajes.php"><i class="fa fa-message"></i>Mis mensajes</a></li> 
                <li><a href="solicitarfolleto.php"><i class="fa fa-star"></i>Solicitar folleto</a></li> 
                <li><a href="configurar.php"><i class="fa fa-wrench"></i> Configuración</a></li>
                <li><a href="logout.php"><i class="fa fa-x"></i>Salir</a></li>  
            </ul>
        </nav>
    </header>