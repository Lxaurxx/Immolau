<!-- index.php -->
<?php

// Configura la cookie de sesión para que expire al cerrar el navegador
session_set_cookie_params([
    'lifetime' => 0,            // 0 significa que expira al cerrar el navegador
    'path' => '/',
    'domain' => $_SERVER['HTTP_HOST'], 
    'secure' => isset($_SERVER['HTTPS']),  // Solo en HTTPS si está habilitado
    'httponly' => true,
    'samesite' => 'Lax'  // Ajuste opcional
]);

session_start();

include 'head.php';
include 'header1.php';


// Verifica si el usuario está logueado a través de la sesión o las cookies
if (isset($_SESSION['usuario'])) {
    $usuario = $_SESSION['usuario'];
} elseif (isset($_COOKIE['usuario'])) {
    // Si la cookie de usuario existe, mantenemos al usuario logueado (sin la sesión)
    $usuario = $_COOKIE['usuario'];
    $_SESSION['usuario'] = $usuario;  // Opcional: Mantener la sesión activa
} else {
    $usuario = null;
}

// Verifica si el usuario está logueado
$usuario_logueado = isset($usuario);

// Verifica si el usuario está logueado y si la cookie de "usuario" existe (lo que implica que se marcó "Recordarme")
if ($usuario_logueado) {
    // Establece la zona horaria a Madrid
    date_default_timezone_set("Europe/Madrid");
    $hora_actual = date("H");

    // Determina el saludo según la hora
    if ($hora_actual >= 6 && $hora_actual < 12) {
        $saludo = "Buenos días";
    } elseif ($hora_actual >= 12 && $hora_actual < 16) {
        $saludo = "Hola";
    } elseif ($hora_actual >= 16 && $hora_actual < 20) {
        $saludo = "Buenas tardes";
    } else {
        $saludo = "Buenas noches";
    }

    // Recupera la última visita de las cookies
    if (isset($_COOKIE['ultima_visita'])) {
        $ultima_visita = date("d/m/Y H:i", strtotime($_COOKIE['ultima_visita'])); // Formato de la última visita

        // Muestra el mensaje con el saludo y la última visita
        echo "<div class='mensaje-bienvenida'>";
        echo "<p>$saludo, <strong>$usuario</strong>. Su última conexión fue el $ultima_visita.</p>";
        echo "</div>";

        // Actualiza la cookie de última visita con la fecha actual
        setcookie('ultima_visita', date("Y-m-d H:i:s"), time() + (90 * 24 * 60 * 60), "/");  // La cookie dura 90 días
    }
}

// Mostrar el mensaje flashdata (si existe)
if (isset($_SESSION['flashdata'])) {
    echo "<p style='color: red;'>" . $_SESSION['flashdata'] . "</p>";
    // Eliminar el mensaje después de mostrarlo
    unset($_SESSION['flashdata']);
}
?>



<main>
<?php include 'search.php'; ?>
    </div>
    <h2 class="titulospaginas3">Últimos anuncios</h2>
    <?php
    // Verificar si existe el parámetro de error en la URL
    if (isset($_GET['error']) && $_GET['error'] == "Usuario o contraseña incorrectos") {
        echo "<p style='color: red;'>Error: Usuario o contraseña incorrectos. Inténtalo de nuevo.</p>";
    }
    ?>

<?php
include 'db.php';

// Consulta para obtener los últimos 5 anuncios
$sql = "SELECT 
            a.IdAnuncio,
            a.Titulo,
            a.FRegistro,
            a.Ciudad,
            p.NomPais,
            a.Precio,
            f.Fichero
        FROM 
            Anuncios a
        LEFT JOIN 
            Paises p ON a.Pais = p.IdPais
        LEFT JOIN 
            Fotos f ON a.IdAnuncio = f.Anuncio
        GROUP BY 
            a.IdAnuncio
        ORDER BY 
            a.FRegistro DESC
        LIMIT 6";

$result = $conn->query($sql);
echo "<div class='ultimosanuncios'>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $anuncio_id = $row['IdAnuncio'];
        $titulo = htmlspecialchars($row['Titulo']);
        $fecha = date("d/m/Y", strtotime($row['FRegistro']));
        $ciudad = htmlspecialchars($row['Ciudad']);
        $pais = htmlspecialchars($row['NomPais']);
        $precio = htmlspecialchars($row['Precio']);
        $foto = htmlspecialchars($row['Fichero']) ?: 'default.jpg';

        echo "
        <a href='" . ($usuario_logueado ? "anuncio.php?id=$anuncio_id" : "errorbusqueda.php") . "'>
            <div class='ultimosanuncios'>
                <img src='$foto' width='200' alt='Imagen del anuncio $titulo'>
                <figcaption>$titulo - $fecha - $ciudad, $pais - $precio €</figcaption>
            </div>
        </a>";
    }
} else {
    echo "<p>No hay anuncios disponibles.</p>";
}

?>
<?php
// Archivo de anuncios seleccionados
$archivoAnuncios = 'anuncios_seleccionados.txt';

// Leer el archivo y obtener un anuncio aleatorio
if (file_exists($archivoAnuncios)) {
    $contenido = file($archivoAnuncios, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

    // Filtrar líneas no válidas o comentarios
    $anunciosSeleccionados = array_filter($contenido, function ($linea) {
        return strpos($linea, '#') !== 0; // Ignorar líneas que empiezan con '#'
    });

    // Si hay anuncios seleccionados, elegir uno al azar
    if (!empty($anunciosSeleccionados)) {
        $anuncioAleatorio = $anunciosSeleccionados[array_rand($anunciosSeleccionados)];
        list($idAnuncio, $persona, $comentario) = explode('|', $anuncioAleatorio);

        // Consulta para obtener los detalles del anuncio
        $sqlAnuncio = "SELECT 
                            a.Titulo, 
                            a.Ciudad, 
                            a.Precio, 
                            f.Fichero 
                        FROM 
                            Anuncios a
                        LEFT JOIN 
                            Fotos f ON a.IdAnuncio = f.Anuncio
                        WHERE 
                            a.IdAnuncio = ?";
        $stmt = $conn->prepare($sqlAnuncio);
        $stmt->bind_param("i", $idAnuncio);
        $stmt->execute();
        $resultadoAnuncio = $stmt->get_result()->fetch_assoc();

        $enlaceAnuncio = ($usuario_logueado ? "anuncio.php?id=$idAnuncio" : "errorbusqueda.php");

        // Mostrar el anuncio seleccionado si existe
        if ($resultadoAnuncio) {
            $titulo = htmlspecialchars($resultadoAnuncio['Titulo']);
            $ciudad = htmlspecialchars($resultadoAnuncio['Ciudad']);
            $precio = htmlspecialchars($resultadoAnuncio['Precio']);
            $foto = htmlspecialchars($resultadoAnuncio['Fichero']) ?: 'default.jpg';

            echo "
                <section class='anuncio-seleccionado'>
        <h2>Anuncio del día 🔝</h2>
        <a href='$enlaceAnuncio'>
            <div class='anuncio-destacado'>
                <img src='$foto' alt='Imagen del anuncio $titulo' width='300'>
                <div class='detalles-anuncio'>
                    <h3>$titulo</h3>     </a>
                    <p><strong>Ciudad:</strong> $ciudad</p>
                    <p><strong>Precio:</strong> $precio €</p>
                    <p><strong>Seleccionado por:</strong> $persona</p>
                    <p><em>Comentario:</em> $comentario</p>
                </div>
            </div>
    </section>
            ";
        } else {
            echo "<p>No se pudo cargar el anuncio seleccionado.</p>";
        }
    } else {
        echo "<p>No hay anuncios seleccionados disponibles.</p>";
    }
} else {
    echo "<p>El archivo de anuncios seleccionados no existe.</p>";
}
$conn->close();
?>

<?php
// Archivo JSON de consejos
$archivoConsejos = 'consejos.json';

// Verifica si el archivo existe y puede ser leído
if (file_exists($archivoConsejos)) {
    $contenidoJSON = file_get_contents($archivoConsejos);
    $consejos = json_decode($contenidoJSON, true);

    // Verifica que la decodificación del JSON fue exitosa y contiene datos
    if (is_array($consejos) && !empty($consejos)) {
        // Selecciona un consejo aleatorio
        $consejoAleatorio = $consejos[array_rand($consejos)];
        $categoria = htmlspecialchars($consejoAleatorio['categoria']);
        $importancia = htmlspecialchars($consejoAleatorio['importancia']);
        $descripcion = htmlspecialchars($consejoAleatorio['descripcion']);

        // Mostrar el consejo en la página principal
        echo "
        <section class='consejo-compra-venta'>
            <h2>Consejo de compra/venta 💡</h2>
            <div class='consejo'>
                <p><strong>Categoría:</strong> $categoria</p>
                <p><strong>Importancia:</strong> $importancia</p>
                <p><strong>Descripción:</strong> $descripcion</p>
            </div>
        </section>
        ";
    } else {
        echo "<p>No se pudieron cargar los consejos. Verifica el archivo JSON.</p>";
    }
} else {
    echo "<p>El archivo de consejos no existe.</p>";
}
?>


</main>

<?php include 'panel_anuncios.php'; ?>
<?php include 'footer.php'; ?>
