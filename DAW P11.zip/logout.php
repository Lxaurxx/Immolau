<?php
session_start();
session_destroy();

// Borramos las cookies
setcookie('usuario', '', time() - 3600);
setcookie('ultima_visita', '', time() - 3600);
setcookie('ultimos_anuncios', '', time() - 3600);
setcookie('estilo', '', time() - 3600);

header("Location: index.php");
exit;
?>
