<!-- 
Página mensaje a propietario
-->
<?php
// En mensaje.php, obtén el ID del anuncio
if (isset($_GET['id'])) {
    $anuncioId = (int)$_GET['id']; // Convierte el ID a entero para seguridad
} else {
    // Si no está presente, puedes redirigir con un error o mostrar un mensaje de error
    header("Location: mensaje.php?error=1");
    exit;
}

// En mensaje.php, capturamos el parámetro 'usuarioDestino' de la URL
if (isset($_GET['usuarioDestino'])) {
    $usuarioDestino = (int)$_GET['usuarioDestino'];  // Asegúrate de convertirlo a entero para seguridad
} else {
    // Si no existe el parámetro, puedes redirigir o manejar el error
    echo "Error: El parámetro usuarioDestino no está presente en la URL.";
    exit;
}
?>
<?php include 'db.php'; ?>
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?>


<body>
<?php include 'search.php'; ?>
    <h2 class="titulospaginas3">Enviar Mensaje al Anunciante</h2>
    
    <form action="respuestamensaje.php" method="get" enctype="multipart/form-data" class="formulario-centrado">
        <label for="tipo">Tipo de mensaje:</label><br>
        <select id="tipo" name="tipo">
            <option value="">Seleccione el tipo de mensaje</option>
            
            <?php
            // Realizamos la consulta para obtener los tipos de mensajes desde la base de datos
            $sqlTiposMensajes = "SELECT * FROM TiposMensajes";
            $resultTiposMensajes = $conn->query($sqlTiposMensajes);

            // Verificamos si hay resultados
            if ($resultTiposMensajes->num_rows > 0) {
                // Generamos las opciones del select basadas en los tipos de mensaje de la base de datos
                while ($row = $resultTiposMensajes->fetch_assoc()) {
                    echo '<option value="' . $row['IdTMensaje'] . '">' . htmlspecialchars($row['NomTMensaje']) . '</option>';
                }
            } else {
                // Si no hay tipos de mensajes, mostramos un mensaje en la lista desplegable
                echo '<option value="">No hay tipos de mensajes disponibles</option>';
            }
            ?>

        </select><br><br>

        <label for="asunto">Asunto:</label><br>
        <input type="text" id="asunto" name="asunto"><br><br>

        <label for="mensaje">Mensaje:</label><br>
        <textarea id="mensaje" name="mensaje" rows="5" cols="40"></textarea><br><br>

        <!-- Campo oculto para enviar el usuarioDestino a respuestamensaje.php -->
        <input type="hidden" name="usuarioDestino" value="<?php echo $usuarioDestino; ?>">

        <input type="hidden" name="id" value="<?php echo $anuncioId; ?>"> <!-- Enviar el ID del anuncio -->

        <input type="submit" value="Enviar Mensaje">
    </form>
    <?php $conn->close(); ?>
    <?php include 'panel_anuncios.php'; ?>
<?php include 'footer.php'; ?>

