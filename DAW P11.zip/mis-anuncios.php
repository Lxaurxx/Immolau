<?php
include 'control-priv.php';
include 'db.php';

// Obtener el nombre de usuario de la sesión
$nombreUsuario = $_SESSION['usuario'];

// Consulta para obtener el ID del usuario a partir de su nombre
$sql = "SELECT IdUsuario FROM Usuarios WHERE NomUsuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nombreUsuario); // Vinculamos el nombre de usuario
$stmt->execute();
$stmt->bind_result($idUsuario);
$stmt->fetch();
$stmt->close(); // Cerramos la consulta

// Verificamos si se ha encontrado el ID del usuario
if (!$idUsuario) {
    echo "No se pudo encontrar el usuario en la base de datos.";
    exit; // Si no se encuentra el usuario, detenemos la ejecución
}

// Ahora $idUsuario contiene el ID numérico del usuario

// Consulta para obtener los anuncios del usuario
$sql = "
    SELECT 
        a.IdAnuncio, 
        a.Titulo, 
        a.FRegistro, 
        a.Ciudad, 
        p.NomPais, 
        a.Precio, 
        f.Fichero
    FROM 
        Anuncios a
    LEFT JOIN 
        Paises p ON a.Pais = p.IdPais
    LEFT JOIN 
        Fotos f ON a.IdAnuncio = f.Anuncio
    WHERE 
        a.Usuario = ?
    GROUP BY 
        a.IdAnuncio
    ORDER BY 
        a.FRegistro DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $idUsuario); // Ahora usamos el ID del usuario
$stmt->execute();
$result = $stmt->get_result();

// Cuenta el número total de anuncios del usuario
$totalAnuncios = $result->num_rows;

include 'head.php';
include 'header1.php';
?>

<main>
<?php include 'search.php'; ?>
<h1 class="titulospaginas3">Mis anuncios</h1>
<p><strong>Total de anuncios:</strong> <?php echo $totalAnuncios; ?></p>
<a href="crear-anuncio.php"><i class="fa-solid fa-plus"></i><strong> Crear anuncio</strong></a><br><br>
<div class="ultimosanuncios">

<?php
// Mostrar los anuncios del usuario
if ($totalAnuncios > 0) {
    while ($row = $result->fetch_assoc()) {
        $anuncio_id = $row['IdAnuncio'];
        $titulo = htmlspecialchars($row['Titulo']);
        $fecha = date("d/m/Y", strtotime($row['FRegistro']));
        $ciudad = htmlspecialchars($row['Ciudad']);
        $pais = htmlspecialchars($row['NomPais']);
        $precio = htmlspecialchars($row['Precio']);
        $foto = htmlspecialchars($row['Fichero']) ?: 'default.jpg'; // Foto por defecto si no hay ninguna

        echo "
        <a href='ver-anuncio.php?id=$anuncio_id'>
            <div class='ultimosanuncios'>
                <img src='$foto' width='200' alt='Imagen del anuncio $titulo'>
                <figcaption>$titulo - $fecha - $ciudad, $pais - $precio €</figcaption>
            </div>
        </a>";
    }
} else {
    echo "<p>No has publicado anuncios todavía.</p>";
}
?>

</div>
</main>

<?php
include 'footer.php';
$conn->close();
?>
