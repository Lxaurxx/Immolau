<?php include 'control-priv.php'; ?> 
<?php include 'head.php'; ?>
<?php include 'db.php'; ?>
<?php include 'filters.php'; ?>
<?php
// Valida el formato de un correo electrónico
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Valida que una contraseña cumpla con ciertos criterios
function validarContrasena($password) {
    $longitudMinima = 8;
    $patron = '/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';

    if (strlen($password) < $longitudMinima) {
        return false;
    }

    if (!preg_match($patron, $password)) {
        return false;
    }

    return true;
}
?>

<?php
if (!isset($_SESSION['usuario'])) {
    echo "Error: Debes iniciar sesión para ver tus datos.";
    exit();
}

$nomUsuario = $_SESSION['usuario'];

$stmt = $conn->prepare("
    SELECT u.NomUsuario, u.Email, u.Sexo, u.FNacimiento, u.Ciudad, u.Pais, u.Foto, p.NomPais
    FROM Usuarios u
    LEFT JOIN Paises p ON u.Pais = p.IdPais
    WHERE u.NomUsuario = ?
");
$stmt->bind_param("s", $nomUsuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Error: Usuario no encontrado.";
    exit();
}

$row = $result->fetch_assoc();

$nombreUsuario = $row['NomUsuario'];
$email = $row['Email'];
$sexo = $row['Sexo'];
$fNacimiento = $row['FNacimiento'];
$ciudad = $row['Ciudad'];
$pais = $row['NomPais'];
$foto = $row['Foto'] ?: 'default-user-icon.png'; // Icono por defecto si no hay foto

$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errores = [];
    $email = trim($_POST['email']);
    $city = trim($_POST['city']);
    $currentPassword = trim($_POST['current_password']);
    $newPassword = trim($_POST['new_password']);
    $newPassword2 = trim($_POST['new_password2']);
    $newPhoto = $_FILES['new_photo'] ?? null;
    $deletePhoto = isset($_POST['delete_photo']); // Verificar si el usuario quiere eliminar su foto

    // Validar email
    if (!validarEmail($email)) {
        $errores['email'] = "El correo no es válido.";
    }

    // Validar contraseña actual
    $stmt = $conn->prepare("SELECT Clave FROM Usuarios WHERE NomUsuario = ?");
    $stmt->bind_param("s", $nomUsuario);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    if (!password_verify($currentPassword, $result['Clave'])) {
        $errores['current_password'] = "La contraseña actual es incorrecta.";
    }

    // Validar y actualizar contraseña nueva
    $newPasswordHash = $result['Clave'];
    if (!empty($newPassword)) {
        if (!validarContrasena($newPassword)) {
            $errores['new_password'] = "La nueva contraseña no cumple los requisitos.";
        } elseif ($newPassword !== $newPassword2) {
            $errores['new_password2'] = "Las contraseñas no coinciden.";
        } else {
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
        }
    }

    // Procesar la nueva fotografía
    if ($newPhoto && $newPhoto['error'] === UPLOAD_ERR_OK) {
         // Generar un nombre único para la foto
    $extension = pathinfo($newPhoto['name'], PATHINFO_EXTENSION);
    $uniqueName = uniqid('user_', true) . '.' . $extension;
    $photoPath = 'uploads/perfiles/' . $uniqueName;
        if (move_uploaded_file($newPhoto['tmp_name'], $photoPath)) {
            // Borrar foto anterior si existe
            if ($foto && $foto !== 'default-user-icon.png') {
                if (file_exists($foto)) {
                    unlink($foto); // Eliminar el archivo si existe
                } else {
                    error_log("El archivo $foto no existe y no se pudo eliminar.");
                }
            }
            $foto = $photoPath;
        } else {
            $errores['new_photo'] = "Error al subir la nueva foto.";
        }
    }

    // Procesar eliminación de la fotografía
    if ($deletePhoto) {
        if ($foto && $foto !== 'default-user-icon.png') {
            if (file_exists($foto)) {
                unlink($foto); // Eliminar el archivo si existe
            } else {
                error_log("El archivo $foto no existe y no se pudo eliminar.");
            }
        }
        $foto = 'default-user-icon.png';
    }

    if (empty($errores)) {
        // Actualizar los datos en la base de datos
        $stmt = $conn->prepare("UPDATE Usuarios SET Email = ?, Ciudad = ?, Pais = ?, Clave = ?, Foto = ? WHERE NomUsuario = ?");
        $stmt->bind_param("ssssss", $email, $city, $pais, $newPasswordHash, $foto, $nomUsuario);
        if ($stmt->execute()) {
            echo "Datos actualizados con éxito.";
        } else {
            echo "Error al actualizar los datos: " . $stmt->error;
        }
        $stmt->close();
    }
}
?>

<?php include 'header1.php'; ?>

<body>
<?php include 'search.php'; ?>
<h2 class="titulospaginas3">Mis Datos de Usuario</h2>

<form class="formulario-centrado" action="mis-datos.php" method="POST" enctype="multipart/form-data">
    <label for="email"><i class="fa fa-envelope"></i> Correo electrónico:</label><br>
    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required><br><br>

    <label for="city"><i class="fa fa-city"></i> Ciudad:</label><br>
    <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($ciudad); ?>" required><br><br>

    <label for="photo"><i class="fa fa-image"></i> Foto de perfil actual:</label><br>
    <img src="<?php echo htmlspecialchars($foto); ?>" alt="Foto de perfil" width="100"><br><br>

    <label for="new_photo">Subir nueva foto:</label><br>
    <input type="file" id="new_photo" name="new_photo" accept="image/*"><br><br>

    <input type="checkbox" id="delete_photo" name="delete_photo">
    <label for="delete_photo">Eliminar foto de perfil</label><br><br>

    <label for="current_password">Contraseña actual:</label><br>
    <input type="password" id="current_password" name="current_password" required><br><br>

    <label for="new_password">Nueva contraseña:</label><br>
    <input type="password" id="new_password" name="new_password"><br><br>

    <label for="new_password2">Repetir nueva contraseña:</label><br>
    <input type="password" id="new_password2" name="new_password2"><br><br>

    <button type="submit">Actualizar datos</button>
</form>
<?php include 'footer.php'; ?>
