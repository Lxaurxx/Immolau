<!-- 
 Página mis mensajes
-->
<?php include 'control-priv.php'; ?>
<?php include 'head.php'; ?>
<?php include 'db.php'; ?>
<?php

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    echo "Error: Debes iniciar sesión para ver tus mensajes.";
    exit();
}

// Obtener el ID del usuario desde la sesión
$nomUsuario = $_SESSION['usuario'];

// Consultar el ID del usuario
$stmt = $conn->prepare("SELECT IdUsuario FROM Usuarios WHERE NomUsuario = ?");
$stmt->bind_param("s", $nomUsuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Error: Usuario no encontrado.";
    exit();
}

$row = $result->fetch_assoc();
$idUsuario = $row['IdUsuario'];

// Consultar mensajes enviados
$stmtEnviados = $conn->prepare("
    SELECT M.Texto, M.FRegistro, U.NomUsuario AS Receptor, T.NomTMensaje AS Tipo
    FROM Mensajes M
    JOIN Usuarios U ON M.UsuarioDestino = U.IdUsuario
    JOIN TiposMensajes T ON M.TMensaje = T.IdTMensaje
    WHERE M.UsuarioOrigen = ?
");
$stmtEnviados->bind_param("i", $idUsuario);
$stmtEnviados->execute();
$mensajesEnviados = $stmtEnviados->get_result();
$totalEnviados = $mensajesEnviados->num_rows;  // Contar los mensajes enviados

// Consultar mensajes recibidos
$stmtRecibidos = $conn->prepare("
    SELECT M.Texto, M.FRegistro, U.NomUsuario AS Emisor, T.NomTMensaje AS Tipo
    FROM Mensajes M
    JOIN Usuarios U ON M.UsuarioOrigen = U.IdUsuario
    JOIN TiposMensajes T ON M.TMensaje = T.IdTMensaje
    WHERE M.UsuarioDestino = ?
");
$stmtRecibidos->bind_param("i", $idUsuario);
$stmtRecibidos->execute();
$mensajesRecibidos = $stmtRecibidos->get_result();
$totalRecibidos = $mensajesRecibidos->num_rows;  // Contar los mensajes recibidos
?>

<?php include 'header1.php'; ?>


<body>
<?php include 'search.php'; ?>

<h1 class="conBorde">Mensajes enviados: <?= $totalEnviados ?></h1>
    <?php if ($mensajesEnviados->num_rows > 0): ?>
        <?php while ($mensaje = $mensajesEnviados->fetch_assoc()): ?>
            <p><strong>Tipo:</strong> <?= htmlspecialchars($mensaje['Tipo']) ?></p>
            <p><strong>Texto:</strong> <?= htmlspecialchars($mensaje['Texto']) ?></p>
            <p><strong>Fecha:</strong> <?= htmlspecialchars($mensaje['FRegistro']) ?></p>
            <p><strong>Receptor:</strong> <?= htmlspecialchars($mensaje['Receptor']) ?></p>
            <hr>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No tienes mensajes enviados.</p>
    <?php endif; ?>

    <h1 class="conBorde">Mensajes recibidos: <?= $totalRecibidos ?></h1>
    <?php if ($mensajesRecibidos->num_rows > 0): ?>
        <?php while ($mensaje = $mensajesRecibidos->fetch_assoc()): ?>
            <p><strong>Tipo:</strong> <?= htmlspecialchars($mensaje['Tipo']) ?></p>
            <p><strong>Texto:</strong> <?= htmlspecialchars($mensaje['Texto']) ?></p>
            <p><strong>Fecha:</strong> <?= htmlspecialchars($mensaje['FRegistro']) ?></p>
            <p><strong>Emisor:</strong> <?= htmlspecialchars($mensaje['Emisor']) ?></p>
            <hr>
        <?php endwhile; ?>
    <?php else: ?>
        <p>No tienes mensajes recibidos.</p>
    <?php endif; ?>

    <?php include 'footer.php'; ?>
</html>
<?php
// Cerrar las conexiones
$stmtEnviados->close();
$stmtRecibidos->close();
$stmt->close();
$conn->close();
?>

   
