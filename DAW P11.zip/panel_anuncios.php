<?php
// Cargar los últimos anuncios desde la cookie
$ultimosAnuncios = isset($_COOKIE['ultimos_anuncios']) ? json_decode($_COOKIE['ultimos_anuncios'], true) : [];

// Verificar si hay anuncios para mostrar
if (!empty($ultimosAnuncios)) {
    echo '<div class="panel-ultimos-anuncios">';
    echo '<h2>Últimos anuncios visitados</h2>';

    foreach ($ultimosAnuncios as $anuncio) {
        echo '<div class="anuncio">';
        echo '<a href="anuncio.php?id=' . $anuncio['id'] . '">';
        echo '<img src="' . $anuncio['img'] . '" width="100" alt="Imagen del anuncio">';
        echo '<h3>' . $anuncio['titulo'] . '</h3>';
        echo '<p>' . $anuncio['ciudad'] . ', ' . $anuncio['pais'] . '</p>';
        echo '<p><strong>Precio:</strong> ' . $anuncio['precio'] . '</p>';
        echo '</a>';
        echo '</div>';
    }

    echo '</div>';
} else {
    echo '<div class="panel-ultimos-anuncios">';
    echo '<h2>Últimos anuncios visitados</h2>';
    echo '</div>';
}
?>
