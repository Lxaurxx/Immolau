<?php
include 'db.php';
include 'control-priv.php';

// Obtener el ID del usuario desde la sesión
$idUsuario = $_SESSION['user_id'];

// Obtener y verificar la contraseña ingresada
$password = $_POST['password'];

// Comprobar la contraseña del usuario
$queryUsuario = $conn->prepare("SELECT Clave FROM Usuarios WHERE IdUsuario = ?");
$queryUsuario->bind_param("i", $idUsuario);
$queryUsuario->execute();
$resultUsuario = $queryUsuario->get_result();

if ($resultUsuario->num_rows === 0) {
    echo "Error: Usuario no encontrado.";
    exit;
}

$usuario = $resultUsuario->fetch_assoc();
if ($usuario['Clave'] !== $password) {
    echo "Error: Contraseña incorrecta.";
    exit;
}

// Eliminar usuario y datos relacionados
$conn->begin_transaction();

try {
    // 1. Seleccionar la foto de perfil del usuario
    $queryFotoPerfil = $conn->prepare("SELECT Foto FROM Usuarios WHERE IdUsuario = ?");
    $queryFotoPerfil->bind_param("i", $idUsuario);
    $queryFotoPerfil->execute();
    $resultFotoPerfil = $queryFotoPerfil->get_result();

    if ($resultFotoPerfil->num_rows > 0) {
        $usuario = $resultFotoPerfil->fetch_assoc();

        // 2. Eliminar la foto de perfil físicamente del servidor si existe
        if (!empty($usuario['Foto'])) {
            $rutaFotoPerfil = __DIR__ . '/' . $usuario['Foto'];
            if (file_exists($rutaFotoPerfil)) {
                unlink($rutaFotoPerfil); // Elimina el archivo de la foto de perfil
            }
        }
    }

    // 1. Obtener y eliminar archivos de fotos relacionados
    $queryFotos = $conn->prepare("
        SELECT f.Fichero 
        FROM Fotos f
        INNER JOIN Anuncios a ON f.Anuncio = a.IdAnuncio
        WHERE a.Usuario = ?
    ");
    $queryFotos->bind_param("i", $idUsuario);
    $queryFotos->execute();
    $resultFotos = $queryFotos->get_result();

    // Eliminar cada archivo físicamente del servidor
    while ($foto = $resultFotos->fetch_assoc()) {
        $rutaFoto = __DIR__ . '/' . $foto['Fichero'];
        if (file_exists($rutaFoto)) {
            unlink($rutaFoto); // Elimina el archivo
        }
    }

    // 2. Eliminar anuncios y fotos relacionados (ON DELETE CASCADE eliminará de `Fotos`)
    $queryEliminarAnuncios = $conn->prepare("DELETE FROM Anuncios WHERE Usuario = ?");
    $queryEliminarAnuncios->bind_param("i", $idUsuario);
    $queryEliminarAnuncios->execute();

    // 3. Eliminar mensajes relacionados
    $queryEliminarMensajes = $conn->prepare("DELETE FROM Mensajes WHERE UsuarioOrigen = ? OR UsuarioDestino = ?");
    $queryEliminarMensajes->bind_param("ii", $idUsuario, $idUsuario);
    $queryEliminarMensajes->execute();

    // 4. Eliminar el usuario
    $queryEliminarUsuario = $conn->prepare("DELETE FROM Usuarios WHERE IdUsuario = ?");
    $queryEliminarUsuario->bind_param("i", $idUsuario);
    $queryEliminarUsuario->execute();

    // Confirmar transacción
    $conn->commit();
    echo "Tu cuenta y todos los datos asociados se han eliminado correctamente.";
    sleep(2);
    header("Location: logout.php");
} catch (Exception $e) {
    $conn->rollback();
    echo "Error al eliminar la cuenta: " . $e->getMessage();
}

?>
