<!-- 
 Página formulario de registro
-->
 
<?php
session_start();
include 'head.php'; // Incluye el encabezado
include 'header1.php'; // Incluye el encabezado con el formulario de registro
include 'db.php';
include 'filters.php';

// Recuperamos los errores desde la sesión
$errores = isset($_SESSION['flashdata']) ? $_SESSION['flashdata'] : [];
// Eliminamos los errores de la sesión después de haberlos usado
unset($_SESSION['flashdata']);

// Si hay datos previos (como los valores introducidos en el formulario)
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';
$email = isset($_SESSION['email']) ? $_SESSION['email'] : '';
$password = isset($_SESSION['password']) ? $_SESSION['password'] : '';
$password2 = isset($_SESSION['password2']) ? $_SESSION['password2'] : '';
$birthdate = isset($_SESSION['birthdate']) ? $_SESSION['birthdate'] : '';
$sexo = isset($_SESSION['sexo']) ? $_SESSION['sexo'] : '';
$city = isset($_SESSION['city']) ? $_SESSION['city'] : '';
$pais = isset($_SESSION['pais']) ? $_SESSION['pais'] : '';

// Limpiar los valores de sesión después de haber sido utilizados
unset($_SESSION['username'], $_SESSION['email'], $_SESSION['password'], $_SESSION['password2'], $_SESSION['birthdate'], $_SESSION['sexo'], $_SESSION['city'], $_SESSION['pais']);
?>
<body>
<?php include 'search.php'; ?>

    <h2 class="titulospaginas3"> Registro de Nuevo Usuario ✅</h2>


    <form action="respuestaregistro.php" id="registerForm" method="post" enctype="multipart/form-data" class="formulario-centrado">
        <!-- Campos del formulario con valores anteriores -->
        
        <label for="username"><i class="fa fa-user"></i> Nombre de usuario:</label><br>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>">
        <?php if (isset($errores['username'])): ?>
            <span class="mensaje-error" id="error-username"><?php echo $errores['username']; ?></span>
        <?php endif; ?>
        <br><br>

        <label for="email"><i class="fa fa-envelope"></i> Correo electrónico:</label><br>
        <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>">
        <?php if (isset($errores['email'])): ?>
            <span class="mensaje-error" id="error-email"><?php echo $errores['email']; ?></span>
        <?php endif; ?>
        <br><br>

        <label for="password"><i class="fa fa-lock"></i> Contraseña:</label><br>
        <input type="password" id="password" name="password">
        <?php if (isset($errores['password'])): ?>
            <span class="mensaje-error" id="error-password"><?php echo $errores['password']; ?></span>
        <?php endif; ?>
        <br><br>

        <label for="password2"><i class="fa fa-lock"></i> Repetir contraseña:</label><br>
        <input type="password" id="password2" name="password2">
        <?php if (isset($errores['password2'])): ?>
            <span class="mensaje-error" id="error-password2"><?php echo $errores['password2']; ?></span>
        <?php endif; ?>
        <br><br>

        <label for="birthdate"><i class="fa fa-calendar"></i> Fecha de nacimiento (AAAA-MM-DD):</label><br>
        <input type="text" id="birthdate" name="birthdate" value="<?php echo htmlspecialchars($birthdate); ?>">
        <?php if (isset($errores['birthdate'])): ?>
            <span class="mensaje-error" id="error-birthdate"><?php echo $errores['birthdate']; ?></span>
        <?php endif; ?>
        <br><br>

        <label for="sexo"><i class="fa fa-venus-mars"></i> Sexo:</label>
        <select id="sexo" name="sexo">
            <option value="">Seleccione su sexo</option>
            <option value="masculino" <?php echo $sexo === 'masculino' ? 'selected' : ''; ?>>Masculino</option>
            <option value="femenino" <?php echo $sexo === 'femenino' ? 'selected' : ''; ?>>Femenino</option>
            <option value="otro" <?php echo $sexo === 'otro' ? 'selected' : ''; ?>>Otro</option>
            <option value="prefiero_no_decirlo" <?php echo $sexo === 'prefiero_no_decirlo' ? 'selected' : ''; ?>>Prefiero no decirlo</option>
        </select>
        <?php if (isset($errores['sexo'])): ?>
            <span class="mensaje-error" id="error-sexo"><?php echo $errores['sexo']; ?></span>
        <?php endif; ?>
        <br><br>

        <label for="city"><i class="fa fa-city"></i> Ciudad:</label><br>
        <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($city); ?>"><br><br>

        <label for="pais"><i class="fa fa-flag"></i> País de Residencia:</label><br>
<select id="pais" name="pais">
    <option value="">Seleccione su país</option>
    <?php
    // Obtener países
    $sql = "SELECT IdPais, NomPais FROM Paises ORDER BY NomPais ASC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<option value="' . htmlspecialchars($row['IdPais']) . '"';
            if ($pais == $row['IdPais']) {
                echo ' selected';
            }
            echo '>' . htmlspecialchars($row['NomPais']) . '</option>';
        }
    } else {
        echo '<option value="">No hay países disponibles</option>';
    }

    // Cerrar la conexión
    $conn->close();
    ?>
</select>
<br><br>

        <label for="photo"><i class="fa fa-image"></i> Foto de perfil:</label><br>
        <input type="file" id="photo" name="photo" accept="image/*"><br><br>

        <input type="submit" value="Registrarse">
    </form>

    <?php include 'footer.php'; ?>

