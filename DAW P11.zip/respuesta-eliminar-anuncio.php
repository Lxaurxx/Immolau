<?php
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'db.php';

// Verifica si el ID de anuncio está presente en la URL
$idAnuncio = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Obtener el nombre de usuario de la sesión
$nombreUsuario = $_SESSION['usuario'];

// Consulta para obtener el ID del usuario logueado
$sqlUsuario = "SELECT IdUsuario FROM Usuarios WHERE NomUsuario = ?";
$stmtUsuario = $conn->prepare($sqlUsuario);
$stmtUsuario->bind_param("s", $nombreUsuario);
$stmtUsuario->execute();
$stmtUsuario->bind_result($idUsuario);
$stmtUsuario->fetch();
$stmtUsuario->close();

// Verificar si el usuario existe
if (!$idUsuario) {
    echo "Usuario no encontrado.";
    exit;
}

// Obtener la información del anuncio para mostrarla
$queryAnuncio = "SELECT Titulo FROM Anuncios WHERE IdAnuncio = ? AND Usuario = ?";
$stmtAnuncio = $conn->prepare($queryAnuncio);
$stmtAnuncio->bind_param("ii", $idAnuncio, $idUsuario);
$stmtAnuncio->execute();
$resultAnuncio = $stmtAnuncio->get_result();

// Si no se encuentra el anuncio, redirige al perfil
if ($resultAnuncio->num_rows === 0) {
    echo "Anuncio no encontrado o no pertenece a este usuario.";
    exit;
}

$anuncio = $resultAnuncio->fetch_assoc();
$stmtAnuncio->close();

?>

<!-- Formulario de confirmación de eliminación -->
<div class="formulario-centrado">
    <h1>Confirmar eliminación</h1>
    <p>¿Está seguro de que desea eliminar el anuncio "<strong><?php echo htmlspecialchars($anuncio['Titulo']); ?></strong>"? Esta acción es irreversible.</p>

    <!-- Formulario para confirmar la eliminación -->
    <form action="respuesta-eliminar-anuncio.php?id=<?php echo $idAnuncio; ?>" method="post">
        <input type="hidden" name="id" value="<?php echo $idAnuncio; ?>">
        <button type="submit" name="confirmar" value="si" style="color: red;">Sí, eliminar anuncio</button>
        <a href="mis-anuncios.php">Cancelar</a>
    </form>
</div>

<?php
// Si el formulario de confirmación ha sido enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar']) && $_POST['confirmar'] === 'si') {
    $conn->begin_transaction(); // Inicia una transacción para asegurarse de que todo se elimine correctamente

    try {
        // Obtener todas las fotos asociadas al anuncio antes de eliminarlas
        $queryFotos = "SELECT Fichero FROM Fotos WHERE Anuncio = ?";
        $stmtFotos = $conn->prepare($queryFotos);
        $stmtFotos->bind_param("i", $idAnuncio);
        $stmtFotos->execute();
        $resultFotos = $stmtFotos->get_result();

        // Eliminar las fotos físicamente del servidor
        while ($foto = $resultFotos->fetch_assoc()) {
            $fotoPath = $foto['Fichero'];
            if (file_exists($fotoPath)) {
                unlink($fotoPath);  // Elimina el archivo físico
            }
        }
        $stmtFotos->close();

        // Eliminar fotos asociadas al anuncio de la base de datos
        $queryEliminarFotos = "DELETE FROM Fotos WHERE Anuncio = ?";
        $stmtEliminarFotos = $conn->prepare($queryEliminarFotos);
        $stmtEliminarFotos->bind_param("i", $idAnuncio);
        $stmtEliminarFotos->execute();
        $stmtEliminarFotos->close();

        // Eliminar mensajes asociados al anuncio
        $queryEliminarMensajes = "DELETE FROM Mensajes WHERE Anuncio = ?";
        $stmtEliminarMensajes = $conn->prepare($queryEliminarMensajes);
        $stmtEliminarMensajes->bind_param("i", $idAnuncio);
        $stmtEliminarMensajes->execute();
        $stmtEliminarMensajes->close();

        // Eliminar solicitudes asociadas al anuncio
        $queryEliminarSolicitudes = "DELETE FROM Solicitudes WHERE Anuncio = ?";
        $stmtEliminarSolicitudes = $conn->prepare($queryEliminarSolicitudes);
        $stmtEliminarSolicitudes->bind_param("i", $idAnuncio);
        $stmtEliminarSolicitudes->execute();
        $stmtEliminarSolicitudes->close();

        // Eliminar el anuncio
        $queryEliminarAnuncio = "DELETE FROM Anuncios WHERE IdAnuncio = ? AND Usuario = ?";
        $stmtEliminarAnuncio = $conn->prepare($queryEliminarAnuncio);
        $stmtEliminarAnuncio->bind_param("ii", $idAnuncio, $idUsuario);
        $stmtEliminarAnuncio->execute();
        $stmtEliminarAnuncio->close();

        // Commit de la transacción
        $conn->commit();

        // Redirigir al perfil después de la eliminación exitosa
        echo "<p>El anuncio ha sido eliminado correctamente. Redirigiendo...</p>";
        include 'footer.php';
        header("refresh:2;url=mis-anuncios.php");
        exit;
    } catch (Exception $e) {
        // Si ocurre un error, deshacer la transacción
        $conn->rollback();
        echo "Error al eliminar el anuncio: " . $e->getMessage();
    }
}

// Cierra la conexión a la base de datos
$conn->close();
?>

<?php include 'footer.php'; ?>
