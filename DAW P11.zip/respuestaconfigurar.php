<?php
// Incluir la conexión a la base de datos y verificar el inicio de sesión del usuario
include 'db.php';
session_start();

include 'head.php'; 
include 'header1.php'; 
include 'control-priv.php'; 

// Obtener el ID del usuario desde la sesión
$usuarioId = $_SESSION['user_id'];

// Verificar si se ha enviado un estilo desde configurar.php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['estilo'])) {
    $estiloId = (int)$_POST['estilo']; // Asegurar que el valor sea un número entero

    // Actualizar el estilo del usuario en la base de datos
    $sql = "UPDATE Usuarios SET Estilo = ? WHERE IdUsuario = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        die('Error en la preparación de la consulta: ' . $conn->error);
    }

    $stmt->bind_param("ii", $estiloId, $usuarioId);

    if ($stmt->execute()) {
        // Actualizar el estilo en la sesión
        $_SESSION['estilo'] = $estiloId;

        // Redirigir a la misma página para recargar el estilo
        header("Location: respuestaconfigurar.php?success=1");
        exit();
    } else {
        $mensaje = "Error al modificar el estilo: " . $stmt->error;
    }

    $stmt->close();
}

// Mostrar mensaje en caso de error (si no se realizó la redirección)
$conn->close();
?>

<body>
<?php include 'search.php'; ?>
    <p>Se ha cambiado el estilo</p>
    <a href="configurar.php">Volver a Configuración</a>
    <?php include 'footer.php'; ?>

