<?php include 'db.php'; ?>
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?>
<?php
// Comprobamos si se han recibido los datos a través de GET
if (isset($_GET['tipo'], $_GET['asunto'], $_GET['mensaje'])) {
    // Recogemos los datos del formulario y aplicamos trim() para eliminar espacios en blanco al principio y al final
    $tipo = trim($_GET['tipo']);
    $asunto = trim($_GET['asunto']);
    $mensaje = trim($_GET['mensaje']);

    // Comprobamos si los campos están vacíos después de aplicar trim()
    if (empty($tipo) || empty($asunto) || empty($mensaje)) {
        // Si alguno de los campos está vacío después de eliminar los espacios en blanco, redirigimos con un error
        header("Location: mensaje.php?error=1");
        exit;
    }

    // Realizamos una consulta a la base de datos para obtener el nombre del tipo de mensaje
    $sql = "SELECT NomTMensaje FROM TiposMensajes WHERE IdTMensaje = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die('Error en la preparación de la consulta: ' . $conn->error);
    }
    $stmt->bind_param("i", $tipo); // "i" para tipo entero (IdTMensaje)
    $stmt->execute();
    $stmt->bind_result($nomTMensaje);
    $stmt->fetch();
    $stmt->close();

    // Si no se encuentra el tipo de mensaje, asignamos un valor predeterminado
    if (!$nomTMensaje) {
        $nomTMensaje = "Tipo de mensaje no encontrado";
    }


    // Fecha del envío (puedes generar la fecha actual)
    $fechaEnvio = date('d/m/Y');

    // Información del usuario actual (esto depende de cómo gestionas la sesión)
    // Supongo que ya tienes una variable $userId con el id del usuario conectado
    $usuarioOrigen = $_SESSION['user_id'];
// Verificar si el parámetro usuarioDestino está presente en la URL
if (isset($_GET['usuarioDestino'])) {
    $usuarioDestino = (int)$_GET['usuarioDestino'];  // Convertir a entero para mayor seguridad
} else {
    header("Location: mensaje.php?error=1");
    exit;
}

// Realizamos una consulta para obtener el nombre del usuarioDestino desde la base de datos
$sql = "SELECT NomUsuario FROM Usuarios WHERE IdUsuario = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die('Error en la preparación de la consulta: ' . $conn->error);
}

$stmt->bind_param("i", $usuarioDestino);  // Usamos el ID del usuarioDestino
$stmt->execute();
$stmt->bind_result($nombre);  // Solo asignamos una variable porque solo seleccionamos una columna

// Ejecutamos la consulta
if ($stmt->fetch()) {
    $destinatario = $nombre;  // Solo mostramos el nombre del usuario
} else {
    // Si no encontramos al usuario, asignamos un valor predeterminado
    $destinatario = "Usuario no encontrado";
}

$stmt->close();


   // En respuestamensaje.php, obtenemos el ID del anuncio
if (isset($_GET['id'])) {
    $anuncioId = (int)$_GET['id']; // Convierte el ID a entero para seguridad
} else {
    // Si no está presente, rediriges o muestras un mensaje de error
    header("Location: mensaje.php?error=1");
    exit;
}


    // Verificamos si el anuncio con el IdAnuncio existe en la tabla Anuncios
    $checkAnuncioSql = "SELECT IdAnuncio FROM Anuncios WHERE IdAnuncio = ?";
    $checkAnuncioStmt = $conn->prepare($checkAnuncioSql);
    if ($checkAnuncioStmt === false) {
        die('Error en la preparación de la consulta de verificación de anuncio: ' . $conn->error);
    }
    $checkAnuncioStmt->bind_param("i", $anuncioId);
    $checkAnuncioStmt->execute();
    $checkAnuncioStmt->store_result();

    if ($checkAnuncioStmt->num_rows === 0) {
        // Si no existe el anuncio con ese IdAnuncio, mostramos un error y no realizamos la inserción
        echo "El anuncio con ID $anuncioId no existe.";
        $checkAnuncioStmt->close();
        exit;
    }

    $checkAnuncioStmt->close();

    // Ahora insertamos el mensaje en la base de datos
    $insertSql = "INSERT INTO Mensajes (TMensaje, Texto, Anuncio, UsuarioOrigen, UsuarioDestino) 
                  VALUES (?, ?, ?, ?, ?)";
    $insertStmt = $conn->prepare($insertSql);

    if ($insertStmt === false) {
        die('Error en la preparación de la consulta de inserción: ' . $conn->error);
    }

    $insertStmt->bind_param("isiii", $tipo, $mensaje, $anuncioId, $usuarioOrigen, $usuarioDestino);

    // Ejecutar la inserción
    if ($insertStmt->execute()) {
        // Si la inserción fue exitosa, mostramos los detalles del mensaje
        $mensajeExito = true;
    } else {
        // Si hubo algún error en la inserción, mostramos un mensaje de error
        echo 'Error en la inserción: ' . $insertStmt->error;
        $mensajeExito = false;
    }

    $insertStmt->close();
} else {
    // Si faltan datos importantes, redirigimos con un error
    header("Location: mensaje.php?error=1");
    exit;
}
?>

<!-- Página respuesta mensaje a propietario -->


<body>
<?php include 'search.php'; ?>

    <form action="index.php" method="get" enctype="multipart/form-data">
     <h1 class="conBorde">
        <?php if (isset($mensajeExito) && $mensajeExito) { ?>
            Tu mensaje ha sido enviado correctamente.
        <?php } else { ?>
            Hubo un error al enviar el mensaje.
        <?php } ?>
     </h1>
    
     <h2>Detalles del Mensaje</h2>
     <p><strong>Destinatario:</strong> <?php echo $destinatario; ?></p>
     <p><strong>Tipo de mensaje:</strong> <?php echo ucfirst($nomTMensaje); ?></p>  <!-- Mostrar el nombre del tipo de mensaje -->
     <p><strong>Asunto:</strong> <?php echo $asunto; ?></p>
     <p><strong>Mensaje:</strong> <?php echo nl2br($mensaje); ?></p>  <!-- nl2br() para convertir saltos de línea en <br> -->
     <p><strong>Fecha de Envío:</strong> <?php echo $fechaEnvio; ?></p>

    <input type="submit" value="Entendido">
</form>
<?php $conn->close(); ?>
<?php include 'panel_anuncios.php'; ?>
<?php include 'footer.php'; ?>
</body>
