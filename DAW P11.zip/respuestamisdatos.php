<?php
session_start();
include 'db.php'; // Conexión a la base de datos
include 'filters.php'; // Funciones de validación

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recoger datos del formulario
    $username = $_POST['username'];
    $email = trim($_POST['email']);
    $city = trim($_POST['city']);
    $pais = intval($_POST['pais']);
    $currentPassword = trim($_POST['current_password']);
    $newPassword = trim($_POST['new_password']);
    $newPassword2 = trim($_POST['new_password2']);

    // Crear un array con los datos recibidos del formulario
    $datos = [
        'username' => $username,
        'password' => $newPassword,
        'password2' => $newPassword2,
        'email' => $email,
        'sexo' => $_POST['sexo'] ?? '',
        'birthdate' => $_POST['birthdate'] ?? ''
    ];

    // Validar datos
    $errores = validarDatosUsuario($datos);

    // Validar contraseña actual
    $stmt = $conn->prepare("SELECT Clave FROM Usuarios WHERE NomUsuario = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if (!$result || !password_verify($currentPassword, $result['Clave'])) {
        $errores['current_password'] = "La contraseña actual es incorrecta.";
    }

    if (empty($errores)) {
        // Actualizar los datos en la base de datos
        $stmt = $conn->prepare("UPDATE Usuarios SET Email = ?, Ciudad = ?, Pais = ?, Clave = ? WHERE NomUsuario = ?");
        $newPasswordHash = empty($newPassword) ? $result['Clave'] : password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt->bind_param("sssss", $email, $city, $pais, $newPasswordHash, $username);
        if ($stmt->execute()) {
            echo "Datos actualizados con éxito.";
        } else {
            echo "Error al actualizar los datos.";
        }
    } else {
        // Si hay errores, guardarlos en la sesión y redirigir
        $_SESSION['flashdata'] = $errores;
        header("Location: mis-datos.php");
        exit;
    }
}
?>
