<?php
// Incluir conexión, validaciones y verificar inicio de sesión
include 'db.php';
include 'validaciones.php';
include 'control-priv.php';
include 'head.php';
include 'header1.php';


// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    die('Error: Debes iniciar sesión para modificar un anuncio.');
}

// Obtener el ID del anuncio desde la URL o formulario
$idAnuncio = isset($_POST['id_anuncio']) ? (int)$_POST['id_anuncio'] : 0;
if ($idAnuncio <= 0) {
    die('Error: ID de anuncio inválido.');
}

// Obtener el ID del usuario de la sesión
$usuarioId = $_SESSION['user_id'];

// Capturar datos del formulario
$datos = [
    'titulo' => $_POST['titulo'] ?? '',
    'descripcion' => $_POST['descripcion'] ?? '',
    'tipo_anuncio' => $_POST['tipo_anuncio'] ?? '',
    'tipo_vivienda' => $_POST['tipo_vivienda'] ?? '',
    'precio' => $_POST['precio'] ?? '',
    'superficie' => $_POST['superficie'] ?? '',
    'ciudad' => $_POST['ciudad'] ?? '',
    'pais' => $_POST['pais'] ?? '',
    'nhabitaciones' => $_POST['nhabitaciones'] ?? '',
    'nbanyos' => $_POST['nbanyos'] ?? '',
    'planta' => $_POST['planta'] ?? '',
    'anyo' => $_POST['anyo'] ?? ''
];

// Validar los datos
$errores = validarDatosAnuncio($datos);
if (!empty($errores)) {
    foreach ($errores as $error) {
        echo "<p>Error: $error</p>";
    }
    exit;
}

// Actualizar anuncio en la base de datos
$sql = "UPDATE Anuncios SET 
        Titulo = ?, Texto = ?, Precio = ?, Ciudad = ?, Pais = ?, Superficie = ?, 
        TAnuncio = ?, TVivienda = ?, Nhabitaciones = ?, Nbanyos = ?, Planta = ?, Anyo = ?
        WHERE IdAnuncio = ? AND Usuario = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Error en la preparación de la consulta: ' . $conn->error);
}
$precio = is_numeric($datos['precio']) ? floatval($datos['precio']) : 0;
$superficie = is_numeric($datos['superficie']) ? floatval($datos['superficie']) : 0;
$pais = is_numeric($datos['pais']) ? intval($datos['pais']) : 0;
$tipo_anuncio = is_numeric($datos['tipo_anuncio']) ? intval($datos['tipo_anuncio']) : 0;
$tipo_vivienda = is_numeric($datos['tipo_vivienda']) ? intval($datos['tipo_vivienda']) : 0;
$nhabitaciones = is_numeric($datos['nhabitaciones']) ? intval($datos['nhabitaciones']) : 0;
$nbanyos = is_numeric($datos['nbanyos']) ? intval($datos['nbanyos']) : 0;
$planta = is_numeric($datos['planta']) ? intval($datos['planta']) : 0;
$anyo = is_numeric($datos['anyo']) ? intval($datos['anyo']) : 0;


// Vincular parámetros para la actualización
$stmt->bind_param(
    "ssssssiissiiii",
    $datos['titulo'],          // string
    $datos['descripcion'],     // string
    $precio,                   // float
    $datos['ciudad'],          // string
    $pais,                     // int
    $superficie,               // float
    $tipo_anuncio,             // int
    $tipo_vivienda,            // int
    $nhabitaciones,            // int
    $nbanyos,                  // int
    $planta,                   // int
    $anyo,                     // int
    $idAnuncio,                // int
    $usuarioId                 // int
);

include 'search.php';
if ($stmt->execute()) {
    echo "<h1>Anuncio modificado con éxito</h1>";
    echo "<a href='ver-anuncio.php?id=$idAnuncio'>Volver al anuncio</a>";
} else {
    echo "Error al modificar el anuncio: " . $stmt->error;
}

$stmt->close();
$conn->close();
include 'footer.php';
?>

