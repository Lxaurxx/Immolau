<?php
session_start();
include 'db.php'; // Conexión a la base de datos
include 'filters.php'; // Funciones de validación

// Obtener los datos del formulario
$username = trim($_POST['username']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$password2 = trim($_POST['password2']);
$birthdate = trim($_POST['birthdate']);
$mapaSexo = [
    'masculino' => 1,
    'femenino' => 2,
    'otro' => 3,
    'prefiero_no_decirlo' => 4
];
$sexo = isset($_POST['sexo']) && isset($mapaSexo[trim($_POST['sexo'])]) ? $mapaSexo[trim($_POST['sexo'])] : 0;
$city = trim($_POST['city']);
$pais = intval($_POST['pais']);
$photoPath = null;  // Para la foto de perfil 

// Validar y procesar la foto de perfil
if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $fileTmpPath = $_FILES['photo']['tmp_name'];
    $fileName = $_FILES['photo']['name'];
    $fileSize = $_FILES['photo']['size'];
    $fileType = $_FILES['photo']['type'];

    // Validar el tipo de archivo (solo imágenes permitidas)
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    if (!in_array($fileType, $allowedTypes)) {
        die("Error: El archivo debe ser una imagen (JPEG, PNG o GIF).");
    }

    // Validar el tamaño del archivo (máximo 2MB)
    if ($fileSize > 2 * 1024 * 1024) {
        die("Error: El archivo es demasiado grande. Tamaño máximo permitido: 2MB.");
    }

    // Mover el archivo al directorio de destino
    $uploadDir = 'uploads/perfiles/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Crear el directorio si no existe
    }
    $fileDestination = $uploadDir . uniqid() . '-' . basename($fileName);

    if (!move_uploaded_file($fileTmpPath, $fileDestination)) {
        die("Error: No se pudo mover el archivo al directorio de destino.");
    }

    $photoPath = $fileDestination; // Guardar la ruta del archivo
}

// Crear un array con los datos recibidos del formulario
$datos = [
    'username' => $username,
    'password' => $password,
    'password2' => $password2,
    'email' => $email,
    'sexo' => $sexo,
    'birthdate' => $birthdate
];

// Validación de errores
$errores = validarDatosUsuario($datos);

// Si hay errores, guardar los errores como flashdata
if (!empty($errores)) {
    $_SESSION['flashdata'] = $errores;
    // Guardar los valores previos para rellenar el formulario
    $_SESSION['username'] = $username;
    $_SESSION['email'] = $email;
    $_SESSION['birthdate'] = $birthdate;
    $_SESSION['sexo'] = $sexo;
    $_SESSION['city'] = $city;
    $_SESSION['pais'] = $pais;
    header("Location: registro.php");
    exit;
}

// Si no hay errores, insertar en la base de datos
try {
    $stmt = $conn->prepare(
        "INSERT INTO Usuarios (NomUsuario, Clave, Email, Sexo, FNacimiento, Ciudad, Pais, Foto)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param('ssssssis', $username, $password, $email, $sexo, $birthdate, $city, $pais, $photoPath);

    if (!$stmt->execute()) {
        throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
    }
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>

<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>

<body>
<form action="index.php" method="get" enctype="multipart/form-data">
    <h2 class="titulospaginas3">Registro completado</h2>
    <p><strong>Nombre de usuario:</strong> <?php echo htmlspecialchars($username); ?></p>
    <p><strong>Correo electrónico:</strong> <?php echo htmlspecialchars($email); ?></p>
    <p><strong>Fecha de nacimiento:</strong> <?php echo htmlspecialchars($birthdate); ?></p>
    <p><strong>Sexo:</strong> <?php echo htmlspecialchars($sexo); ?></p>
    <p><strong>Ciudad:</strong> <?php echo htmlspecialchars($city); ?></p>
    <p><strong>País:</strong> <?php echo htmlspecialchars($pais); ?></p>
    <?php if ($photoPath): ?>
        <p><strong>Foto de perfil:</strong></p>
        <img src="<?php echo htmlspecialchars($photoPath); ?>" alt="Foto de perfil" style="max-width: 200px; height: auto;">
    <?php endif; ?>
    <p><em>Su registro se ha completado con éxito.</em></p>

    <input type="submit" value="Entendido">
</body>

<?php include 'footer.php'; ?>
