<!-- Página respuesta solicitar folleto -->
<?php 
include 'head.php'; 
include 'header1.php'; 
include 'control-priv.php'; 
include 'db.php';  // Asegúrate de incluir la conexión a la base de datos
//Funcion obtener costo
function obtenerCosto($paginas, $fotos, $resolucion, $tipo) {
    $costoBase = 12.00;
    $incrementoPaginas = 0;
    if ($paginas > 1 && $paginas <= 4) {
        $incrementoPaginas = 2.00 * ($paginas - 1);
    } elseif ($paginas >= 5 && $paginas <= 10) {
        $incrementoPaginas = 2.00 * 3 + 1.80 * ($paginas - 4); 
    } elseif ($paginas > 10) {
        $incrementoPaginas = 2.00 * 3 + 1.80 * 6 + 1.60 * ($paginas - 10);
    }

    $incrementoFotos = 0;
    if ($tipo === "color") {
        $incrementoFotos += 0.50 * $fotos;
    }

    if ($resolucion === "450-900") {
        $incrementoFotos += 0.20 * $fotos;
    }

    $costoTotal = $costoBase + $incrementoPaginas + $incrementoFotos;
    return number_format($costoTotal, 2);
}

// Verificación de los datos recibidos desde el formulario
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Obtener los datos del formulario
    $nombre = htmlspecialchars($_GET['nombre']);
    $correo = htmlspecialchars($_GET['correo']);
    $texto = htmlspecialchars($_GET['texto']);
    $calle = htmlspecialchars($_GET['calle']);
    $numero = htmlspecialchars($_GET['numero']);
    $piso = htmlspecialchars($_GET['piso']);
    $puerta = htmlspecialchars($_GET['puerta']);
    $codigo_postal = htmlspecialchars($_GET['codigo_postal']);
    $pais = htmlspecialchars($_GET['pais']);
    $provincia = htmlspecialchars($_GET['provincia']);
    $localidad = htmlspecialchars($_GET['localidad']);
    $telefono = htmlspecialchars($_GET['Telefono']);
    $color_portada = htmlspecialchars($_GET['color']);
    $numero_copias = (int)$_GET['numero_copias'];
    $resolucion = htmlspecialchars($_GET['resolucion']);
    $anuncio = (int)$_GET['anuncio'];
    $fecha_recepcion = htmlspecialchars($_GET['fecha_recepcion']);
    $impresion_color = $_GET['impresion_color'] === 'atodocolor' ? 'A todo color' : 'Blanco y negro';
    $impresion_precio = $_GET['impresion_precio'] === 'con_precio' ? 'Con precio' : 'Sin precio';

    // Validaciones básicas
    $errores = [];
    if (empty($nombre)) $errores[] = "El nombre completo es obligatorio.";
    if (empty($correo) || !filter_var($correo, FILTER_VALIDATE_EMAIL)) $errores[] = "El correo electrónico es inválido.";
    if (empty($telefono)) $errores[] = "El teléfono es obligatorio.";
    if (empty($calle) || empty($numero) || empty($piso) || empty($puerta) || empty($codigo_postal)) {
        $errores[] = "La dirección de envío es incompleta.";
    }
    if (empty($fecha_recepcion)) $errores[] = "La fecha de recepción es obligatoria.";
    if ($numero_copias <= 0) $errores[] = "El número de copias debe ser al menos 1.";

    if (count($errores) == 0) {
        // Cálculo del costo total (asumiendo que ya tienes esta función definida)
        $paginas = 5;  // Asumimos un número de páginas ficticio para este ejemplo
        $fotos = 15;   // Asumimos un número de fotos ficticio
        $costoUnitario = obtenerCosto($paginas, $fotos, $resolucion, $impresion_color === 'A todo color' ? 'color' : 'bn');
        $costoTotal = $numero_copias * $costoUnitario;

        // Preparar la dirección de envío como un solo texto
        $direccion = "Calle: $calle, Número: $numero, Piso: $piso, Puerta: $puerta, Código Postal: $codigo_postal, País: $pais, Provincia: $provincia, Localidad: $localidad";

// Asignar a variables
$impresion_color_val = ($impresion_color === 'A todo color') ? 1 : 0;
$impresion_precio_val = ($impresion_precio === 'con_precio') ? 1 : 0;

// Insertar la solicitud en la base de datos
$stmt = $conn->prepare("INSERT INTO Solicitudes (Anuncio, Texto, Nombre, Email, Direccion, Telefono, Color, Copias, Resolucion, Fecha, IColor, IPrecio, Coste) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("issssssissdsd", 
                  $anuncio, 
                  $texto, 
                  $nombre, 
                  $correo, 
                  $direccion, 
                  $telefono, 
                  $color_portada, 
                  $numero_copias, 
                  $resolucion, 
                  $fecha_recepcion, 
                  $impresion_color_val,   // Usar la variable en lugar de la expresión
                  $impresion_precio_val,  // Usar la variable en lugar de la expresión
                  $costoTotal);

        if ($stmt->execute()) {
            echo "<div>
                    <h2>Confirmación de Solicitud</h2>
                    <p>Gracias por tu solicitud. Se ha registrado correctamente tu solicitud de impresión de álbum.</p>
                    <h4>Detalles de la solicitud:</h4>
                    <ul>
                        <li><strong>Nombre completo:</strong> $nombre</li>
                        <li><strong>Correo electrónico:</strong> $correo</li>
                        <li><strong>Teléfono:</strong> $telefono</li>
                        <li><strong>Dirección:</strong> $direccion</li>
                        <li><strong>Fecha de recepción:</strong> $fecha_recepcion</li>
                        <li><strong>Color de portada:</strong> $color_portada</li>
                        <li><strong>Número de copias:</strong> $numero_copias</li>
                        <li><strong>Resolución de fotos:</strong> $resolucion DPI</li>
                        <li><strong>Anuncio seleccionado:</strong> $anuncio</li>
                        <li><strong>Impresión a color:</strong> $impresion_color</li>
                        <li><strong>Impresión del precio:</strong> $impresion_precio</li>
                        <li><strong>Coste total:</strong> €" . number_format($costoTotal, 2) . "</li>
                    </ul>
                  </div>";
        } else {
            echo "<p>Error al registrar la solicitud. Por favor, intenta nuevamente más tarde.</p>";
        }

        $stmt->close();
    } else {
        // Mostrar los errores
        echo "<div class='titulospaginas3'><h2>Errores en la solicitud:</h2><ul>";
        foreach ($errores as $error) {
            echo "<li>$error</li>";
        }
        echo "</ul></div>";
    }
}

$conn->close();
?>

<form action="perfil.php" method="get">
    <input type="submit" value="Volver al perfil">
</form>

<?php include 'footer.php'; ?>
