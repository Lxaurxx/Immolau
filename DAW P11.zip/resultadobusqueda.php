<!-- 
 Página resultados de la búsqueda
-->
 
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'db.php'; ?>

<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Verifica si el usuario está logueado
$usuario_logueado = isset($_SESSION['usuario']);
?>

<body>
<?php include 'search.php'; ?>
<div class="titulospaginas3">
    <h2 class="titulospaginas3">Resultados de Búsqueda</h2>

   <!-- Mostrar los criterios de búsqueda seleccionados -->
   <?php
   // Captura de los datos introducidos por el usuario
   $tipoAnuncio = isset($_GET['tipo-anuncio']) ? htmlspecialchars($_GET['tipo-anuncio']) : '';
   $tipoVivienda = isset($_GET['tipo-vivienda']) ? htmlspecialchars($_GET['tipo-vivienda']) : '';
   $ciudad = isset($_GET['ciudad']) ? htmlspecialchars($_GET['ciudad']) : '';
   $pais = isset($_GET['pais']) ? htmlspecialchars($_GET['pais']) : '';
   $precio = isset($_GET['precio']) ? htmlspecialchars($_GET['precio']) : '';
   $fechaPublicacion = isset($_GET['fecha-publicacion']) ? htmlspecialchars($_GET['fecha-publicacion']) : '';

   // Construcción de la consulta SQL dinámica
$query = "SELECT a.IdAnuncio, a.Titulo, a.Precio, a.Ciudad, p.NomPais, a.FRegistro, f.Fichero 
FROM Anuncios a
LEFT JOIN Paises p ON a.Pais = p.IdPais
LEFT JOIN Fotos f ON a.IdAnuncio = f.Anuncio
WHERE 1=1";

if ($tipoAnuncio) {
$query .= " AND a.TAnuncio = $tipoAnuncio";
}
if ($tipoVivienda) {
$query .= " AND a.TVivienda = $tipoVivienda";
}
if ($ciudad) {
$query .= " AND LOWER(a.Ciudad) LIKE LOWER('%$ciudad%')";
}
if ($pais) {
$query .= " AND a.Pais = $pais";
}
if ($precio) {
$query .= " AND a.Precio <= $precio";
}
if ($fechaPublicacion) {
$query .= " AND DATE(a.FRegistro) = '$fechaPublicacion'";
}

$query .= " GROUP BY a.IdAnuncio"; // Para evitar duplicados por las fotos

$result = $conn->query($query);

   // Obtener nombre de "Tipo de Anuncio"
   if ($tipoAnuncio) {
       $sqlTipoAnuncio = "SELECT NomTAnuncio FROM TiposAnuncios WHERE IdTAnuncio = '$tipoAnuncio'";
       $resultTipoAnuncio = $conn->query($sqlTipoAnuncio);
       if ($resultTipoAnuncio->num_rows > 0) {
           $row = $resultTipoAnuncio->fetch_assoc();
           $tipoAnuncio = $row['NomTAnuncio']; // Nombre del tipo de anuncio
       }
   }

   // Obtener nombre de "Tipo de Vivienda"
   if ($tipoVivienda) {
       $sqlTipoVivienda = "SELECT NomTVivienda FROM TiposViviendas WHERE IdTVivienda = '$tipoVivienda'";
       $resultTipoVivienda = $conn->query($sqlTipoVivienda);
       if ($resultTipoVivienda->num_rows > 0) {
           $row = $resultTipoVivienda->fetch_assoc();
           $tipoVivienda = $row['NomTVivienda']; // Nombre del tipo de vivienda
       }
   }

   // Obtener nombre de "País"
   if ($pais) {
       $sqlPais = "SELECT NomPais FROM Paises WHERE IdPais = '$pais'";
       $resultPais = $conn->query($sqlPais);
       if ($resultPais->num_rows > 0) {
           $row = $resultPais->fetch_assoc();
           $pais = $row['NomPais']; // Nombre del país
       }
   }

   // Mostrar los criterios de búsqueda seleccionados
   echo "<h3>Criterios de búsqueda seleccionados</h3>";
   echo "<p><strong>Tipo de anuncio:</strong> " . ucfirst($tipoAnuncio ?: 'No especificado') . "</p>";
   echo "<p><strong>Tipo de vivienda:</strong> " . ucfirst($tipoVivienda ?: 'No especificado') . "</p>";
   echo "<p><strong>Ciudad:</strong> " . ucfirst($ciudad ?: 'No especificado') . "</p>";
   echo "<p><strong>País:</strong> " . ucfirst($pais ?: 'No especificado') . "</p>";
   echo "<p><strong>Precio máximo:</strong> " . ($precio ? ucfirst($precio) . " €" : 'No especificado') . "</p>";
   echo "<p><strong>Fecha de publicación:</strong> " . ucfirst($fechaPublicacion ?: 'No especificado') . "</p>";
   ?>
</div>
    <!-- Listado de resultados de búsqueda -->
    <ul class="formulario-centrado">
    <?php
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<li>';
            echo '<img src="' . ($row['Fichero'] ?: 'default.jpg') . '" alt="Foto del anuncio" width="350"><br>';
            echo '<strong>Título:</strong> ' . htmlspecialchars($row['Titulo']) . '<br>';
            echo '<strong>Fecha de publicación:</strong> ' . htmlspecialchars($row['FRegistro']) . '<br>';
            echo '<strong>Ciudad:</strong> ' . htmlspecialchars($row['Ciudad']) . '<br>';
            echo '<strong>País:</strong> ' . htmlspecialchars($row['NomPais']) . '<br>';
            echo '<strong>Precio:</strong> €' . htmlspecialchars($row['Precio']) . '<br>';
            echo '<a href="' . ($usuario_logueado ? 'anuncio.php?id=' . $row['IdAnuncio'] : 'errorbusqueda.php') . '">Ver detalles</a>';
            echo '</li><br><br>';
        }
    } else {
        echo "<p>No se encontraron resultados para los criterios especificados.</p>";
    }
    ?>
</ul>
<?php $conn->close(); ?>
    <?php include 'panel_anuncios.php'; ?>
    <?php include 'footer.php'; ?>
