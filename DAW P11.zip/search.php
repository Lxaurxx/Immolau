<div class="titulospaginas2">
        <div class="form-container">
            <form action="resultadobusqueda.php" method="get">
                <i class="fa fa-search"></i> Titulo: <input type="search" name="titulo">
                <input type="submit" value="Buscar">
            </form>
            <h3><a href="busqueda.php">Búsqueda avanzada</a></h3>
        </div>
    </div>