<!-- solicitar_folleto.php -->
<?php include 'head.php'; ?>
<?php include 'db.php'; ?>
<?php
// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    echo "Error: Debes iniciar sesión para ver tus anuncios.";
    exit();
}

// Obtener el ID del usuario de la sesión
$nomUsuario = $_SESSION['usuario'];

// Consultar el ID del usuario
$stmt = $conn->prepare("SELECT IdUsuario FROM Usuarios WHERE NomUsuario = ?");
$stmt->bind_param("s", $nomUsuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Error: Usuario no encontrado.";
    exit();
}

$row = $result->fetch_assoc();
$idUsuario = $row['IdUsuario'];

// Consultar los anuncios del usuario
$stmtAnuncios = $conn->prepare("SELECT IdAnuncio, Titulo FROM Anuncios WHERE Usuario = ?");
$stmtAnuncios->bind_param("i", $idUsuario);
$stmtAnuncios->execute();
$resultAnuncios = $stmtAnuncios->get_result();
?>

<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?>
<body>
<?php include 'search.php'; ?>
        
<div class="titulospaginas3">
    <h2>Solicitud de impresión de álbum</h2>
    <p>Rellena el formulario para solicitar tu folleto publicitario impreso. Por favor, asegúrate de completar todos los campos con la información correcta para que podamos procesar tu solicitud y enviar el folleto a tu dirección.</p>
</div>

<?php
// Definir la función de cálculo del costo del folleto
function obtenerCosto($paginas, $fotos, $resolucion, $tipo) {
    $costoBase = 12.00;
    $incrementoPaginas = 0;
    if ($paginas > 1 && $paginas <= 4) {
        $incrementoPaginas = 2.00 * ($paginas - 1);
    } elseif ($paginas >= 5 && $paginas <= 10) {
        $incrementoPaginas = 2.00 * 3 + 1.80 * ($paginas - 4); 
    } elseif ($paginas > 10) {
        $incrementoPaginas = 2.00 * 3 + 1.80 * 6 + 1.60 * ($paginas - 10);
    }

    $incrementoFotos = 0;
    if ($tipo === "color") {
        $incrementoFotos += 0.50 * $fotos;
    }

    if ($resolucion === "450-900") {
        $incrementoFotos += 0.20 * $fotos;
    }

    $costoTotal = $costoBase + $incrementoPaginas + $incrementoFotos;
    return number_format($costoTotal, 2);
}

// Procesar formulario de cálculo del costo si fue enviado
$costoTotal = null;
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['pages'], $_POST['photos'], $_POST['resolution'], $_POST['tipo_impresion'])) {
    $paginas = (int)$_POST['pages'];
    $fotos = (int)$_POST['photos'];
    $resolucion = $_POST['resolution'];
    $tipo = $_POST['tipo_impresion'];

    $costoTotal = obtenerCosto($paginas, $fotos, $resolucion, $tipo);
}
?>

<main class="formulario-contenedor">
    <div class="form-and-table">
        <div class="apariencia-tablas">
            <form id="print-form" action="" method="POST">
                <h1>Solicitar Álbum</h1>
                <label for="pages">Número de páginas:</label>
                <input type="number" id="pages" name="pages" min="1" required>
                
                <label for="photos">Número de fotos:</label>
                <input type="number" id="photos" name="photos" min="0" required><br><br>
            
                <label for="resolution">Resolución:</label>
                <select id="resolution" name="resolution" required>
                    <option value="150-300">150-300 dpi</option>
                    <option value="450-900">450-900 dpi</option>
                </select>
                
                <label for="tipo_impresion">Tipo de impresión:</label>
                <select id="tipo_impresion" name="tipo_impresion"required >
                    <option value="bn">Blanco y Negro</option>
                    <option value="color">Color</option>
                </select><br><br>
            
                <button type="submit" class="toggle-btn">Calcular</button><br><br>
            </form>

            <?php if ($costoTotal !== null): ?>
                <h2>Resultado del Cálculo del Costo</h2>
                <table>
                    <thead>
                        <tr><th>Páginas</th><th>Fotos</th><th>Resolución</th><th>Tipo de Impresión</th><th>Costo Total</th></tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?= htmlspecialchars($paginas) ?></td>
                            <td><?= htmlspecialchars($fotos) ?></td>
                            <td><?= htmlspecialchars($resolucion) ?></td>
                            <td><?= $tipo === 'bn' ? 'Blanco y Negro' : 'Color' ?></td>
                            <td><?= $costoTotal ?> €</td>
                        </tr>
                    </tbody>
                </table>
            <?php endif; ?>

            <br>
        </div>

        <!-- Tarifa de ejemplo -->
        <div class="apariencia-tablas"><h1>Tarifas</h1>
            <table>
                <thead>
                    <tr>
                        <th>Concepto</th>
                        <th>Coste de procesamiento y envío</th>
                        <th>&lt; 5 páginas</th>
                        <th>Entre 5 y 10 páginas</th>
                        <th>&gt; 10 páginas</th>
                        <th>Blanco y negro</th>
                        <th>Color</th>
                        <th>Resolución &lt;= 300 dpi</th>
                        <th>Resolución > 300 dpi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Tarifas</td>
                        <td>10€</td>
                        <td>2€ por página</td>
                        <td>1.8€ por página</td>
                        <td>1.6€ por página</td>
                        <td>0€</td>
                        <td>0.5€ por foto</td>
                        <td>0€ por foto</td>
                        <td>0.2€ por foto</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

        <form action="respuestasolicitarfolleto.php" method="get" class="formulario"> 
            <h2>Formulario de Solicitud </h2>
            <p> Rellena el siguiente formulario para poder procesar tu solicitud de impresión de álbum </p>
            <p>Los campos de marcados con asterisco (*) son obligatorios. </p><br>
            <p><label for="nombre">Nombre completo*:</label> <input type="text" name="nombre" id="nombre" maxlength="200" ></p>
            <p><label for="correo">Correo electrónico*:</label> <input type="email" name="correo" id="correo" maxlength="200"></p>
            <p><label for="texto"> Texto adicional:</label>
            <textarea name="texto" id="texto" maxlength="4000" rows="3" cols="40"></textarea></p>

            <fieldset>
                <legend>Dirección de envío*</legend>
                <p>
                    <label for="calle">Calle*:</label>
                    <input type="text" id="calle" name="calle">
                </p>
                <p>
                    <label for="numero">Número*:</label>
                    <input type="number" id="numero" name="numero" size="3"> 
                </p>
                <p>
                    <label for="piso">Piso*:</label>
                    <input type="text" id="piso" name="piso" size="6">
                </p>
                <p>
                    <label for="puerta">Puerta*:</label>
                    <input type="text" id="puerta" name="puerta" size="6">
                </p>
                <p>
                    <label for="codigo_postal">Código Postal*:</label>
                    <input type="number" id="codigo_postal" name="codigo_postal" size="6">
                </p>
                <p>
                    <label for="pais">País*:</label>
                    <select id="pais" name="pais">
                        <option value="">Seleccione un país</option>
                        <option value="España">España</option>
                        <option value="Francia">Francia</option>
                        <option value="Italia">Italia</option>
                        <option value="Alemania">Alemania</option>
                        <option value="Reino Unido">Reino Unido</option>
                        <option value="Portugal">Portugal</option>
                    </select>
                </p>
                <p>
                    <label for="provincia">Provincia*:</label>
                    <select id="provincia" name="provincia">
                        <option value="">Seleccione una provincia</option>
                        <option value="Madrid">Madrid</option>
                        <option value="Cataluña">Barcelona</option>
                        <option value="Andalucía">Alicante</option>
                        <option value="Valencia">Valencia</option>
                        <option value="País Vasco">Bilbao</option>
                        <option value="Galicia">Coruña</option>
                    </select>
                </p>
                <p>
                    <label for="localidad">Localidad*:</label>
                    <select id="localidad" name="localidad">
                        <option value="">Seleccione una localidad</option>
                        <option value="Madrid">Madrid</option>
                        <option value="Barcelona">Barcelona</option>
                        <option value="Sevilla">Sevilla</option>
                        <option value="Valencia">Valencia</option>
                        <option value="Bilbao">Bilbao</option>
                        <option value="Coruña">A Coruña</option>
                    </select>
                </p>
            </fieldset>
            <p><label for="Telefono">Teléfono:</label> <input type="tel" name="Telefono" id="Telefono"></p>

   <p><label for="color">Color portada:</label> <input type="color" name="color" id="color"></p>
   
   <p>
    <label for="numero_copias">Número de copias:</label>
    <input type="number" id="numero_copias" name="numero_copias" min="1" max="99" value="1">
   </p>  
   

   <!-- <p> <label for="Resolucion">Resolución de impresión (DPI):</label>  
         <input type="range" name="Resolucion" id="Resolucion" min="150" max="900" step="150" value="150" onchange="document.getElementById('valor').value=value"><output id="valor"></output></p>  MANERA VISTA EN CLASE DE TEORÍA
   -->  
                  <p>
            <label for="resolucion">Resolución de las fotos (DPI):</label>
            <select id="resolucion" name="resolucion">
                <option value="150-300" selected>150-300</option>
                <option value="450-900">450-900</option>

            </select>
        </p>

    
   <p>
   <label for="anuncio">Anuncio:</label>
            <select id="anuncio" name="anuncio">
                <option value="">Selecciona un anuncio</option>
                <?php while ($anuncio = $resultAnuncios->fetch_assoc()): ?>
                    <option value="<?= $anuncio['IdAnuncio'] ?>"><?= htmlspecialchars($anuncio['Titulo']) ?></option>
                <?php endwhile; ?>
            </select>
    </p>

    <p>
        <label for="fecha_recepcion">Fecha de recepción:</label>
        <input type="date" id="fecha_recepcion" name="fecha_recepcion">
    </p>

    <p>
        <label>¿Impresión a color?:</label>
        <input type="radio" id="blanco_negro" name="impresion_color" value="blanco_negro"> <!-- radio buttons solo permite la marca de una casilla -->
        <label for="blanco_negro">Blanco y negro</label>
        <input type="radio" id="atodocolor" name="impresion_color" value="atodocolor" checked> <!-- marco una casilla por defecto-->
        <label for="atodocolor">A todo color</label>
    </p>
    
    <p>
        <label>¿Impresión del precio?:</label>
        <input type="radio" id="con_precio" name="impresion_precio" value="con_precio" checked> <!-- marco una casilla por defecto-->
        <label for="con_precio">Con precio</label>
        <input type="radio" id="sin_precio" name="impresion_precio" value="sin_precio">
        <label for="sin_precio">Sin precio</label>
    </p>

<input type="submit" value="Solicitar">

</form>
    </main>
    <?php
// Cerrar las conexiones
$stmtAnuncios->close();
$stmt->close();
$conn->close();
?>
    <?php include 'footer.php'; ?>
