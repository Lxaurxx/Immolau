<?php
function obtenerCosto($paginas, $fotos, $resolucion, $tipo) {
    $costoBase = 12.00; // Costo inicial para la primera página y 3 fotos
    
    // Incremento por páginas según el número de páginas
    $incrementoPaginas = 0;
    if ($paginas > 1 && $paginas <= 4) {
        $incrementoPaginas = 2.00 * ($paginas - 1);
    } elseif ($paginas >= 5 && $paginas <= 10) {
        $incrementoPaginas = 2.00 * 3 + 1.80 * ($paginas - 4); 
    } elseif ($paginas > 10) {
        $incrementoPaginas = 2.00 * 3 + 1.80 * 6 + 1.60 * ($paginas - 10);
    }

    // Incremento por fotos según tipo y resolución
    $incrementoFotos = 0;

    // Si es color, sumamos 0.50€ por cada foto
    if ($tipo === "color") {
        $incrementoFotos += 0.50 * $fotos;
    }

    // Si la resolución es de 450-900 dpi, sumamos 0.20€ por foto
    if ($resolucion === "450-900") {
        $incrementoFotos += 0.20 * $fotos;
    }

    // Sumar el costo base, incremento por páginas y por fotos
    $costoTotal = $costoBase + $incrementoPaginas + $incrementoFotos;

    return number_format($costoTotal, 2); // Formato con 2 decimales
}
?>
