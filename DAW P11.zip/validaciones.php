<?php
function validarDatosAnuncio($datos) {
    $errores = [];

    // Validar título
    if (empty(trim($datos['titulo']))) {
        $errores[] = "El título es obligatorio.";
    }

    // Validar descripción
    if (empty(trim($datos['descripcion']))) {
        $errores[] = "La descripción es obligatoria.";
    }

    // Validar tipo de anuncio
    if (!is_numeric($datos['tipo_anuncio']) || $datos['tipo_anuncio'] <= 0) {
        $errores[] = "Tipo de anuncio inválido.";
    }

    // Validar tipo de vivienda
    if (!is_numeric($datos['tipo_vivienda']) || $datos['tipo_vivienda'] <= 0) {
        $errores[] = "Tipo de vivienda inválido.";
    }

    // Validar precio
    if (!is_numeric($datos['precio']) || $datos['precio'] < 0) {
        $errores[] = "El precio debe ser un número positivo.";
    }

    // Validar superficie
    if (!is_numeric($datos['superficie']) || $datos['superficie'] <= 0) {
        $errores[] = "La superficie debe ser un número positivo.";
    }

    // Validar ciudad
    if (empty(trim($datos['ciudad']))) {
        $errores[] = "La ciudad es obligatoria.";
    }

    // Validar país
    if (!is_numeric($datos['pais']) || $datos['pais'] <= 0) {
        $errores[] = "País inválido.";
    }

    // Validar número de habitaciones
    if (!is_numeric($datos['nhabitaciones']) || $datos['nhabitaciones'] < 0) {
        $errores[] = "El número de habitaciones debe ser un valor no negativo.";
    }

    // Validar número de baños
    if (!is_numeric($datos['nbanyos']) || $datos['nbanyos'] < 0) {
        $errores[] = "El número de baños debe ser un valor no negativo.";
    }

    // Validar planta
    if (!is_numeric($datos['planta']) || $datos['planta'] < 0) {
        $errores[] = "La planta debe ser un valor no negativo.";
    }

    // Validar año de construcción
    $currentYear = date('Y');
    if (!is_numeric($datos['anyo']) || $datos['anyo'] < 1900 || $datos['anyo'] > $currentYear) {
        $errores[] = "El año de construcción debe estar entre 1900 y $currentYear.";
    }

    return $errores;
}
?>

