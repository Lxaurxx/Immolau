<?php
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'db.php';


?>

<body>
<?php include 'search.php'; ?>

<div class="anuncio">
    <h1 class="titulospaginas3"> Detalle del Anuncio</h1>

    <?php
    // Captura el parámetro 'id' de la URL
    $idAnuncio = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Usa 0 como valor predeterminado

    // Obtener el nombre de usuario de la sesión
    $nombreUsuario = $_SESSION['usuario'];

    // Consulta para obtener el ID del usuario a partir del nombre
    $sqlUsuario = "SELECT IdUsuario FROM Usuarios WHERE NomUsuario = ?";
    $stmtUsuario = $conn->prepare($sqlUsuario);
    $stmtUsuario->bind_param("s", $nombreUsuario);
    $stmtUsuario->execute();
    $stmtUsuario->bind_result($idUsuario);
    $stmtUsuario->fetch();
    $stmtUsuario->close();

    if (!$idUsuario) {
        echo "Usuario no encontrado.";
        exit; // Si no se encuentra el usuario, detenemos la ejecución
    }

    // Consulta principal para obtener la información del anuncio
    $queryAnuncio = "
        SELECT a.Titulo, a.Precio, a.Texto, a.Ciudad, p.NomPais AS Pais, a.Superficie, 
               a.Nhabitaciones, a.Nbanyos, a.Planta, a.Anyo, a.FRegistro, 
               t.NomTAnuncio AS TipoAnuncio, v.NomTVivienda AS TipoVivienda, 
               u.NomUsuario AS Usuario
        FROM Anuncios a
        LEFT JOIN Paises p ON a.Pais = p.IdPais
        LEFT JOIN TiposAnuncios t ON a.TAnuncio = t.IdTAnuncio
        LEFT JOIN TiposViviendas v ON a.TVivienda = v.IdTVivienda
        LEFT JOIN Usuarios u ON a.Usuario = u.IdUsuario
        WHERE a.IdAnuncio = ? AND a.Usuario = ?"; // Aseguramos que el anuncio pertenece al usuario logueado

    $stmt = $conn->prepare($queryAnuncio);
    $stmt->bind_param("ii", $idAnuncio, $idUsuario); // Pasamos el ID del anuncio y el ID del usuario logueado
    $stmt->execute();
    $resultAnuncio = $stmt->get_result();

    if ($resultAnuncio->num_rows > 0) {
        $anuncio = $resultAnuncio->fetch_assoc();

        // Consulta para obtener las fotos del anuncio
        $queryFotos = "SELECT Fichero, Alternativo FROM Fotos WHERE Anuncio = ? ORDER BY IdFoto ASC";
        $stmtFotos = $conn->prepare($queryFotos);
        $stmtFotos->bind_param("i", $idAnuncio);
        $stmtFotos->execute();
        $resultFotos = $stmtFotos->get_result();

        $fotos = [];
        while ($foto = $resultFotos->fetch_assoc()) {
            $fotos[] = $foto;
        }

        // Determina la foto principal (primera de la lista)
        $fotoPrincipal = count($fotos) > 0 ? $fotos[0] : null;

        // Muestra detalles del anuncio
        echo "<h2>Tipo de Anuncio: {$anuncio['TipoAnuncio']}</h2>";
        echo "<h3>Tipo de Vivienda: {$anuncio['TipoVivienda']}</h3>";

        // Muestra la foto principal si existe
        if ($fotoPrincipal) {
            echo "<div><img src='{$fotoPrincipal['Fichero']}' alt='{$fotoPrincipal['Alternativo']}' width='600'></div>";
        }

        echo "<h2>{$anuncio['Titulo']}</h2>";
        echo "<p>{$anuncio['Texto']}</p>";
        echo "<p><strong>Fecha:</strong> {$anuncio['FRegistro']}</p>";
        echo "<p><strong>Ciudad:</strong> {$anuncio['Ciudad']}</p>";
        echo "<p><strong>País:</strong> {$anuncio['Pais']}</p>";
        echo "<p><strong>Precio:</strong> {$anuncio['Precio']} €</p>";
        echo "<h3>Características:</h3>";
        echo "<ul>";
        echo "<li>Superficie: {$anuncio['Superficie']} m²</li>";
        echo "<li>Habitaciones: {$anuncio['Nhabitaciones']}</li>";
        echo "<li>Baños: {$anuncio['Nbanyos']}</li>";
        echo "<li>Planta: {$anuncio['Planta']}</li>";
        echo "<li>Año: {$anuncio['Anyo']}</li>";
        echo "</ul>";

        // Muestra las miniaturas de las fotos
        echo "<h3><a href='ver-fotos-priv.php?id={$idAnuncio}'>Galería de Fotos</a></h3>";
        echo "<div>";
        foreach ($fotos as $foto) {
            echo "<img src='{$foto['Fichero']}' alt='{$foto['Alternativo']}' width='150'>";
        }
        echo "</div>";

    } else {
        echo "<p>Anuncio no encontrado o no pertenece a este usuario.</p>";
    }

    // Cierra las conexiones
    $stmt->close();
    $conn->close();
    ?>
<h3><a href="ver-mensajes.php?id=<?php echo $idAnuncio; ?>">Ver mensajes recibidos</a></h3>
<h3><a href="modificaranuncio.php?id=<?php echo $idAnuncio; ?>">Modificar anuncio</a></h3>
<h3><a href="anadir-foto.php?id=<?php echo $idAnuncio; ?>">Añadir foto a este anuncio</a></h3>
<h3><a href="respuesta-eliminar-anuncio.php?id=<?php echo $idAnuncio; ?>" style="color: red;">Eliminar anuncio</a></h3>

</div>

<?php include 'footer.php'; ?>