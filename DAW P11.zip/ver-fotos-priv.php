<!-- 
 Página fotos anuncio
-->
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?> 
<?php include 'db.php';?> 

<body>
<?php include 'search.php'; ?>
<?php

$usuarioLogueado = $_SESSION['usuario']; // El nombre del usuario logueado

// Obtener el ID del usuario a partir del nombre de usuario
$queryUsuarioId = "SELECT IdUsuario FROM Usuarios WHERE NomUsuario = ?";
$stmtUsuarioId = $conn->prepare($queryUsuarioId);
$stmtUsuarioId->bind_param("s", $usuarioLogueado);
$stmtUsuarioId->execute();
$resultUsuarioId = $stmtUsuarioId->get_result();

if ($resultUsuarioId->num_rows > 0) {
    $usuario = $resultUsuarioId->fetch_assoc();
    $idUsuario = $usuario['IdUsuario']; // El ID del usuario logueado
} else {
    echo "<p>No se pudo obtener el ID del usuario.</p>";
    exit();
}
// Obtener el ID del anuncio desde la URL
$idAnuncio = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Obtén el ID del anuncio

// Verificar que el usuario logueado sea el propietario del anuncio
$queryFotos = "
    SELECT f.IdFoto, f.Fichero, f.Alternativo
    FROM Fotos f
    JOIN Anuncios a ON f.Anuncio = a.IdAnuncio
    WHERE a.IdAnuncio = ? AND a.Usuario = ?";
$stmtFotos = $conn->prepare($queryFotos);
$stmtFotos->bind_param("ii", $idAnuncio, $idUsuario); // Usamos el ID del usuario
$stmtFotos->execute();
$resultFotos = $stmtFotos->get_result();

include 'galeria-fotos.php'; 

// Cerrar las conexiones
$stmtFotos->close();
$stmtUsuarioId->close();
$conn->close();
?>

<?php include 'footer.php'; ?>