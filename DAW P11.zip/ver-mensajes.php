<?php
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'db.php';

// Obtener el ID del anuncio desde la URL
$idAnuncio = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Usamos 0 como valor predeterminado

// Obtener el nombre de usuario de la sesión
$nombreUsuario = $_SESSION['usuario'];

// Consulta para obtener el ID del usuario a partir del nombre de usuario
$sqlUsuario = "SELECT IdUsuario FROM Usuarios WHERE NomUsuario = ?";
$stmtUsuario = $conn->prepare($sqlUsuario);
$stmtUsuario->bind_param("s", $nombreUsuario);
$stmtUsuario->execute();
$stmtUsuario->bind_result($idUsuario);
$stmtUsuario->fetch();
$stmtUsuario->close();

if (!$idUsuario) {
    echo "Usuario no encontrado.";
    exit; // Si no se encuentra el usuario, detenemos la ejecución
}

// Consulta para obtener los mensajes recibidos para este anuncio
$queryMensajes = "
    SELECT m.Texto, m.FRegistro, tm.NomTMensaje AS Tipo, u.NomUsuario AS Emisor
    FROM Mensajes m
    JOIN TiposMensajes tm ON m.TMensaje = tm.IdTMensaje
    JOIN Usuarios u ON m.UsuarioOrigen = u.IdUsuario
    WHERE m.Anuncio = ? AND m.UsuarioDestino = ?
    ORDER BY m.FRegistro DESC"; // Ordenar por la fecha de registro (más recientes primero)

$stmtMensajes = $conn->prepare($queryMensajes);
$stmtMensajes->bind_param("ii", $idAnuncio, $idUsuario); // Anuncio y UsuarioDestino
$stmtMensajes->execute();
$mensajesRecibidos = $stmtMensajes->get_result();

// Mostrar el número total de mensajes recibidos
$totalRecibidos = $mensajesRecibidos->num_rows;
echo "<h1 class='conBorde'>Mensajes recibidos: {$totalRecibidos}</h1>";

if ($totalRecibidos > 0) {
    // Mostrar los mensajes
    while ($mensaje = $mensajesRecibidos->fetch_assoc()) {
        echo "<p><strong>Tipo:</strong> " . htmlspecialchars($mensaje['Tipo']) . "</p>";
        echo "<p><strong>Texto:</strong> " . htmlspecialchars($mensaje['Texto']) . "</p>";
        echo "<p><strong>Fecha:</strong> " . htmlspecialchars($mensaje['FRegistro']) . "</p>";
        echo "<p><strong>Emisor:</strong> " . htmlspecialchars($mensaje['Emisor']) . "</p>";
        echo "<hr>";
    }
} else {
    echo "<p>No tienes mensajes recibidos para este anuncio.</p>";
}

// Cerrar la conexión
$stmtMensajes->close();
$conn->close();
?>

<?php include 'footer.php'; ?>
