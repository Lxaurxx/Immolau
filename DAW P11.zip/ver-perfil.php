<?php
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'db.php';

// Obtener el nombre de usuario desde la URL
$nombreUsuario = isset($_GET['usuario']) ? $_GET['usuario'] : '';

// Verificar que el nombre de usuario no esté vacío
if (empty($nombreUsuario)) {
    echo "<p>Usuario no válido.</p>";
    exit;
}

// Consulta para obtener la información del usuario
$sqlUsuario = "SELECT IdUsuario, NomUsuario, Foto, FRegistro FROM Usuarios WHERE NomUsuario = ?";
$stmtUsuario = $conn->prepare($sqlUsuario);
$stmtUsuario->bind_param("s", $nombreUsuario);
$stmtUsuario->execute();
$resultUsuario = $stmtUsuario->get_result();

if ($resultUsuario->num_rows > 0) {
    $usuario = $resultUsuario->fetch_assoc();

    // Mostrar información básica del usuario
    echo "<h1>Perfil de Usuario: {$usuario['NomUsuario']}</h1>";
    echo "<p><strong>Fecha de incorporación:</strong> " . date("d/m/Y", strtotime($usuario['FRegistro'])) . "</p>";

    // Mostrar la foto del perfil si existe
    if (!empty($usuario['Foto'])) {
        echo "<img src='{$usuario['Foto']}' alt='Foto de perfil de {$usuario['NomUsuario']}' width='150'>";
    } else {
        echo "<img src='default-avatar.jpg' alt='Foto de perfil predeterminada' width='150'>";
    }

    // Mostrar los anuncios del usuario
    echo "<h3>Mis Anuncios:</h3>";
    
    // Consulta para obtener los anuncios del usuario
    $sqlAnuncios = "SELECT IdAnuncio, Titulo, Precio, Ciudad, FRegistro FROM Anuncios WHERE Usuario = ? ORDER BY FRegistro DESC";
    $stmtAnuncios = $conn->prepare($sqlAnuncios);
    $stmtAnuncios->bind_param("i", $usuario['IdUsuario']);
    $stmtAnuncios->execute();
    $resultAnuncios = $stmtAnuncios->get_result();

    if ($resultAnuncios->num_rows > 0) {
        echo "<ul>";
        while ($anuncio = $resultAnuncios->fetch_assoc()) {
            echo "<li><a href='anuncio.php?id={$anuncio['IdAnuncio']}'>{$anuncio['Titulo']}</a> - {$anuncio['Ciudad']} - {$anuncio['Precio']} € - " . date("d/m/Y", strtotime($anuncio['FRegistro'])) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p>No tiene anuncios publicados.</p>";
    }

    // Cierra las conexiones
    $stmtAnuncios->close();
} else {
    echo "<p>Usuario no encontrado.</p>";
}

// Cierra la conexión de usuario
$stmtUsuario->close();
$conn->close();
?>

<?php include 'footer.php'; ?>
