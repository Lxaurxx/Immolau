function obtenerCosto(paginas, fotos, resolucion, tipo) {
    let costoBase = 12.00; // Costo inicial para la primera página y 3 fotos
    
    // Incremento por páginas según el número de páginas
    let incrementoPaginas = 0;
    if (paginas > 1 && paginas <= 4) {
        incrementoPaginas = 2.00 * (paginas - 1);
    } else if (paginas >= 5 && paginas <= 10) {
        incrementoPaginas = 2.00 * 3 + 1.80 * (paginas - 4); 
    } else if (paginas > 10) {
        incrementoPaginas = 2.00 * 3 + 1.80 * 6 + 1.60 * (paginas - 10);
    }
    
    // Incremento por fotos según tipo y resolución
    let incrementoFotos = 0;

    // Si es color, sumamos 0.50€ por cada foto (sin incluir las primeras 3)
    if (tipo === "color") {
        incrementoFotos += 0.50 * fotos;
    }

    // Si la resolución es de 450-900 dpi, sumamos 0.20€ por foto
    if (resolucion === "450-900") {
        incrementoFotos += 0.20 * fotos;
    }

    // Sumamos el costo base, el incremento por páginas y el incremento por fotos
    const costoTotal = costoBase + incrementoPaginas + incrementoFotos;

    return costoTotal.toFixed(2);  // Redondeamos a 2 decimales
}


// Función para crear la tabla de resultados del formulario
function crearTabla(paginas, fotos, resolucion, tipo) {
    const contenedorTabla = document.getElementById('tabla-container');
    contenedorTabla.innerHTML = ''; // Limpiar tabla anterior

    const tabla = document.createElement('table');
    const encabezado = document.createElement('thead');
    const cuerpoTabla = document.createElement('tbody');

    const encabezadoFila = document.createElement('tr');
    ['Páginas', 'Fotos', 'Resolución', 'Tipo de Impresión', 'Costo Total'].forEach(texto => {
        const th = document.createElement('th');
        th.textContent = texto;
        encabezadoFila.appendChild(th);
    });
    encabezado.appendChild(encabezadoFila);
    tabla.appendChild(encabezado);

    const fila = document.createElement('tr');
    [paginas, fotos, resolucion, (tipo === 'bn' ? 'Blanco y Negro' : 'Color'), obtenerCosto(paginas, fotos, resolucion, tipo) + ' €'].forEach(texto => {
        const td = document.createElement('td');
        td.textContent = texto;
        fila.appendChild(td);
    });

    cuerpoTabla.appendChild(fila);
    tabla.appendChild(cuerpoTabla);
    contenedorTabla.appendChild(tabla);
}

// Mostrar u ocultar la tabla precalculada
document.getElementById('toggle-cost-table').addEventListener('click', function(event) {
    event.preventDefault(); // Evitar el comportamiento por defecto del botón

    const tablaContainer = document.getElementById('tabla-container');
    const toggleButton = document.getElementById('toggle-cost-table');

    // Alternar la clase 'hidden'
    if (tablaContainer.classList.contains('hidden')) {
        tablaContainer.classList.remove('hidden');
        toggleButton.textContent = 'Ocultar tabla de costes precalculada';
    } else {
        tablaContainer.classList.add('hidden');
        toggleButton.textContent = 'Mostrar tabla de costes precalculada';
    }
});

// Manejo del formulario y validaciones
document.getElementById('print-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const paginas = parseInt(document.getElementById('pages').value);
    const fotos = parseInt(document.getElementById('photos').value);
    const resolucion = document.getElementById('resolution').value;
    const tipo = document.getElementById('tipo_impresion').value;

    // Verifica si los valores ingresados son válidos
    if (paginas > 0 && fotos >= 0) {
        crearTabla(paginas, fotos, resolucion, tipo);

        // Mostrar la tabla de costos siempre que se calcule
        const tablaContainer = document.getElementById('tabla-container');
        tablaContainer.classList.remove('hidden'); // Asegúrate de que la tabla esté visible

        // Cambiar el texto del botón de alternar
        document.getElementById('toggle-cost-table').textContent = 'Ocultar tabla de costes precalculada';
    } else {
        document.getElementById('error-message').textContent = 'Los valores ingresados no son válidos.';
    }
});
