// Escuchamos el evento de enviar el formulario de register
document.addEventListener("DOMContentLoaded", function() { 
    document.getElementById("registerForm").addEventListener("submit", function(event) {

        // Limpiar mensajes de error previos y estilos
        const campos = ['username', 'password', 'password2', 'email', 'birthdate', 'sexo'];
        campos.forEach(campo => {
            document.getElementById(campo).classList.remove('input-error');
            document.querySelector(`label[for="${campo}"]`).classList.remove('label-error');
        });
        document.querySelectorAll('.mensaje-error').forEach(function(errorMsg) {
            errorMsg.textContent = '';
        });
        
        let isValid = true;
        
        // Obtener valores de los campos
        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value.trim();
        const password2 = document.getElementById("password2").value.trim();
        const email = document.getElementById("email").value.trim();
        const birthdate = document.getElementById("birthdate").value;
        const sexo = document.getElementById("sexo").value;

        // Validación del nombre de usuario
        function validarUsername(username) {
            // Verificar longitud del username
            if (username.length < 3 || username.length > 15) return false;

            // Verificar que comience con una letra
            const primerCaracter = username.charAt(0); // Obtener el primer carácter
            const esLetra = (primerCaracter >= 'A' && primerCaracter <= 'Z') || (primerCaracter >= 'a' && primerCaracter <= 'z');
            if (!esLetra) return false; // Si no es una letra, retorna false

            // Verificar que solo contenga letras y números
            for (let i = 0; i < username.length; i++) {
            const char = username[i];
            if (!((char >= 'A' && char <= 'Z') || (char >= 'a' && char <= 'z') || (char >= '0' && char <= '9'))) {
            return false; // Solo permite letras y números
          }
        }
        return true; // Si pasa todas las verificaciones, retorna true
    }

        // Validación al enviar el formulario
        if (!validarUsername(username)) {
        document.getElementById('error-username').textContent = 'El nombre de usuario debe contener entre 3 y 15 caracteres, y solo puede contener letras y números';
        document.getElementById('username').classList.add('input-error');
        document.querySelector('label[for="username"]').classList.add('label-error');
        isValid = false; // Indica que el formulario no es válido
    }


        // Validación de la contraseña
        function validarPassword(password) {
            if (password.length < 6 || password.length > 15) return false;
            let tieneMayuscula = false;
            let tieneMinuscula = false;
            let tieneNumero = false;
            for (let i = 0; i < password.length; i++) {
                const char = password[i];
                if (char >= 'A' && char <= 'Z') tieneMayuscula = true;
                else if (char >= 'a' && char <= 'z') tieneMinuscula = true;
                else if (char >= '0' && char <= '9') tieneNumero = true;
                else if (char !== '-' && char !== '_') return false; // Solo se permite guion y guion bajo
            }
            return tieneMayuscula && tieneMinuscula && tieneNumero;
        }

        if (!validarPassword(password)) {
            document.getElementById('error-password').textContent = 'La contraseña debe contener al menos 1 mayúscula, 1 minúscula, 1 número y debe contener entre 6 y 15 caracteres';
            document.getElementById('password').classList.add('input-error');
            document.querySelector('label[for="password"]').classList.add('label-error');
            isValid = false;
        }

        // Verificar si las contraseñas coinciden
        if (password !== password2) {
            document.getElementById('error-password2').textContent = 'Las contraseñas no coinciden';
            document.getElementById('password2').classList.add('input-error');
            document.querySelector('label[for="password2"]').classList.add('label-error');
            isValid = false;
        }

        // Validación del email
    function validarEmail(email) {
    if (email.length > 254) return false;

    const [localPart, domain] = email.split('@');
    if (!localPart || !domain || localPart.length > 64 || domain.length > 255) return false;

    // Validar la parte local
    for (let i = 0; i < localPart.length; i++) {
        const char = localPart[i];
        if (!(
            (char >= 'A' && char <= 'Z') || (char >= 'a' && char <= 'z') || 
            (char >= '0' && char <= '9') || "!#$%&'*+-/=?^_`{|}~.".includes(char)
        )) {
            return false;
        }
    }
    if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) return false;

    // Validar la parte de dominio
    const subdomains = domain.split('.');
    
    // Verificar que hay al menos un subdominio y un TLD (como en "gmail.com")
    if (subdomains.length < 2) return false;

    if (subdomains.some(subdomain => subdomain.length > 63 || subdomain.length === 0)) return false;

    for (let subdomain of subdomains) {
        for (let i = 0; i < subdomain.length; i++) {
            const char = subdomain[i];
            if (!((char >= 'A' && char <= 'Z') || (char >= 'a' && char <= 'z') || 
                (char >= '0' && char <= '9') || char === '-')) {
                return false;
            }
        }

        // Asegurarse de que no empiece ni termine con un guion
        if (subdomain.startsWith('-') || subdomain.endsWith('-')) return false;
    }

    return true;
}

        if (!validarEmail(email)) {
            document.getElementById('error-email').textContent = 'El correo electrónico no es válido. Formato (example@example.com)';
            document.getElementById('email').classList.add('input-error');
            document.querySelector('label[for="email"]').classList.add('label-error');
            isValid = false;
        }

        // Validación de la fecha de nacimiento
        function validarFormatoFecha(birthdate) {
            const partes = birthdate.split('/');
            if (partes.length !== 3) return false;
        
            const [year, month, day] = partes.map(Number);
        
            // Validar que el año tenga 4 dígitos
            if (isNaN(year) || year.toString().length !== 4 || year <= 0) return false;
        
            // Validar que el mes esté entre 1 y 12
            if (isNaN(month) || month < 1 || month > 12) return false;
        
            // Validar que el día sea válido para el mes dado
            const diasPorMes = [31, (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        
            if (isNaN(day) || day < 1 || day > diasPorMes[month - 1]) return false;
        
            return true;
        }

        function validarMayorEdad(birthdate) {
            const [year, month, day] = birthdate.split('/').map(Number);
            const birthDate = new Date(year, month - 1, day);
            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();

            const monthDiff = today.getMonth() - birthDate.getMonth();
            const dayDiff = today.getDate() - birthDate.getDate();
            if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) age--;

            return age >= 18;
        }

        if (!validarFormatoFecha(birthdate)) {
            document.getElementById('error-birthdate').textContent = 'Formato de fecha no válido. Debe ser YYYY/MM/DD';
            document.getElementById('birthdate').classList.add('input-error');
            document.querySelector('label[for="birthdate"]').classList.add('label-error');
            isValid = false;
        } else if (!validarMayorEdad(birthdate)) {
            document.getElementById('error-birthdate').textContent = 'Debes ser mayor de 18 años para registrarte';
            document.getElementById('birthdate').classList.add('input-error');
            document.querySelector('label[for="birthdate"]').classList.add('label-error');
            isValid = false;
        }

        // Validación del sexo (debe ser seleccionado)
        if (sexo === "") {
            document.getElementById('error-sexo').textContent = 'Debes seleccionar un valor';
            document.querySelector('label[for="sexo"]').classList.add('label-error');
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault();
        }
    });
});


// Escuchamos el evento de enviar el formulario de login
document.getElementById('loginForm').addEventListener('submit', function(event) {
    // Obtenemos los valores de los campos de usuario y contraseña
    const usuario = document.getElementById('usuario').value.trim();
    const contra = document.getElementById('contra').value.trim();

    // Validamos que ambos campos tengan contenido, evitando solo espacios o tabuladores
    if (usuario === "" || contra === "") {
        // Si alguno de los campos es inválido, mostramos una alerta y prevenimos el envío
        document.getElementById('error-login').textContent = 'Por favor, rellena ambos campos correctamente'
        document.getElementById('usuario').classList.add('input-error');
        document.getElementById('contra').classList.add('input-error');
        event.preventDefault();  // Evita el envío del formulario
    }
});
