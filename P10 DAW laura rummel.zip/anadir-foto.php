<?php
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'db.php';


// Obtenemos el ID del anuncio desde la URL, si existe
$idAnuncioSeleccionado = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// Consulta a la base de datos para obtener los anuncios existentes
$query = "SELECT IdAnuncio, Titulo FROM Anuncios";
$result = $conn->query($query);

$anuncios = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $anuncios[$row['IdAnuncio']] = $row['Titulo'];
    }
}

// Validamos si el ID del anuncio seleccionado es válido
$anuncioValido = $idAnuncioSeleccionado > 0 && isset($anuncios[$idAnuncioSeleccionado]);
?>



<main>
<?php include 'search.php'; ?>
<h1 class="titulospaginas3">Añadir foto a anuncio</h1>

<form action="respuesta-anadir-foto.php?id=<?php echo $idAnuncioSeleccionado; ?>" method="post" enctype="multipart/form-data" class="formulario-centrado">
    <!-- Campo de selección de anuncio -->
    <label for="anuncio">Anuncio:</label><br>

    <?php if ($anuncioValido): ?>
        <!-- Muestra el anuncio preseleccionado como texto -->
        <p><?php echo htmlspecialchars($anuncios[$idAnuncioSeleccionado]); ?></p>
        <!-- Campo oculto para enviar el ID del anuncio -->
        <input type="hidden" name="anuncio" value="<?php echo $idAnuncioSeleccionado; ?>">

    <?php else: ?>
        <!-- Lista desplegable para seleccionar el anuncio -->
        <select id="anuncio" name="anuncio" required>
            <option value="">Seleccione un anuncio</option>
            <?php foreach ($anuncios as $id => $nombreAnuncio): ?>
                <option value="<?php echo $id; ?>"><?php echo htmlspecialchars($nombreAnuncio); ?></option>
            <?php endforeach; ?>
        </select>
    <?php endif; ?>

    <br><br>

    <!-- Campo de selección de foto -->
    <label for="foto">Foto:</label><br>
    <input type="file" id="foto" name="foto" accept="image/*"><br><br>


    <!-- Campo para el título de la foto -->
    <label for="titulo">Título de la foto:</label><br>
    <input type="text" id="titulo" name="titulo"><br><br>

    <!-- Campo para el texto alternativo de la foto -->
    <label for="alt_text">Texto alternativo:</label><br>
    <input type="text" id="alt_text" name="alt_text"><br><br>



    <!-- Botón para enviar el formulario -->
    <input type="submit" value="Añadir Foto">
</form>
</main>
<?php include 'footer.php'; ?>
