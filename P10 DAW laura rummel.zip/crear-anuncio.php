<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?>
<?php include 'consulta1.php'; ?> 

<body>
<main>
    <h1 class="titulospaginas3">Crear un Nuevo Anuncio</h1>
    
    <form action="respuestacrearanuncio.php" method="post" enctype="multipart/form-data" class="formulario-centrado">
        
        <!-- Tipo de anuncio (Venta, Alquiler, etc.) -->
        <label for="tipo_anuncio">Tipo de Anuncio:</label><br>
        <select id="tipo_anuncio" name="tipo_anuncio">
            <option value="">Seleccione el tipo de anuncio</option>
            <?php
            // Obtener los tipos de anuncio desde la base de datos
            $sql = "SELECT IdTAnuncio, NomTAnuncio FROM TiposAnuncios";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['IdTAnuncio'] . "'>" . $row['NomTAnuncio'] . "</option>";
            }
            ?>
        </select><br><br>
        
        <!-- Tipo de vivienda (Casa, Apartamento, etc.) -->
        <label for="tipo_vivienda">Tipo de Vivienda:</label><br>
        <select id="tipo_vivienda" name="tipo_vivienda">
            <option value="">Seleccione el tipo de vivienda</option>
            <?php
            // Obtener los tipos de vivienda desde la base de datos
            $sql = "SELECT IdTVivienda, NomTVivienda FROM TiposViviendas";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['IdTVivienda'] . "'>" . $row['NomTVivienda'] . "</option>";
            }
            ?>
        </select><br><br>
        
        <!-- Título del anuncio -->
        <label for="titulo">Título:</label><br>
        <input type="text" id="titulo" name="titulo"><br><br>
        
        <!-- Precio del anuncio -->
        <label for="precio">Precio (€):</label><br>
        <input type="number" id="precio" name="precio" step="0.01"><br><br>

          <!-- Ciudad -->
          <label for="ciudad">Superficie (m2):</label><br>
        <input type="text" id="supeficie" name="superficie"><br><br>
        
        <!-- Descripción del anuncio -->
        <label for="descripcion">Descripción:</label><br>
        <textarea id="descripcion" name="descripcion" rows="3" cols="60"></textarea><br><br>
        
        <!-- Ciudad -->
        <label for="ciudad">Ciudad:</label><br>
        <input type="text" id="ciudad" name="ciudad"><br><br>
        
        <!-- País -->
        <label for="pais">País:</label><br>
        <select id="pais" name="pais">
            <option value="">Seleccione el país</option>
            <?php
            // Obtener los países desde la base de datos
            $sql = "SELECT IdPais, NomPais FROM Paises";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['IdPais'] . "'>" . $row['NomPais'] . "</option>";
            }
            ?>
        </select><br><br>
        
        <!-- Foto principal -->
        <label for="foto_principal">Foto Principal:</label><br>
        <input type="file" id="foto_principal" name="foto_principal" accept="image/*">
        
        <!-- Características adicionales -->
        <h3>Características:</h3>
        <label><input type="checkbox" name="caracteristicas[]" value="piscina"> Piscina</label><br>
        <label><input type="checkbox" name="caracteristicas[]" value="jardin"> Jardín</label><br>
        <label><input type="checkbox" name="caracteristicas[]" value="garaje"> Garaje</label><br>
        <label><input type="checkbox" name="caracteristicas[]" value="aire_acondicionado"> Aire Acondicionado</label><br>
        <label><input type="checkbox" name="caracteristicas[]" value="terraza"> Terraza</label><br>
        
        <br>
        
        <!-- Botón para enviar el formulario -->
        <input type="submit" value="Crear Anuncio">
        
    </form>
</main>

<?php include 'footer.php'; ?>
</body>
