<?php
function validarNombreUsuario($nombreUsuario) {
    return preg_match('/^[a-zA-Z][a-zA-Z0-9]{2,14}$/', $nombreUsuario);
}

function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) && strlen($email) <= 254;
}

function validarContrasena($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z0-9_-]{6,15}$/', $password);
}

function validarFechaNacimiento($fecha) {
    $partes = explode('-', $fecha);
    if (count($partes) === 3 && checkdate($partes[1], $partes[2], $partes[0])) {
        $edad = (new DateTime())->diff(new DateTime($fecha))->y;
        return $edad >= 18;
    }
    return false;
}
?>
