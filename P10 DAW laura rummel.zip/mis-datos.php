<!-- 
 Página fotos anuncio
-->
<?php include 'control-priv.php'; ?> 
<?php include 'head.php'; ?>
<?php include 'db.php'; ?>
<?php include 'filters.php'; ?>
<?php
// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    echo "Error: Debes iniciar sesión para ver tus datos.";
    exit();
}

// Obtener el nombre de usuario desde la sesión
$nomUsuario = $_SESSION['usuario'];

// Consultar los datos del usuario
$stmt = $conn->prepare("
    SELECT u.NomUsuario, u.Email, u.Sexo, u.FNacimiento, u.Ciudad, u.Pais, u.Foto, p.NomPais
    FROM Usuarios u
    LEFT JOIN Paises p ON u.Pais = p.IdPais
    WHERE u.NomUsuario = ?
");
$stmt->bind_param("s", $nomUsuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Error: Usuario no encontrado.";
    exit();
}

$row = $result->fetch_assoc();

// Extraer los datos del usuario
$nombreUsuario = $row['NomUsuario'];
$email = $row['Email'];
$sexo = $row['Sexo'];
$fNacimiento = $row['FNacimiento'];
$ciudad = $row['Ciudad'];
$pais = $row['NomPais'];
$foto = $row['Foto'];

// Cerrar la conexión
$stmt->close();
$conn->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errores = [];
    $email = trim($_POST['email']);
    $city = trim($_POST['city']);
    $pais = intval($_POST['pais']);
    $currentPassword = trim($_POST['current_password']);
    $newPassword = trim($_POST['new_password']);
    $newPassword2 = trim($_POST['new_password2']);

    // Validar datos
    if (!validarEmail($email)) {
        $errores['email'] = "El correo no es válido.";
    }
    if (!empty($newPassword)) {
        if (!validarContrasena($newPassword)) {
            $errores['new_password'] = "La nueva contraseña no cumple los requisitos.";
        } elseif ($newPassword !== $newPassword2) {
            $errores['new_password2'] = "Las contraseñas no coinciden.";
        }
    }

    // Validar contraseña actual
    $stmt = $conn->prepare("SELECT Clave FROM Usuarios WHERE NomUsuario = ?");
    $stmt->bind_param("s", $nomUsuario);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if (!password_verify($currentPassword, $result['Clave'])) {
        $errores['current_password'] = "La contraseña actual es incorrecta.";
    }

    if (empty($errores)) {
        // Actualizar datos
        $stmt = $conn->prepare("UPDATE Usuarios SET Email = ?, Ciudad = ?, Pais = ?, Clave = ? WHERE NomUsuario = ?");
        $newPasswordHash = empty($newPassword) ? $result['Clave'] : password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt->bind_param("sssss", $email, $city, $pais, $newPasswordHash, $nomUsuario);
        $stmt->execute();
        echo "Datos actualizados con éxito.";
    }
}
?>

<?php include 'header1.php'; ?>


<body>
<?php include 'search.php'; ?>
<h2 class="titulospaginas3">Mis Datos de Usuario</h2>

<form class="formulario-centrado" action="respuestamisdatos.php" method="POST">
        <label for="username"><i class="fa fa-user"></i> Nombre de usuario:</label><br>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($nombreUsuario); ?>" required>
        <br><br>

        <label for="email"><i class="fa fa-envelope"></i> Correo electrónico:</label><br>
        <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
        <br><br>

        <label for="sexo"><i class="fa fa-venus-mars"></i> Sexo:</label><br>
        <input type="text" id="sexo" name="sexo" value="<?php echo ($sexo == 1) ? 'Masculino' : (($sexo == 0) ? 'Femenino' : 'Otro'); ?>" readonly>
        <br><br>

        <label for="birthdate"><i class="fa fa-calendar"></i> Fecha de nacimiento:</label><br>
        <input type="text" id="birthdate" name="birthdate" value="<?php echo date('d/m/Y', strtotime($fNacimiento)); ?>" readonly>
        <br><br>

        <label for="city"><i class="fa fa-city"></i> Ciudad:</label><br>
        <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($ciudad); ?>" required>
        <br><br>

        <label for="pais"><i class="fa fa-flag"></i> País de residencia:</label><br>
        <input type="text" id="pais" name="pais" value="<?php echo htmlspecialchars($pais); ?>" readonly>
        <br><br>

        <label for="photo"><i class="fa fa-image"></i> Foto de perfil:</label><br>
        <?php if ($foto): ?><br>
            <img src=<?php echo htmlspecialchars($foto); ?> alt="Foto de perfil" width="100">
        <?php else: ?>
            <p>No tienes foto de perfil.</p>
        <?php endif; ?>
        <br><br>

        <label for="current_password">Contraseña actual:</label>
    <input type="password" id="current_password" name="current_password" required><br><br>

    <label for="new_password">Nueva contraseña:</label>
    <input type="password" id="new_password" name="new_password"><br><br>

    <label for="new_password2">Repetir nueva contraseña:</label>
    <input type="password" id="new_password2" name="new_password2"><br><br>
    <input type="hidden" name="username" value="<?php echo htmlspecialchars($nombreUsuario); ?>">
<input type="hidden" name="sexo" value="<?php echo htmlspecialchars($sexo); ?>">
<input type="hidden" name="birthdate" value="<?php echo htmlspecialchars($fNacimiento); ?>">
<input type="hidden" name="photo" value="<?php echo htmlspecialchars($foto); ?>">

    <button type="submit">Actualizar datos</button>
</form>
    <?php include 'footer.php'; ?>