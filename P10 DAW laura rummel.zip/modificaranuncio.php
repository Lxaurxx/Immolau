<?php
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'db.php';

// Obtener el ID del anuncio desde la URL
$idAnuncio = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Validar que el anuncio pertenece al usuario logueado
$nombreUsuario = $_SESSION['usuario'];

// Obtener el ID del usuario logueado
$sqlUsuario = "SELECT IdUsuario FROM Usuarios WHERE NomUsuario = ?";
$stmtUsuario = $conn->prepare($sqlUsuario);
$stmtUsuario->bind_param("s", $nombreUsuario);
$stmtUsuario->execute();
$stmtUsuario->bind_result($idUsuario);
$stmtUsuario->fetch();
$stmtUsuario->close();

if (!$idUsuario) {
    echo "Usuario no encontrado.";
    exit;
}

// Obtener los datos del anuncio
$sqlAnuncio = "
    SELECT Titulo, Precio, Texto, Ciudad, Pais, Superficie, Nhabitaciones, Nbanyos, Planta, 
           Anyo, TAnuncio, TVivienda
    FROM Anuncios
    WHERE IdAnuncio = ? AND Usuario = ?";
$stmtAnuncio = $conn->prepare($sqlAnuncio);
$stmtAnuncio->bind_param("ii", $idAnuncio, $idUsuario);
$stmtAnuncio->execute();
$resultAnuncio = $stmtAnuncio->get_result();

if ($resultAnuncio->num_rows == 0) {
    echo "El anuncio no existe o no pertenece al usuario logueado.";
    exit;
}

$anuncio = $resultAnuncio->fetch_assoc();
$stmtAnuncio->close();

?>

<body>
<main>
    <h1 class="titulospaginas3">Modificar Anuncio</h1>

    <form action="respuestamodificaranuncio.php" method="post" enctype="multipart/form-data" class="formulario-centrado">
        <!-- Campo oculto para pasar el ID del anuncio -->
        <input type="hidden" name="id_anuncio" value="<?php echo $idAnuncio; ?>">

        <!-- Tipo de anuncio -->
        <label for="tipo_anuncio">Tipo de Anuncio:</label><br>
        <select id="tipo_anuncio" name="tipo_anuncio">
            <option value="">Seleccione el tipo de anuncio</option>
            <?php
            $sqlTiposAnuncio = "SELECT IdTAnuncio, NomTAnuncio FROM TiposAnuncios";
            $resultTiposAnuncio = $conn->query($sqlTiposAnuncio);
            while ($row = $resultTiposAnuncio->fetch_assoc()) {
                $selected = $anuncio['TAnuncio'] == $row['IdTAnuncio'] ? "selected" : "";
                echo "<option value='{$row['IdTAnuncio']}' $selected>{$row['NomTAnuncio']}</option>";
            }
            ?>
        </select><br><br>

        <!-- Tipo de vivienda -->
        <label for="tipo_vivienda">Tipo de Vivienda:</label><br>
        <select id="tipo_vivienda" name="tipo_vivienda">
            <option value="">Seleccione el tipo de vivienda</option>
            <?php
            $sqlTiposVivienda = "SELECT IdTVivienda, NomTVivienda FROM TiposViviendas";
            $resultTiposVivienda = $conn->query($sqlTiposVivienda);
            while ($row = $resultTiposVivienda->fetch_assoc()) {
                $selected = $anuncio['TVivienda'] == $row['IdTVivienda'] ? "selected" : "";
                echo "<option value='{$row['IdTVivienda']}' $selected>{$row['NomTVivienda']}</option>";
            }
            ?>
        </select><br><br>

        <!-- Título del anuncio -->
        <label for="titulo">Título:</label><br>
        <input type="text" id="titulo" name="titulo" value="<?php echo $anuncio['Titulo']; ?>"><br><br>

        <!-- Precio del anuncio -->
        <label for="precio">Precio (€):</label><br>
        <input type="number" id="precio" name="precio" step="0.01" value="<?php echo $anuncio['Precio']; ?>"><br><br>

        <!-- Superficie -->
        <label for="superficie">Superficie (m2):</label><br>
        <input type="text" id="superficie" name="superficie" value="<?php echo $anuncio['Superficie']; ?>"><br><br>

        <!-- Descripción -->
        <label for="descripcion">Descripción:</label><br>
        <textarea id="descripcion" name="descripcion" rows="3" cols="60"><?php echo $anuncio['Texto']; ?></textarea><br><br>

        <!-- Ciudad -->
        <label for="ciudad">Ciudad:</label><br>
        <input type="text" id="ciudad" name="ciudad" value="<?php echo $anuncio['Ciudad']; ?>"><br><br>

        <!-- País -->
        <label for="pais">País:</label><br>
        <select id="pais" name="pais">
            <option value="">Seleccione el país</option>
            <?php
            $sqlPaises = "SELECT IdPais, NomPais FROM Paises";
            $resultPaises = $conn->query($sqlPaises);
            while ($row = $resultPaises->fetch_assoc()) {
                $selected = $anuncio['Pais'] == $row['IdPais'] ? "selected" : "";
                echo "<option value='{$row['IdPais']}' $selected>{$row['NomPais']}</option>";
            }
            ?>
        </select><br><br>

        <!-- Botón para enviar -->
        <input type="submit" value="Modificar Anuncio">
    </form>
</main>

<?php include 'footer.php'; ?>
</body>
