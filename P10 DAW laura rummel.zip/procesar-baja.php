<?php
include 'db.php';
include 'control-priv.php';

// Obtener el ID del usuario desde la sesión
$idUsuario = $_SESSION['user_id'];

// Obtener y verificar la contraseña ingresada
$password = $_POST['password'];

// Comprobar la contraseña del usuario
$queryUsuario = $conn->prepare("SELECT Clave FROM Usuarios WHERE IdUsuario = ?");
$queryUsuario->bind_param("i", $idUsuario);
$queryUsuario->execute();
$resultUsuario = $queryUsuario->get_result();

if ($resultUsuario->num_rows === 0) {
    echo "Error: Usuario no encontrado.";
    exit;
}

$usuario = $resultUsuario->fetch_assoc();
if ($usuario['Clave'] !== $password) {
    echo "Error: Contraseña incorrecta.";
    exit;
}

// Eliminar usuario y datos relacionados
$conn->begin_transaction();

try {
    // Eliminar anuncios y fotos relacionadas
    $queryEliminarAnuncios = $conn->prepare("DELETE FROM Anuncios WHERE Usuario = ?");
    $queryEliminarAnuncios->bind_param("i", $idUsuario);
    $queryEliminarAnuncios->execute();

    // Eliminar mensajes relacionados
    $queryEliminarMensajes = $conn->prepare("DELETE FROM Mensajes WHERE UsuarioOrigen = ? OR UsuarioDestino = ?");
    $queryEliminarMensajes->bind_param("ii", $idUsuario, $idUsuario);
    $queryEliminarMensajes->execute();

    // Eliminar el usuario
    $queryEliminarUsuario = $conn->prepare("DELETE FROM Usuarios WHERE IdUsuario = ?");
    $queryEliminarUsuario->bind_param("i", $idUsuario);
    $queryEliminarUsuario->execute();

    // Confirmar transacción
    $conn->commit();
    echo "Tu cuenta y todos los datos asociados se han eliminado correctamente.";
    sleep(2);
    header("Location: logout.php");
} catch (Exception $e) {
    $conn->rollback();
    echo "Error al eliminar la cuenta: " . $e->getMessage();
}

?>
