<?php
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'db.php';
include 'search.php';

// Verificar si el formulario ha sido enviado correctamente
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos del formulario
    $idAnuncio = isset($_POST['anuncio']) ? (int)$_POST['anuncio'] : 0;
    $titulo = trim($_POST['titulo']);
    $altText = trim($_POST['alt_text']);

    // Validaciones
    $errores = [];

    // Validar que el ID del anuncio sea válido
    if ($idAnuncio <= 0) {
        $errores[] = "Debe seleccionar un anuncio válido.";
    }

    // Validar el título (Fichero)
    if (empty($titulo)) {
        $errores[] = "El título de la foto es obligatorio.";
    }

    // Validar el texto alternativo
    if (empty($altText)) {
        $errores[] = "El texto alternativo es obligatorio.";
    } elseif (strlen($altText) < 10) {
        $errores[] = "El texto alternativo debe tener al menos 10 caracteres.";
    } elseif (preg_match('/^(foto|imagen)/i', $altText)) {
        $errores[] = "El texto alternativo no puede comenzar con 'foto' o 'imagen'.";
    }

    // Si hay errores, mostrarlos y detener el proceso
    if (!empty($errores)) {
        echo "<h3>Errores en el formulario:</h3>";
        echo "<ul>";
        foreach ($errores as $error) {
            echo "<li>" . htmlspecialchars($error) . "</li>";
        }
        echo "</ul>";
        echo "<a href='anadir-foto.php?id=$idAnuncio'>Volver</a>";
        include 'footer.php';
        exit();
    }

    // Inserción en la base de datos
    try {
        // Preparar la consulta para insertar la foto
        $queryInsertFoto = "INSERT INTO Fotos (Alternativo, Fichero, Anuncio) VALUES (?, ?, ?)";
        $stmtInsertFoto = $conn->prepare($queryInsertFoto);
        $stmtInsertFoto->bind_param("ssi", $altText, $titulo, $idAnuncio);

        // Ejecutar la consulta
        if ($stmtInsertFoto->execute()) {
            echo "<h3>Foto añadida correctamente.</h3>";
            echo "<a href='ver-fotos-priv.php?id=$idAnuncio'>Volver a las fotos</a>";
        } else {
            throw new Exception("Error al añadir la foto: " . $stmtInsertFoto->error);
        }

        // Cerrar el statement
        $stmtInsertFoto->close();
    } catch (Exception $e) {
        echo "<h3>Ocurrió un error:</h3>";
        echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
        echo "<a href='anadir-foto.php?id=$idAnuncio'>Volver</a>";
    }
} else {
    echo "<h3>Acceso no autorizado</h3>";
    echo "<p>Por favor, envíe el formulario desde la página de añadir foto.</p>";
    echo "<a href='perfil.php'>Volver al perfil</a>";
    
}
include 'footer.php';

// Cerrar la conexión
$conn->close();
?>
