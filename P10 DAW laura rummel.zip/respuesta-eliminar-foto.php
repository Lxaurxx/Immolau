<?php
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'db.php';

// Obtener los parámetros ID de anuncio y ID de foto desde la URL
$idAnuncio = isset($_GET['idAnuncio']) ? (int)$_GET['idAnuncio'] : 0;
$idFoto = isset($_GET['idFoto']) ? (int)$_GET['idFoto'] : 0;

// Si el ID de foto o ID de anuncio no es válido, redirigir al perfil
if ($idAnuncio <= 0 || $idFoto <= 0) {
    header("Location: perfil.php");
    exit;
}

// Obtener los detalles de la foto para mostrarla en el mensaje de confirmación
$queryFoto = "SELECT Fichero, Alternativo FROM Fotos WHERE IdFoto = ? AND Anuncio = ?";
$stmtFoto = $conn->prepare($queryFoto);
$stmtFoto->bind_param("ii", $idFoto, $idAnuncio);
$stmtFoto->execute();
$resultFoto = $stmtFoto->get_result();

// Si no se encuentra la foto o no pertenece al anuncio, redirigir al perfil
if ($resultFoto->num_rows == 0) {
    echo "Foto no encontrada o no pertenece a este anuncio.";
    exit;
}

$foto = $resultFoto->fetch_assoc();
$stmtFoto->close();

// Verificar si el formulario ha sido enviado para eliminar la foto
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirmar']) && $_POST['confirmar'] === 'si') {
    // Eliminar la foto de la base de datos
    $queryEliminarFoto = "DELETE FROM Fotos WHERE IdFoto = ? AND Anuncio = ?";
    $stmtEliminar = $conn->prepare($queryEliminarFoto);
    $stmtEliminar->bind_param("ii", $idFoto, $idAnuncio);
    $stmtEliminar->execute();
    $stmtEliminar->close();

    // Eliminar la foto físicamente del servidor (si es necesario)
    // Puedes usar la función unlink() si las fotos están almacenadas localmente
    // unlink($foto['Fichero']);  // Descomentar si deseas borrar la imagen del servidor

    // Redirigir al perfil después de la eliminación
    header("Location: perfil.php");
    exit;
}
?>

<body>
<?php include 'search.php'; ?>
    <div class="confirmar-eliminacion">
        <h2>¿Estás seguro de que deseas eliminar esta foto?</h2>
        <img src="<?php echo $foto['Fichero']; ?>" alt="<?php echo $foto['Alternativo']; ?>" width="550">
        <p><strong>Alternativo:</strong> <?php echo $foto['Alternativo']; ?></p>
        
        <form action="respuesta-eliminar-foto.php?idAnuncio=<?php echo $idAnuncio; ?>&idFoto=<?php echo $idFoto; ?>" method="POST">
            <!-- Botones para confirmar o cancelar -->
            <button type="submit" name="confirmar" value="si" style="color: red;">Sí, eliminar foto</button>
            <a href="ver-fotos-priv.php?id=<?php echo $idAnuncio; ?>" class="btn-cancelar">Cancelar</a>
        </form>
    </div>
    <?php include 'footer.php'; ?>
