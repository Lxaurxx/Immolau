<?php
// Incluir conexión a la base de datos y verificar el inicio de sesión
include 'db.php';
include 'head.php';
include 'header1.php';
include 'control-priv.php';
include 'search.php';

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    die('Error: Debes iniciar sesión para crear un anuncio.');
}

// Obtener el ID del usuario de la sesión
$usuarioId = $_SESSION['user_id'];

// Validar que los datos requeridos estén presentes
$titulo = trim($_POST['titulo']);
$descripcion = trim($_POST['descripcion']);

if (empty($titulo) || empty($descripcion)) {
    die('Error: El título y la descripción son obligatorios.');
}

// Validar otros campos con detalles adicionales
$tipo_anuncio = isset($_POST['tipo_anuncio']) ? $_POST['tipo_anuncio'] : null;
$tipo_vivienda = isset($_POST['tipo_vivienda']) ? $_POST['tipo_vivienda'] : null;
$precio = isset($_POST['precio']) ? $_POST['precio'] : null;
$superficie = isset($_POST['superficie']) ? $_POST['superficie'] : null;
$ciudad = isset($_POST['ciudad']) ? trim($_POST['ciudad']) : null;
$pais = isset($_POST['pais']) ? $_POST['pais'] : null;

include 'validaciones.php';

$alternativo = "Descripción alternativa";

// Modificar la consulta para incluir el campo Alternativo
$sql = "INSERT INTO Anuncios (Alternativo, Titulo, Texto, Precio, Ciudad, Pais, Superficie, Usuario, TAnuncio, TVivienda) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Error en la preparación de la consulta: ' . $conn->error);
}

$stmt->bind_param(
    "sssdsdsiii",
    $alternativo,
    $titulo,
    $descripcion,
    $precio,
    $ciudad,
    $pais,
    $superficie,
    $usuarioId,
    $tipo_anuncio,
    $tipo_vivienda
);

if ($stmt->execute()) {
    // Obtener el ID del anuncio recién creado
    $idAnuncio = $stmt->insert_id;

    // Redirigir al usuario para añadir una foto al anuncio
    echo "<h1>Anuncio creado con éxito</h1>";
    echo "<p>Ahora puedes añadir fotos a tu anuncio.</p>";
    echo "<a href='anadir-foto.php?id=$idAnuncio'>Haz clic aquí para añadir una foto</a>";
} else {
    echo "Error al crear el anuncio: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
<?php include 'footer.php'; ?>