<?php
session_start();
include 'db.php'; // Conexión a la base de datos
include 'filters.php'; // Funciones de validación

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recoger datos del formulario
    $username = $_POST['username'];
    $email = trim($_POST['email']);
    $city = trim($_POST['city']);
    $pais = intval($_POST['pais']);
    $currentPassword = trim($_POST['current_password']);
    $newPassword = trim($_POST['new_password']);
    $newPassword2 = trim($_POST['new_password2']);

    $errores = [];

    // Validar datos
    if (!validarEmail($email)) {
        $errores['email'] = "El correo no es válido.";
    }
    if (!empty($newPassword)) {
        if (!validarContrasena($newPassword)) {
            $errores['new_password'] = "La nueva contraseña no cumple los requisitos.";
        } elseif ($newPassword !== $newPassword2) {
            $errores['new_password2'] = "Las contraseñas no coinciden.";
        }
    }

    // Validar contraseña actual
    $stmt = $conn->prepare("SELECT Clave FROM Usuarios WHERE NomUsuario = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();

    if (!$result || !password_verify($currentPassword, $result['Clave'])) {
        $errores['current_password'] = "La contraseña actual es incorrecta.";
    }

    if (empty($errores)) {
        // Actualizar los datos en la base de datos
        $stmt = $conn->prepare("UPDATE Usuarios SET Email = ?, Ciudad = ?, Pais = ?, Clave = ? WHERE NomUsuario = ?");
        $newPasswordHash = empty($newPassword) ? $result['Clave'] : password_hash($newPassword, PASSWORD_DEFAULT);
        $stmt->bind_param("sssss", $email, $city, $pais, $newPasswordHash, $username);
        if ($stmt->execute()) {
            echo "Datos actualizados con éxito.";
        } else {
            echo "Error al actualizar los datos.";
        }
    } else {
        // Mostrar errores
        foreach ($errores as $campo => $mensaje) {
            echo "<p>Error en $campo: $mensaje</p>";
        }
    }
}
?>
