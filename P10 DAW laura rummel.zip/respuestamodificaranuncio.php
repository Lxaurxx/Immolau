<?php
// Incluir conexión, validaciones y verificar inicio de sesión
include 'db.php';
include 'validaciones.php';
include 'control-priv.php';
include 'head.php';
include 'header1.php';


// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    die('Error: Debes iniciar sesión para modificar un anuncio.');
}

// Obtener el ID del anuncio desde la URL o formulario
$idAnuncio = isset($_POST['id_anuncio']) ? (int)$_POST['id_anuncio'] : 0;
if ($idAnuncio <= 0) {
    die('Error: ID de anuncio inválido.');
}

// Obtener el ID del usuario de la sesión
$usuarioId = $_SESSION['user_id'];

// Capturar datos del formulario
$datos = [
    'titulo' => $_POST['titulo'] ?? '',
    'descripcion' => $_POST['descripcion'] ?? '',
    'tipo_anuncio' => $_POST['tipo_anuncio'] ?? '',
    'tipo_vivienda' => $_POST['tipo_vivienda'] ?? '',
    'precio' => $_POST['precio'] ?? '',
    'superficie' => $_POST['superficie'] ?? '',
    'ciudad' => $_POST['ciudad'] ?? '',
    'pais' => $_POST['pais'] ?? ''
];

// Validar los datos
$errores = validarDatosAnuncio($datos);
if (!empty($errores)) {
    foreach ($errores as $error) {
        echo "<p>Error: $error</p>";
    }
    exit;
}

// Actualizar anuncio en la base de datos
$sql = "UPDATE Anuncios SET 
        Titulo = ?, Texto = ?, Precio = ?, Ciudad = ?, Pais = ?, Superficie = ?, 
        TAnuncio = ?, TVivienda = ? 
        WHERE IdAnuncio = ? AND Usuario = ?";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('Error en la preparación de la consulta: ' . $conn->error);
}

$stmt->bind_param(
    "sssssiiiii",
    $datos['titulo'],
    $datos['descripcion'],
    $datos['precio'],
    $datos['ciudad'],
    $datos['pais'],
    $datos['superficie'],
    $datos['tipo_anuncio'],
    $datos['tipo_vivienda'],
    $idAnuncio,
    $usuarioId
);
include 'search.php';
if ($stmt->execute()) {
    echo "<h1>Anuncio modificado con éxito</h1>";
    echo "<a href='ver-anuncio.php?id=$idAnuncio'>Volver al anuncio</a>";
} else {
    echo "Error al modificar el anuncio: " . $stmt->error;
}

$stmt->close();
$conn->close();
include 'footer.php';
?>

