<?php
session_start();
include 'db.php'; // Conexión a la base de datos

// Obtener los datos del formulario
$username = trim($_POST['username']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$password2 = trim($_POST['password2']);
$birthdate = trim($_POST['birthdate']);
$sexo = trim($_POST['sexo']) === 'masculino' ? 1 : (trim($_POST['sexo']) === 'femenino' ? 0 : 2);
$city = trim($_POST['city']);
$pais = intval($_POST['pais']);
// Manejo de la foto de perfil
$photoPath = null; /*
if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $photoDir = 'uploads/';
    if (!is_dir($photoDir)) {
        mkdir($photoDir, 0777, true);
    }
    $photoPath = $photoDir . basename($_FILES['photo']['name']);
    move_uploaded_file($_FILES['photo']['tmp_name'], $photoPath);
} */

// Validación de errores
$errores = [];

// 1. Validar nombre de usuario
if (!preg_match('/^[a-zA-Z][a-zA-Z0-9]{2,14}$/', $username)) {
    $errores['username'] = "El nombre de usuario debe tener entre 3 y 15 caracteres, comenzar con una letra y solo contener letras y números.";
}

// 2. Validar contraseña
if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z0-9_-]{6,15}$/', $password)) {
    $errores['password'] = "La contraseña debe tener entre 6 y 15 caracteres, incluir al menos una mayúscula, una minúscula y un número.";
}

// 3. Validar repetir contraseña
if ($password !== $password2) {
    $errores['password2'] = "Las contraseñas no coinciden.";
}

// 4. Validar email
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254) {
    $errores['email'] = "El correo electrónico no es válido.";
}

// 5. Validar sexo
if (empty($sexo)) {
    $errores['sexo'] = "Debe seleccionar un sexo.";
}

// 6. Validar fecha de nacimiento
$dateParts = explode('-', $birthdate);
if (count($dateParts) === 3 && checkdate($dateParts[1], $dateParts[2], $dateParts[0])) {
    $dateTimeBirth = new DateTime($birthdate);
    $dateTimeNow = new DateTime();
    $age = $dateTimeNow->diff($dateTimeBirth)->y;
    if ($age < 18) {
        $errores['birthdate'] = "Debes tener al menos 18 años para registrarte.";
    }
} else {
    $errores['birthdate'] = "La fecha de nacimiento no es válida.";
}

// Si hay errores, guardar los errores como flashdata
if (!empty($errores)) {
    $_SESSION['flashdata'] = $errores;
    // Guardar los valores previos para rellenar el formulario
    $_SESSION['username'] = $username;
    $_SESSION['email'] = $email;
    $_SESSION['birthdate'] = $birthdate;
    $_SESSION['sexo'] = trim($_POST['sexo']);
    $_SESSION['city'] = $city;
    $_SESSION['pais'] = $pais;
    header("Location: registro.php");
    exit;
}

// Insertar en la base de datos
try {
    $stmt = $conn->prepare(
        "INSERT INTO Usuarios (NomUsuario, Clave, Email, Sexo, FNacimiento, Ciudad, Pais, Foto)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param('ssssssis', $username, $password, $email, $sexo, $birthdate, $city, $pais, $photoPath);

    if (!$stmt->execute()) {
        throw new Exception("Error al ejecutar la consulta: " . $stmt->error);
    }
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>

<body>
<form action="index.php" method="get" enctype="multipart/form-data">
    <h2 class="titulospaginas3">Registro completado</h2>
    <p><strong>Nombre de usuario:</strong> <?php echo htmlspecialchars($username); ?></p>
    <p><strong>Correo electrónico:</strong> <?php echo htmlspecialchars($email); ?></p>
    <p><strong>Fecha de nacimiento:</strong> <?php echo htmlspecialchars($birthdate); ?></p>
    <p><strong>Sexo:</strong> <?php echo htmlspecialchars($sexo); ?></p>
    <p><strong>Ciudad:</strong> <?php echo htmlspecialchars($city); ?></p>
    <p><strong>País:</strong> <?php echo htmlspecialchars($pais); ?></p>
    <p><em>Su registro se ha completado con éxito.</em></p>

    <input type="submit" value="Entendido">
</body>

<?php include 'footer.php'; ?>
