<?php
function validarDatosAnuncio($datos) {
    $errores = [];

    if (empty(trim($datos['titulo']))) {
        $errores[] = "El título es obligatorio.";
    }

    if (empty(trim($datos['descripcion']))) {
        $errores[] = "La descripción es obligatoria.";
    }

    if (!is_numeric($datos['tipo_anuncio']) || $datos['tipo_anuncio'] <= 0) {
        $errores[] = "Tipo de anuncio inválido.";
    }

    if (!is_numeric($datos['tipo_vivienda']) || $datos['tipo_vivienda'] <= 0) {
        $errores[] = "Tipo de vivienda inválido.";
    }

    if (!is_numeric($datos['precio']) || $datos['precio'] < 0) {
        $errores[] = "El precio debe ser un número positivo.";
    }

    if (!is_numeric($datos['superficie']) || $datos['superficie'] <= 0) {
        $errores[] = "La superficie debe ser un número positivo.";
    }

    if (empty(trim($datos['ciudad']))) {
        $errores[] = "La ciudad es obligatoria.";
    }

    if (!is_numeric($datos['pais']) || $datos['pais'] <= 0) {
        $errores[] = "País inválido.";
    }

    return $errores;
}
?>
