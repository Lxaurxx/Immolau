<!-- 
 Página fotos anuncio
-->
<?php
include 'db.php'; 

// Consulta para obtener los estilos
$sql = "SELECT IdEstilo, Nombre FROM Estilos";
$result = $conn->query($sql);
?>
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?> 

<body>
<?php include 'search.php'; ?>
<h2 class="titulospaginas3">Configurar Estilo</h2>
    
    <form method="POST" action="configurar.php" class="formulario-centrado">
        <label for="estilo">Selecciona un estilo:</label>
        <select name="estilo" id="estilo">
            <?php
            // Verificar si hay resultados
            if ($result->num_rows > 0) {
                // Recorrer los resultados y generar las opciones
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['IdEstilo'] . "'>" . htmlspecialchars($row['Nombre']) . "</option>";
                }
            } else {
                echo "<option value=''>No hay estilos disponibles</option>";
            }
            ?>
        </select>
        <button type="submit">Guardar configuración</button>
    </form>

    <?php
    // Cerrar conexión
    $conn->close();
    ?>

<?php include 'footer.php'; ?>