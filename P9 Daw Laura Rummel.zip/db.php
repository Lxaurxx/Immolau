<?php
$host = "sql105.infinityfree.com";
$user = "if0_37396407";
$password = "VdENh0tc0G";
$dbname = "if0_37396407_pibd";

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}


// Configurar charset a UTF-8
if (!$conn->set_charset("utf8mb4")) {
    die("Error configurando el charset UTF-8: " . $conn->error);
}

// Opción alternativa, si es necesario forzar la configuración:
$conn->query("SET NAMES 'utf8mb4' COLLATE 'utf8mb4_spanish_ci'");

?>
