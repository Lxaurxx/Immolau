<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verifica si el estilo está en la sesión o en las cookies
$estilo = isset($_SESSION['estilo']) ? $_SESSION['estilo'] : (isset($_COOKIE['estilo']) ? $_COOKIE['estilo'] : 'estilo1');

// Dependiendo del estilo, incluye el archivo CSS correspondiente
switch ($estilo) {
    case 1:
        $estilo_css = 'style2.css'; // Estilo por defecto
        break;
    case 2:
        $estilo_css = 'modo-noche.css';
        break;
    case 3:
        $estilo_css = 'alto-contraste.css';
        break;
    case 4:
        $estilo_css = 'texto-grande.css';
        break;
    case 5:
        $estilo_css = 'textoycontraste.css';
        break;
    default:
        $estilo_css = 'style2.css'; // Valor por defecto si no hay estilo
}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Pictures España</title>
    <link rel="stylesheet" href="<?php echo $estilo_css; ?>" media="screen">
    <!-- Los otros estilos alternativos están deshabilitados, ya que se usa el estilo determinado por el usuario -->
    <link rel="stylesheet" href="print.css" media="print">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
