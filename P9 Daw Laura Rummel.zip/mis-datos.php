<!-- 
 Página fotos anuncio
-->
<?php include 'control-priv.php'; ?> 
<?php include 'head.php'; ?>
<?php include 'db.php'; ?>
<?php
// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario'])) {
    echo "Error: Debes iniciar sesión para ver tus datos.";
    exit();
}

// Obtener el nombre de usuario desde la sesión
$nomUsuario = $_SESSION['usuario'];

// Consultar los datos del usuario
$stmt = $conn->prepare("
    SELECT u.NomUsuario, u.Email, u.Sexo, u.FNacimiento, u.Ciudad, u.Pais, u.Foto, p.NomPais
    FROM Usuarios u
    LEFT JOIN Paises p ON u.Pais = p.IdPais
    WHERE u.NomUsuario = ?
");
$stmt->bind_param("s", $nomUsuario);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Error: Usuario no encontrado.";
    exit();
}

$row = $result->fetch_assoc();

// Extraer los datos del usuario
$nombreUsuario = $row['NomUsuario'];
$email = $row['Email'];
$sexo = $row['Sexo'];
$fNacimiento = $row['FNacimiento'];
$ciudad = $row['Ciudad'];
$pais = $row['NomPais'];
$foto = $row['Foto'];

// Cerrar la conexión
$stmt->close();
$conn->close();
?>

<?php include 'header1.php'; ?>


<body>
<?php include 'search.php'; ?>
<h2 class="titulospaginas3">Mis Datos de Usuario</h2>

    <form class="formulario-centrado">
        <label for="username"><i class="fa fa-user"></i> Nombre de usuario:</label><br>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($nombreUsuario); ?>" readonly>
        <br><br>

        <label for="email"><i class="fa fa-envelope"></i> Correo electrónico:</label><br>
        <input type="text" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" readonly>
        <br><br>

        <label for="sexo"><i class="fa fa-venus-mars"></i> Sexo:</label><br>
        <input type="text" id="sexo" name="sexo" value="<?php echo ($sexo == 1) ? 'Masculino' : (($sexo == 0) ? 'Femenino' : 'Otro'); ?>" readonly>
        <br><br>

        <label for="birthdate"><i class="fa fa-calendar"></i> Fecha de nacimiento:</label><br>
        <input type="text" id="birthdate" name="birthdate" value="<?php echo date('d/m/Y', strtotime($fNacimiento)); ?>" readonly>
        <br><br>

        <label for="city"><i class="fa fa-city"></i> Ciudad:</label><br>
        <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($ciudad); ?>" readonly>
        <br><br>

        <label for="pais"><i class="fa fa-flag"></i> País de residencia:</label><br>
        <input type="text" id="pais" name="pais" value="<?php echo htmlspecialchars($pais); ?>" readonly>
        <br><br>

        <label for="photo"><i class="fa fa-image"></i> Foto de perfil:</label><br>
        <?php if ($foto): ?><br>
            <img src=<?php echo htmlspecialchars($foto); ?> alt="Foto de perfil" width="100">
        <?php else: ?>
            <p>No tienes foto de perfil.</p>
        <?php endif; ?>
        <br><br>
        <a href="mis-datos.php"><button type="button">Confirmar cambios</button></a>
    </form>

    <?php include 'footer.php'; ?>