<?php
session_start();

// Obtener los datos del formulario
$username = trim($_POST['username']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$password2 = trim($_POST['password2']);
$birthdate = trim($_POST['birthdate']);
$sexo = trim($_POST['sexo']);
$city = trim($_POST['city']);
$pais = trim($_POST['pais']);

// Validación de errores
$errores = [];
if (empty($username)) {
    $errores['username'] = 'El nombre de usuario es obligatorio.';
}
if (empty($password)) {
    $errores['password'] = 'La contraseña es obligatoria.';
}
if ($password !== $password2) {
    $errores['password2'] = 'Las contraseñas no coinciden.';
}
if (empty($email)) {
    $errores['email'] = 'El correo electrónico es obligatorio.';
}

// Si hay errores, guardar los errores como flashdata
if (!empty($errores)) {
    $_SESSION['flashdata'] = $errores;
    // Redirigir de vuelta al formulario de registro
    header("Location: registro.php");
    exit;
}

// Si no hay errores, mostrar confirmación del registro
?>
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>

<body>
<form action="index.php" method="get" enctype="multipart/form-data">
    <h2 class="titulospaginas3">Registro completado</h2>
    <p><strong>Nombre de usuario:</strong> <?php echo htmlspecialchars($username); ?></p>
    <p><strong>Correo electrónico:</strong> <?php echo htmlspecialchars($email); ?></p>
    <p><strong>Fecha de nacimiento:</strong> <?php echo htmlspecialchars($birthdate); ?></p>
    <p><strong>Sexo:</strong> <?php echo htmlspecialchars($sexo); ?></p>
    <p><strong>Ciudad:</strong> <?php echo htmlspecialchars($city); ?></p>
    <p><strong>País:</strong> <?php echo htmlspecialchars($pais); ?></p>
    <p><em>Su registro se ha completado con éxito.</em></p>

    <input type="submit" value="Entendido">
</body>

<?php include 'footer.php'; ?>
