<!-- Página respuesta solicitar folleto -->
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?>
<body>
<?php include 'search.php'; ?>

<div class="titulospaginas3">
    <h2>Confirmación de Solicitud</h2>
    <p>Gracias por tu solicitud. Se ha registrado correctamente tu solicitud de impresión de álbum.</p>
</div>

<?php
// Incluye la función de cálculo del costo del folleto
function obtenerCosto($paginas, $fotos, $resolucion, $tipo) {
    $costoBase = 12.00;
    $incrementoPaginas = 0;
    if ($paginas > 1 && $paginas <= 4) {
        $incrementoPaginas = 2.00 * ($paginas - 1);
    } elseif ($paginas >= 5 && $paginas <= 10) {
        $incrementoPaginas = 2.00 * 3 + 1.80 * ($paginas - 4); 
    } elseif ($paginas > 10) {
        $incrementoPaginas = 2.00 * 3 + 1.80 * 6 + 1.60 * ($paginas - 10);
    }

    $incrementoFotos = 0;
    if ($tipo === "color") {
        $incrementoFotos += 0.50 * $fotos;
    }

    if ($resolucion === "450-900") {
        $incrementoFotos += 0.20 * $fotos;
    }

    $costoTotal = $costoBase + $incrementoPaginas + $incrementoFotos;
    return number_format($costoTotal, 2);
}

// Obtén los datos del formulario
$nombre = htmlspecialchars($_GET['nombre']);
$correo = htmlspecialchars($_GET['correo']);
$texto = htmlspecialchars($_GET['texto']);
$calle = htmlspecialchars($_GET['calle']);
$numero = htmlspecialchars($_GET['numero']);
$piso = htmlspecialchars($_GET['piso']);
$puerta = htmlspecialchars($_GET['puerta']);
$codigo_postal = htmlspecialchars($_GET['codigo_postal']);
$pais = htmlspecialchars($_GET['pais']);
$provincia = htmlspecialchars($_GET['provincia']);
$localidad = htmlspecialchars($_GET['localidad']);
$telefono = htmlspecialchars($_GET['Telefono']);
$color_portada = htmlspecialchars($_GET['color']);
$numero_copias = (int)$_GET['numero_copias'];
$resolucion = htmlspecialchars($_GET['resolucion']);
$anuncio = htmlspecialchars($_GET['anuncio']);
$fecha_recepcion = htmlspecialchars($_GET['fecha_recepcion']);
$impresion_color = $_GET['impresion_color'] === 'atodocolor' ? 'A todo color' : 'Blanco y negro';
$impresion_precio = $_GET['impresion_precio'] === 'con_precio' ? 'Con precio' : 'Sin precio';

// Usa valores ficticios para el número de páginas y fotos
$paginas = 5;  // Ejemplo de valor ficticio
$fotos = 15;   // Ejemplo de valor ficticio

// Calcula el coste del folleto unitario
$costoUnitario = obtenerCosto($paginas, $fotos, $resolucion, $impresion_color === 'A todo color' ? 'color' : 'bn');

// Calcula el coste total para el número de copias solicitado
$costoTotal = $numero_copias * $costoUnitario;
?>

<h4>Datos ingresados:</h4>
<ul>
    <li><strong>Nombre completo:</strong> <?= $nombre ?></li>
    <li><strong>Correo electrónico:</strong> <?= $correo ?></li>
    <li><strong>Texto adicional:</strong> <?= $texto ?></li>
    <li><strong>Calle:</strong> <?= $calle ?></li>
    <li><strong>Número:</strong> <?= $numero ?></li>
    <li><strong>Piso:</strong> <?= $piso ?></li>
    <li><strong>Puerta:</strong> <?= $puerta ?></li>
    <li><strong>Código Postal:</strong> <?= $codigo_postal ?></li>
    <li><strong>País:</strong> <?= $pais ?></li>
    <li><strong>Provincia:</strong> <?= $provincia ?></li>
    <li><strong>Localidad:</strong> <?= $localidad ?></li>
    <li><strong>Teléfono:</strong> <?= $telefono ?></li>
    <li><strong>Color de portada:</strong> <?= $color_portada ?></li>
    <li><strong>Número de copias:</strong> <?= $numero_copias ?></li>
    <li><strong>Resolución de fotos:</strong> <?= $resolucion ?> DPI</li>
    <li><strong>Anuncio seleccionado:</strong> <?= $anuncio ?></li>
    <li><strong>Fecha de recepción:</strong> <?= $fecha_recepcion ?></li>
    <li><strong>Impresión a color:</strong> <?= $impresion_color ?></li>
    <li><strong>Impresión del precio:</strong> <?= $impresion_precio ?></li>
</ul>

<h4>Coste del folleto publicitario:</h4>
<p><strong><?= number_format($costoTotal, 2) ?> €</strong></p>

<p>Te contactaremos a través del correo electrónico proporcionado para cualquier consulta adicional.</p>

<form action="perfil.php" method="get">
    <input type="submit" value="Entendido">
</form>
</body>

<?php include 'footer.php'; ?>
