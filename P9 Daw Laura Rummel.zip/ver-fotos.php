<!-- 
 Página fotos anuncio
-->
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>
<?php include 'control-priv.php'; ?> 
<?php include 'db.php';?> 

<body>
<?php include 'search.php'; ?>
<?php 
$idAnuncio = isset($_GET['id']) ? (int)$_GET['id'] : 0; // Obtén el ID del anuncio

// Consulta para obtener las fotos del anuncio
$queryFotos = "SELECT Fichero, Alternativo FROM Fotos WHERE Anuncio = ? ORDER BY IdFoto ASC";
$stmtFotos = $conn->prepare($queryFotos);
$stmtFotos->bind_param("i", $idAnuncio);
$stmtFotos->execute();
$resultFotos = $stmtFotos->get_result();

include 'galeria-fotos.php'; 

// Cerrar las conexiones
$stmtFotos->close();
$conn->close();
?>

<?php include 'panel_anuncios.php'; ?>
<?php include 'footer.php'; ?>