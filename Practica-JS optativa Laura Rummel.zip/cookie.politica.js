// Función para aceptar cookies
function aceptarCookies() {
    establecerCookie("cookieConsent", "accepted", 90); // Aceptar cookies por 90 días
    mostrarMensaje("Has aceptado el uso de cookies.");
}

// Función para rechazar cookies
function rechazarCookies() {
    establecerCookie("cookieConsent", "rejected", 90); // Rechazar cookies por 90 días
    mostrarMensaje("Has rechazado el uso de cookies.");
}

// Mostrar mensaje temporal
function mostrarMensaje(mensaje) {
    const mensajeTemp = document.getElementById("mensaje-confirmacion");
    mensajeTemp.innerText = mensaje;
    mensajeTemp.style.display = "block";
    setTimeout(() => mensajeTemp.style.display = "none", 5000); // Mostrar por 5 segundos
}

// Eventos de los botones para aceptar o rechazar cookies
document.getElementById("aceptar-cookies").addEventListener("click", aceptarCookies);
document.getElementById("rechazar-cookies").addEventListener("click", rechazarCookies);
