// Función para mostrar el aviso de cookies si es necesario
function mostrarAvisoCookies() {
  const consentimiento = obtenerCookie("cookieConsent");
  // Solo mostrar el aviso si no se ha dado consentimiento (no existe la cookie)
  if (!consentimiento) {
      document.getElementById("aviso-cookies").style.display = "block";
  }
}

// Función para establecer una cookie con duración en días
function establecerCookie(nombre, valor, dias) {
  const fecha = new Date();
  fecha.setTime(fecha.getTime() + (dias * 24 * 60 * 60 * 1000));
  const expira = "expires=" + fecha.toUTCString();
  document.cookie = `${nombre}=${valor}; ${expira}; path=/`;
}

// Función para obtener el valor de una cookie
function obtenerCookie(nombre) {
  const nombreEQ = nombre + "=";
  const cookies = document.cookie.split(';');
  for (let cookie of cookies) {
      cookie = cookie.trim();
      if (cookie.indexOf(nombreEQ) === 0) {
          return cookie.substring(nombreEQ.length);
      }
  }
  return null;
}

// Función para aplicar el estilo guardado desde la cookie solo si el consentimiento es "accepted"
function aplicarEstiloGuardado() {
  const estiloGuardado = obtenerCookie("estiloSeleccionado");
  const consentimiento = obtenerCookie("cookieConsent");
  const enlaceEstilo = document.getElementById("estilo-pagina");

  if (consentimiento === "accepted" && estiloGuardado) {
      enlaceEstilo.href = estiloGuardado;
      document.getElementById("selector-estilo").value = estiloGuardado;
  } else {
      enlaceEstilo.href = "style2.css"; // Estilo por defecto
  }
}

// Función para cambiar el estilo y guardar si el usuario ha aceptado cookies
function cambiarEstilo(archivoEstilo) {
  const enlaceEstilo = document.getElementById("estilo-pagina");
  enlaceEstilo.href = archivoEstilo;

  const consentimiento = obtenerCookie("cookieConsent");
  if (consentimiento === "accepted") {
      establecerCookie("estiloSeleccionado", archivoEstilo, 45); // Guardar estilo por 45 días
  }
}

// Función para aceptar cookies
function aceptarCookies() {
  establecerCookie("cookieConsent", "accepted", 90); // Guardar decisión de aceptación por 90 días
  document.getElementById("aviso-cookies").style.display = "none"; // Ocultar el aviso
  showTemporaryMessage("Has aceptado el uso de cookies");
}

// Función para rechazar cookies
function rechazarCookies() {
  establecerCookie("cookieConsent", "rejected", 90); // Guardar decisión de rechazo por 90 días
  establecerCookie("estiloSeleccionado", "", -1); // Eliminar la cookie de estilo seleccionado
  document.getElementById("aviso-cookies").style.display = "none"; // Ocultar el aviso
  showTemporaryMessage("Has rechazado el uso de cookies");
}

// Mostrar mensaje temporal
function showTemporaryMessage(mensaje) {
  const mensajeTemp = document.getElementById("mensaje-confirmacion");
  mensajeTemp.innerText = mensaje;
  mensajeTemp.style.display = "block";
  setTimeout(() => mensajeTemp.style.display = "none", 5000); // Mostrar por 5 segundos
}

// Ejecutar al cargar la página
window.onload = () => {
  mostrarAvisoCookies(); // Llamar a la función que muestra el aviso
  aplicarEstiloGuardado(); // Aplicar el estilo guardado si hay consentimiento

  // Escuchar el cambio en el selector de estilo
  const selectorEstilo = document.getElementById("selector-estilo");
  if (selectorEstilo) { // Asegurarse de que el selector exista
      selectorEstilo.addEventListener("change", (evento) => {
          cambiarEstilo(evento.target.value);
      });
  }
};

// Eventos de los botones para aceptar o rechazar cookies
const aceptarButton = document.getElementById("aceptar-cookies");
const rechazarButton = document.getElementById("rechazar-cookies");

if (aceptarButton) {
  aceptarButton.addEventListener("click", aceptarCookies);
}

if (rechazarButton) {
  rechazarButton.addEventListener("click", rechazarCookies);
}
