document.addEventListener('DOMContentLoaded', () => {
    const listaAnuncios = document.getElementById('lista-anuncios');
    const selectOrdenar = document.getElementById('ordenar');

    selectOrdenar.addEventListener('change', () => {
        const orden = selectOrdenar.value;
        const anuncios = Array.from(listaAnuncios.children);

        // Ordenar según el criterio seleccionado
        anuncios.sort((a, b) => {
            const tituloA = a.dataset.titulo.toLowerCase();
            const tituloB = b.dataset.titulo.toLowerCase();
            const fechaA = new Date(a.dataset.fecha);
            const fechaB = new Date(b.dataset.fecha);
            const ciudadA = a.dataset.ciudad.toLowerCase();
            const ciudadB = b.dataset.ciudad.toLowerCase();
            const paisA = a.dataset.pais.toLowerCase();
            const paisB = b.dataset.pais.toLowerCase();
            const precioA = parseFloat(a.dataset.precio);
            const precioB = parseFloat(b.dataset.precio);

            switch (orden) {
                case 'titulo-asc':
                    return tituloA.localeCompare(tituloB);
                case 'titulo-desc':
                    return tituloB.localeCompare(tituloA);
                case 'fecha-asc':
                    return fechaA - fechaB;
                case 'fecha-desc':
                    return fechaB - fechaA;
                case 'ciudad-asc':
                    return ciudadA.localeCompare(ciudadB);
                case 'ciudad-desc':
                    return ciudadB.localeCompare(ciudadA);
                case 'pais-asc':
                    return paisA.localeCompare(paisB);
                case 'pais-desc':
                    return paisB.localeCompare(paisA);
                case 'precio-asc':
                    return precioA - precioB;
                case 'precio-desc':
                    return precioB - precioA;
                default:
                    return 0;
            }
        });

        // Eliminar los elementos existentes uno por uno
        while (listaAnuncios.firstChild) {
            listaAnuncios.removeChild(listaAnuncios.firstChild);
        }

        // Agregar los anuncios ordenados de nuevo al DOM
        anuncios.forEach(anuncio => listaAnuncios.appendChild(anuncio));
    });
});
