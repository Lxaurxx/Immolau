// Función para cambiar el estilo de la página y guardar la selección en una cookie
function cambiarEstilo(archivoEstilo) {
    const enlaceEstilo = document.getElementById("estilo-pagina");
    enlaceEstilo.href = archivoEstilo;

    const consentimiento = obtenerCookie("cookieConsent"); // Obtener el consentimiento de cookies
    if (consentimiento === "accepted") {
        establecerCookie("estiloSeleccionado", archivoEstilo, 45); // Guardar en cookie por 45 días
    }
}

// Función para establecer una cookie con duración en días
function establecerCookie(nombre, valor, dias) {
    const fecha = new Date();
    fecha.setTime(fecha.getTime() + (dias * 24 * 60 * 60 * 1000));
    const expira = "expires=" + fecha.toUTCString();
    document.cookie = `${nombre}=${valor}; ${expira}; path=/`;
}

// Función para obtener el valor de una cookie
function obtenerCookie(nombre) {
    const nombreEQ = nombre + "=";
    const cookies = document.cookie.split(';');
    for (let cookie of cookies) {
        cookie = cookie.trim();
        if (cookie.indexOf(nombreEQ) === 0) {
            return cookie.substring(nombreEQ.length);
        }
    }
    return null;
}

// Al cargar la página, verificar si existe una cookie de estilo seleccionado
window.onload = () => {
    const estiloGuardado = obtenerCookie("estiloSeleccionado");
    const selectorEstilo = document.getElementById("selector-estilo");

    // Si existe un estilo guardado en la cookie, aplicarlo solo si las cookies han sido aceptadas
    const consentimiento = obtenerCookie("cookieConsent");
    if (estiloGuardado && consentimiento === "accepted") {
        cambiarEstilo(estiloGuardado);
        selectorEstilo.value = estiloGuardado;
    }

    // Event listener para cambiar el estilo cuando el usuario selecciona uno nuevo
    selectorEstilo.addEventListener("change", (event) => {
        cambiarEstilo(event.target.value);
    });
};
