document.addEventListener("DOMContentLoaded", function() {
    // Validación del formulario de registro
    document.getElementById("registerForm").addEventListener("submit", function(event) {
        // Limpiar mensajes de error previos y estilos
        const campos = ['username', 'password', 'password2', 'email', 'birthdate', 'sexo'];
        campos.forEach(campo => {
            document.getElementById(campo).classList.remove('input-error');
            document.querySelector(`label[for="${campo}"]`).classList.remove('label-error');
        });
        document.querySelectorAll('.mensaje-error').forEach(function(errorMsg) {
            errorMsg.textContent = '';
        });

        let isValid = true;

        // Obtener valores de los campos
        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value.trim();
        const password2 = document.getElementById("password2").value.trim();
        const email = document.getElementById("email").value.trim();
        const birthdate = document.getElementById("birthdate").value;
        const sexo = document.getElementById("sexo").value;

        // Validación de nombre de usuario
        const usernameRegex = /^[A-Za-z][A-Za-z0-9]{2,14}$/;
        if (!usernameRegex.test(username)) {
            document.getElementById('error-username').textContent = 'El nombre de usuario debe contener entre 3 y 15 caracteres, y solo puede contener letras y números, sin comenzar con un número.';
            document.getElementById('username').classList.add('input-error');
            document.querySelector('label[for="username"]').classList.add('label-error');
            isValid = false;
        }

        // Validación de la contraseña
        const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d-_]{6,15}$/;
        if (!passwordRegex.test(password)) {
            document.getElementById('error-password').textContent = 'La contraseña debe contener entre 6 y 15 caracteres, y debe tener al menos una letra mayúscula, una letra minúscula, y un número. Solo se permiten letras, números, guion y guion bajo.';
            document.getElementById('password').classList.add('input-error');
            document.querySelector('label[for="password"]').classList.add('label-error');
            isValid = false;
        }

        // Verificar si las contraseñas coinciden
        if (password !== password2) {
            document.getElementById('error-password2').textContent = 'Las contraseñas no coinciden';
            document.getElementById('password2').classList.add('input-error');
            document.querySelector('label[for="password2"]').classList.add('label-error');
            isValid = false;
        }

        // Validación del email
        const emailRegex = /^[A-Za-z0-9!#$%&'*+/=?^_`{|}~]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~]+)*@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9]))+$/;
        if (!emailRegex.test(email) || email.length > 254) {
            document.getElementById('error-email').textContent = 'El correo electrónico no es válido. Formato (example@example.com)';
            document.getElementById('email').classList.add('input-error');
            document.querySelector('label[for="email"]').classList.add('label-error');
            isValid = false;
        }

        // Validación de la fecha de nacimiento
        function validarFormatoFecha(birthdate) {
            const partes = birthdate.split('/');
            if (partes.length !== 3) return false;
        
            const [year, month, day] = partes.map(Number);
            const diasPorMes = [31, (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
            return !(isNaN(year) || year.toString().length !== 4 || year <= 0 || isNaN(month) || month < 1 || month > 12 || isNaN(day) || day < 1 || day > diasPorMes[month - 1]);
        }

        function validarMayorEdad(birthdate) {
            const [year, month, day] = birthdate.split('/').map(Number);
            const birthDate = new Date(year, month - 1, day);
            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();

            const monthDiff = today.getMonth() - birthDate.getMonth();
            const dayDiff = today.getDate() - birthDate.getDate();
            if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) age--;

            return age >= 18;
        }

        if (!validarFormatoFecha(birthdate)) {
            document.getElementById('error-birthdate').textContent = 'Formato de fecha no válido. Debe ser YYYY/MM/DD';
            document.getElementById('birthdate').classList.add('input-error');
            document.querySelector('label[for="birthdate"]').classList.add('label-error');
            isValid = false;
        } else if (!validarMayorEdad(birthdate)) {
            document.getElementById('error-birthdate').textContent = 'Debes ser mayor de 18 años para registrarte';
            document.getElementById('birthdate').classList.add('input-error');
            document.querySelector('label[for="birthdate"]').classList.add('label-error');
            isValid = false;
        }

        // Validación del sexo (debe ser seleccionado)
        if (sexo === "") {
            document.getElementById('error-sexo').textContent = 'Debes seleccionar un valor';
            document.querySelector('label[for="sexo"]').classList.add('label-error');
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault();
        }
    });
});

document.getElementById('loginForm').addEventListener('submit', function(event) {
    const usuario = document.getElementById('usuario').value;
    const contra = document.getElementById('contra').value;

    // Expresión regular para evitar espacios o tabulaciones en blanco
    const regex = /^\S.*\S$|^\S{1}$/;

    // Validamos que ambos campos cumplan con la expresión regular
    if (!regex.test(usuario) || !regex.test(contra)) {
        document.getElementById('error-login').textContent = 'Por favor, rellena ambos campos correctamente';
        document.getElementById('usuario').classList.add('input-error');
        document.getElementById('contra').classList.add('input-error');
        event.preventDefault();  // Evita el envío del formulario
    } else {
        document.getElementById('usuario').classList.remove('input-error');
        document.getElementById('contra').classList.remove('input-error');
        document.getElementById('error-login').textContent = ''; // Limpia el mensaje de error
    }
});

