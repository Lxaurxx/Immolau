<?php
include 'head.php';
include 'header2.php';

// Simulamos los anuncios disponibles
$anuncios = [
    1 => 'Casa en la playa',
    2 => 'Casa de los años 90',
    3 => 'Casa rural'
];

// Obtenemos el ID del anuncio desde la URL, si existe
$idAnuncioSeleccionado = isset($_GET['id']) ? (int) $_GET['id'] : 0;

?>

<main>
<?php include 'search.php'; ?>
<h1 class="titulospaginas3">Añadir foto a anuncio</h1>

<form action="perfil.php" method="post" enctype="multipart/form-data" class="formulario-centrado">
    <!-- Campo de selección de anuncio -->
    <label for="anuncio">Anuncio:</label><br>

    <?php if ($idAnuncioSeleccionado && isset($anuncios[$idAnuncioSeleccionado])): ?>
        <!-- Si tenemos un ID en la URL, mostramos el anuncio preseleccionado y desactivado -->
        <select id="anuncio" name="anuncio" disabled>
            <option value="<?php echo $idAnuncioSeleccionado; ?>">
                <?php echo htmlspecialchars($anuncios[$idAnuncioSeleccionado]); ?>
            </option>
        </select>
        <!-- Guardamos el anuncio seleccionado en un campo oculto para enviar con el formulario -->
        <input type="hidden" name="anuncio" value="<?php echo $idAnuncioSeleccionado; ?>">

    <?php else: ?>
        <!-- Si no tenemos un ID en la URL, mostramos una lista desplegable para seleccionar el anuncio -->
        <select id="anuncio" name="anuncio">
            <option value="">Seleccione un anuncio</option>
            <?php foreach ($anuncios as $id => $nombreAnuncio): ?>
                <option value="<?php echo $id; ?>"><?php echo htmlspecialchars($nombreAnuncio); ?></option>
            <?php endforeach; ?>
        </select>
    <?php endif; ?>

    <br><br>

    <!-- Campo de selección de foto -->
    <label for="foto">Foto:</label><br>
    <input type="file" id="foto" name="foto" accept="image/*"><br><br>


    <!-- Campo para el título de la foto -->
    <label for="titulo">Título de la foto:</label><br>
    <input type="text" id="titulo" name="titulo"><br><br>

    <!-- Campo para el texto alternativo de la foto -->
    <label for="alt_text">Texto alternativo:</label><br>
    <input type="text" id="alt_text" name="alt_text"><br><br>



    <!-- Botón para enviar el formulario -->
    <input type="submit" value="Añadir Foto">
</form>
</main>

<?php include 'footer.php'; ?>
