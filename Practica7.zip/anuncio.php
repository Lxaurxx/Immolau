<!-- 
 Página detalle de un anuncio
-->
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
<?php include 'search.php'; ?>
<div class="anuncio">
    <h1 class="titulospaginas3"> Detalle del Anuncio</h1>

    <?php
    // Captura el parámetro 'id' de la URL
    $idAnuncio = isset($_GET['id']) ? (int)$_GET['id'] : 1; // Si no existe 'id', usa 1 por defecto

    // Anuncios estáticos
    if ($idAnuncio % 2 == 0) {
        // Anuncio con id par
        echo "<h2>Tipo de Anuncio: Venta</h2>";
        echo "<h3>Tipo de Vivienda: Obra nueva</h3>";
        echo "<div><img src='https://a0.muscache.com/im/pictures/miso/Hosting-1202324852808538864/original/9e950c39-fc3d-497c-80f0-6fb83bcaa69c.jpeg?im_w=1200' alt='Foto Principal del Anuncio' width='600'></div>";
        echo "<h2>Precioso chalet Sierra Madrid</h2>";
        echo "<p>Precioso chalet a estrenar en una ubicación inmejorable dentro de Becerril de la Sierra...</p>";
        echo "<p><strong>Fecha:</strong> 20 de Septiembre de 2024</p>";
        echo "<p><strong>Ciudad:</strong> Madrid</p>";
        echo "<p><strong>País:</strong> España</p>";
        echo "<p><strong>Precio:</strong> 350,000 €</p>";
        echo "<h3>Características:</h3><ul><li>4 Habitaciones</li><li>3 Cuartos de baño</li><li>Cocina Equipada</li><li>Aire Acondicionado</li><li>3 Televisores</li><li>Piscina</li><li>Barbacoa</li></ul>";
        echo "<h3>Galería de Fotos:</h3>";
        echo "<div><img src='https://a0.muscache.com/im/pictures/hosting/Hosting-U3RheVN1cHBseUxpc3Rpbmc6MTIwMjMyNDg1MjgwODUzODg2NA%3D%3D/original/c9bf021c-10c6-4784-9346-8fdd374d0813.jpeg?im_w=1200' alt='Miniatura 1' width='250'>";
        echo "<img src='https://a0.muscache.com/im/pictures/hosting/Hosting-U3RheVN1cHBseUxpc3Rpbmc6MTIwMjMyNDg1MjgwODUzODg2NA%3D%3D/original/20dfa10d-75ed-4152-8174-183c3387187b.jpeg?im_w=1440' alt='Miniatura 2' width='250'>";
        echo "<img src='https://a0.muscache.com/im/pictures/hosting/Hosting-1202324852808538864/original/2941f86a-b053-4907-9891-3b20cb4295dd.jpeg?im_w=1440' alt='Miniatura 3' width='250'>";
        echo "<img src='https://a0.muscache.com/im/pictures/hosting/Hosting-U3RheVN1cHBseUxpc3Rpbmc6MTIwMjMyNDg1MjgwODUzODg2NA%3D%3D/original/3b058c1a-b659-4762-8e97-04501bdd392a.jpeg?im_w=1440' alt='Miniatura 4' width='250'></div>";
    } else {
        // Anuncio con id impar
        echo "<h2>Tipo de Anuncio: Alquiler</h2>";
        echo "<h3>Tipo de Vivienda: Vivienda</h3>";
        echo "<div><img src='https://spainestate.com/img/alquiler-a-largo-plazo-apartamento-piso-alicante-centro_55074_lgx.jpg' alt='Foto Principal del Anuncio' width='600'></div>";
        echo "<h2>Apartamento en el centro de Barcelona</h2>";
        echo "<p>Hermoso apartamento en el centro de Barcelona, con todo a mano: tiendas, restaurantes y transportes...</p>";
        echo "<p><strong>Fecha:</strong> 5 de Octubre de 2024</p>";
        echo "<p><strong>Ciudad:</strong> Barcelona</p>";
        echo "<p><strong>País:</strong> España</p>";
        echo "<p><strong>Precio:</strong> 1,200 €/mes</p>";
        echo "<h3>Características:</h3><ul><li>2 Habitaciones</li><li>1 Cuarto de baño</li><li>Cocina equipada</li><li>Ascensor</li><li>Wi-Fi</li></ul>";
        echo "<h3>Galería de Fotos:</h3>";
        echo "<div><img src='https://a0.muscache.com/im/pictures/hosting/Hosting-U3RheVN1cHBseUxpc3Rpbmc6MTIwMjMyNDg1MjgwODUzODg2NA%3D%3D/original/c9bf021c-10c6-4784-9346-8fdd374d0813.jpeg?im_w=1200' alt='Miniatura 1' width='250'>";
        echo "<img src='https://a0.muscache.com/im/pictures/hosting/Hosting-U3RheVN1cHBseUxpc3Rpbmc6MTIwMjMyNDg1MjgwODUzODg2NA%3D%3D/original/20dfa10d-75ed-4152-8174-183c3387187b.jpeg?im_w=1440' alt='Miniatura 2' width='250'>";
        echo "<img src='https://a0.muscache.com/im/pictures/hosting/Hosting-1202324852808538864/original/2941f86a-b053-4907-9891-3b20cb4295dd.jpeg?im_w=1440' alt='Miniatura 3' width='250'>";
        echo "<img src='https://a0.muscache.com/im/pictures/hosting/Hosting-U3RheVN1cHBseUxpc3Rpbmc6MTIwMjMyNDg1MjgwODUzODg2NA%3D%3D/original/3b058c1a-b659-4762-8e97-04501bdd392a.jpeg?im_w=1440' alt='Miniatura 4' width='250'></div>";
    }
    ?>

    <h2><a href="mensaje.php" > Enviar mensaje a propietario </a></h2>
</div>
<?php include 'footer.php'; ?>