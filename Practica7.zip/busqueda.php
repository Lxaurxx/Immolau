<!-- 
 Página formulario de búsqueda
-->
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
<?php include 'search.php'; ?>


    <h2 class="titulospaginas3">Búsqueda de Anuncios 🔎</h2>
    
   <!--  <form action="/buscar" method="get"> Todavia no-->
    <form action="resultadobusqueda.php" method="get" enctype="multipart/form-data" class="formulario-centrado">
        
        <!-- Tipo de anuncio (venta o alquiler) -->
        <label for="tipo-anuncio">Tipo de anuncio:</label><br>
        <select id="tipo-anuncio" name="tipo-anuncio">
            <option value="">Seleccione</option>
            <option value="venta">Venta</option>
            <option value="alquiler">Alquiler</option>
        </select><br><br>

        <!-- Tipo de vivienda -->
        <label for="tipo-vivienda">Tipo de vivienda:</label><br>
        <select id="tipo-vivienda" name="tipo-vivienda">
            <option value="">Seleccione</option>
            <option value="obra nueva">Obra nueva</option>
            <option value="vivienda">Vivienda</option>
            <option value="oficina">Oficina</option>
            <option value="local">Local</option>
            <option value="garaje">Garaje</option>
        </select><br><br>

        <!-- Ciudad -->
        <label for="ciudad">Ciudad:</label><br>
        <input type="text" id="ciudad" name="ciudad"><br><br>

        <!-- País -->
        <label for="pais">País:</label><br>
        <select id="pais" name="pais">
            <option value="">Seleccione su país</option>
            <option value="argentina">Argentina</option>
            <option value="brasil">Brasil</option>
            <option value="chile">Chile</option>
            <option value="colombia">Colombia</option>
            <option value="españa">España</option>
            <option value="mexico">México</option>
            <option value="peru">Perú</option>
            <option value="uruguay">Uruguay</option>
            <option value="venezuela">Venezuela</option>
        </select><br><br>

        <!-- Precio de la vivienda -->
        <label for="precio">Precio máximo:</label><br>
        <input type="number" id="precio" name="precio" min="1" step="1" placeholder="Ingrese el precio máximo"><br><br>

        <!-- Fecha de publicación del anuncio -->
        <label for="fecha-publicacion">Fecha de publicación del anuncio:</label><br>
        <input type="date" id="fecha-publicacion" name="fecha-publicacion"><br><br>

        <!-- Botón de búsqueda -->
        <input type="submit" value="Buscar">

    </form>
<?php include 'footer.php'; ?>
