<?php
// Lista de usuarios permitidos (usuario => contraseña)
$usuarios_validos = [
    "pablo" => "pablo",
    "laura" => "laura",
    "usuario3" => "contraseña3",
    "usuario4" => "contraseña4"
];

// Comprobación de los datos del formulario
$usuario = isset($_GET['usuario']) ? trim($_GET['usuario']) : ''; // Remueve espacios extra
$contraseña = isset($_GET['contra']) ? trim($_GET['contra']) : ''; // Remueve espacios extra

// Verifica si los campos no están vacíos
if ($usuario === '' || $contraseña === '') {
    header("Location: index.php?error=1");
    exit;
}

// Verificar si el usuario y la contraseña son válidos
if (array_key_exists($usuario, $usuarios_validos) && $usuarios_validos[$usuario] === $contraseña) {
    // Redirigir a la página privada si el usuario es válido
    header("Location: perfil.php");
    exit;
} else {
    // Redirigir a la página principal con un mensaje de error si los datos no son válidos
    header("Location: index.php?error=Usuario o contraseña incorrectos");
    exit;
}
?>
