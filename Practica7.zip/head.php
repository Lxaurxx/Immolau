<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <title>Pictures España</title>
    <link rel="stylesheet" href="style2.css" media="screen">
    <link rel="alternate stylesheet" href="modo-noche.css" title="Modo Noche">
    <link rel="alternate stylesheet" href="alto-contraste.css" title="Alto Contraste">
    <link rel="alternate stylesheet" href="texto-grande.css" title="Texto Grande">
    <link rel="alternate stylesheet" href="textoycontraste.css" title="Texto Grande y Alto Contraste">
    <link rel="stylesheet" href="print.css" media="print">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>