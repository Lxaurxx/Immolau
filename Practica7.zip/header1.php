<!-- header.php -->
<body>
    <header>
        <a href="index.php">
            <h1><img class="titulo" src="logo.png" width="100" height="100">Pictures &amp; Images</h1>
        </a>
        <div class="login">
            <form id="loginForm" action="control_acceso.php" method="get">
            <label for="usuario">Usuario:</label>
             <input type="text" id="usuario" name="usuario">
           <label for="contra">Contraseña:</label>
         <input type="password" id="contra" name="contra">
         <input type="submit" id="submitBtn" value="Entrar">
         <span class="mensaje-error-login" id="error-login"></span>
</form>
        </div>
        <nav>
            <ul>
                <li><a href="index.php"><i class="fa fa-home"></i>Inicio</a></li>
                <li><a href="registro.php"><i class="fa fa-pencil"></i>Regístrate</a></li>
            </ul>
        </nav>
    </header>
