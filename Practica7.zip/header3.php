<body>
    <header>
     <a href="index2.php"> <h1><img src="logo.png" width="100" height="100">Pictures &amp; Images</h1></a>
     <nav>
<p class="bienvenido">Bienvenido Pedro García</p>
    <ul>
    <li><a href="index2.php"><i class="fa fa-home"></i>Inicio</a></li> 
    <li><a href="error-genérico.php"><i class="fa-solid fa-pen-to-square"></i>Modificar datos</a></li> 
    <li><a href="error-genérico.php"><i class="fa-regular fa-rectangle-xmark"></i>Darse de baja</a></li> 
    <li><a href="crear-anuncio.php"><i class="fa-solid fa-plus"></i>Crear anuncio</a></li> 
    <li><a href="anadir-foto.php"><i class="fa-solid fa-image"></i>Añadir foto a anuncios</a></li> 
    <li><a href="mis-anuncios.php"><i class="fa fa-list"></i>Mis anuncios</a></li> 
    <li><a href="mismensajes.php"><i class="fa fa-message"></i>Mis mensajes</a></li> 
    <li><a href="solicitarfolleto.php"><i class="fa fa-star"></i>Solicitar folleto</a></li> 
    <li><a href="index.php"><i class="fa fa-x"></i>Salir </a> </li>  
    </ul>
    </nav>
       </header>