
<!-- index.php -->
<?php include 'head.php'; ?>
<?php include 'header1.php'; ?>

<main>
<?php include 'search.php'; ?>
    </div>
    <h2 class="titulospaginas3">Últimos anuncios</h2>
    <?php
    // Verificar si existe el parámetro de error en la URL
    if (isset($_GET['error']) && $_GET['error'] == "Usuario o contraseña incorrectos") {
        echo "<p style='color: red;'>Error: Usuario o contraseña incorrectos. Inténtalo de nuevo.</p>";
    }
    ?>
    <a href="errorbusqueda.php"> 
    <div class="ultimosanuncios">
        <div class="ultimosanuncios">
            <img src="https://st3.idealista.com/news/archivos/styles/fullwidth_xl/public/2020-10/2_1.jpg?VersionId=CHid9TpdZkPMV4HUVXZ2QwrE9.4V_Lli&itok=nt_uogB4" width="200" alt="Imagen de una villa grande en Alicante"> 
            <figcaption>Una villa enorme - 12/04/2024 - Alicante, España - 300€ noche</figcaption>
        </div>
        <div class="ultimosanuncios">
            <img src="https://www.letsbookhotel.com/img/max300/596/5963358.jpg" width="200" alt="Imagen de apartamento en Madrid">
            <figcaption>Un apartamento - 20/08/2024 - Madrid, España - 350.000€</figcaption>
        </div>
        <div class="ultimosanuncios">
            <img src="https://www.ruralesdata.com/cache/alojamientos/aguirre-casa-rural/202-aguirre-casa-rural-elizondo-fachada.jpg" width="200" alt="Imagen de una casa rural en Murcia">
            <figcaption>Una Casa rural - 29/07/2024 - Murcia, España - 215€ noche</figcaption>
        </div>
        <div class="ultimosanuncios">
            <img src="https://img.holidu.com/images/04154f1a-2601-43b9-830c-21adb0d60b11/t.jpg" width="200" alt="Imagen de un apartamento a pie de playa en Salou, Tarragona">
            <figcaption>Apartamento veraniego - 05/09/2024 - Salou, Tarragona, España - 220.000€</figcaption>
        </div>
        <div class="ultimosanuncios">
            <img src="https://content.arquitecturaydiseno.es/medio/2021/08/23/casa-moderna-en-los-bosques-de-canada-5e022697-1500x1080_58fa7c01_1500x1080.jpeg" width="200" alt="Imagen de una casa en la montaña en Teruel">
            <figcaption>Casa de montaña - 01/05/2024 - Teruel, España - 132€ noche</figcaption>
        </div>
    </div></a>
</main>

<?php include 'footer.php'; ?>
