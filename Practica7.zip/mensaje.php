<!-- 
Página mensaje a propietario
-->
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
<?php include 'search.php'; ?>
    <h2 class="titulospaginas3">Enviar Mensaje al Anunciante</h2>
    
    <form action="respuestamensaje.php" method="get" enctype="multipart/form-data" class="formulario-centrado">

        <label for="tipo">Tipo de mensaje:</label><br>
        <select id="tipo" name="tipo">
            <option value="">Seleccione el tipo de mensaje</option>
            <option value="consulta">Consulta privada</option>
            <option value="dudas">Dudas</option>
            <option value="ayuda">Ayuda</option>
            <option value="otro">Otro</option>
        </select>
        <br><br>

        <label for="asunto">Asunto:</label><br>
        <input type="text" id="asunto" name="asunto"><br><br>

        <label for="mensaje">Mensaje:</label><br>
        <textarea id="mensaje" name="mensaje" rows="5" cols="40"></textarea><br><br>

        <input type="submit" value="Enviar Mensaje">
    </form>
<?php include 'footer.php'; ?>

