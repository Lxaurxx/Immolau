<?php
// Simulación de anuncios del usuario
$anuncios = [
    [
        "titulo" => "Chalet en la montaña",
        "ciudad" => "Barcelona",
        "pais" => "España",
        "precio" => "250,000€",
        "foto" => "https://i.pinimg.com/736x/24/23/3e/24233e4a87d1be9df8aec8d3181b010b.jpg",
    ],
    [
        "titulo" => "Apartamento en el centro",
        "ciudad" => "Madrid",
        "pais" => "España",
        "precio" => "320,000€",
        "foto" => "https://lh6.googleusercontent.com/proxy/nm-9fJz0inlSlpGavGu7_awUT2Uai2_FDbrj12_U4TJRrBRTyVKpzJGL0GaSZAAg6ENIB7t0D5bFMEGt6V95LOXg_-F1EwvbZGNqeQXqeUHvCxRH58SQHqrCYA_eN6heEJWcsZ7H",
    ],
    [
        "titulo" => "Casa en la playa",
        "ciudad" => "Valencia",
        "pais" => "España",
        "precio" => "450,000€",
        "foto" => "https://www.fotocasa.es/fotocasa-life/wp-content/uploads/2020/08/casa-campo-de-cuento.png",
    ]
];
?>
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<main>
<?php include 'search.php'; ?>
<h1 class="titulospaginas3">Mis anuncios</h1>

<div class="ultimosanuncios">
    <a href="ver-anuncio.php?id=1"> <!-- Identificador único para cada anuncio -->
        <div class="misanuncios">
            <img src="https://i.pinimg.com/736x/24/23/3e/24233e4a87d1be9df8aec8d3181b010b.jpg" width="200" alt="Imagen de una villa grande en Alicante"> 
            <figcaption>Casa en la playa - 12/04/2024 - Alicante, España - 450,000€</figcaption>
        </div>
    </a>
    <a href="ver-anuncio.php?id=2">
        <div class="misanuncios">
            <img src="https://img.freepik.com/foto-gratis/casa-aislada-campo_1303-23773.jpg" width="200" alt="Imagen de apartamento en Madrid">
            <figcaption>Una casa de los años 90 - 20/08/2024 - Madrid, España - 350.000€</figcaption>
        </div>
    </a>
    <a href="ver-anuncio.php?id=3">
        <div class="misanuncios">
            <img src="https://www.fotocasa.es/fotocasa-life/wp-content/uploads/2020/08/casa-campo-de-cuento.png" width="200" alt="Imagen de una casa rural en Murcia">
            <figcaption>Una Casa rural - 29/07/2024 - Murcia, España - 220.000€</figcaption>
        </div>
    </a>
</div>
</main>

<?php include 'footer.php'; ?>