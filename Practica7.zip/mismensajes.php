<!-- 
 Página mis mensajes
-->
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
<?php include 'search.php'; ?>

        <h1 class="conBorde">Mensajes enviados</h1>

            <p><strong>Tipo:</strong> Consulta privada</p>
            <p><strong>Texto:</strong> Hola, estoy interesado en el departamento que tienes en alquiler en el centro. ¿Podrías enviarme más detalles?</p>
            <p><strong>Fecha:</strong> 29/09/2024</p>
            <p><strong>Receptor:</strong> Juan Pérez</p>
            <hr> <!-- inserta una linea horizontal-->
    
            <p><strong>Tipo:</strong> Dudas</p>
            <p><strong>Texto:</strong> Hola María, la casa estará disponible para visitas este fin de semana. ¿Te viene bien el sábado por la mañana?</p>
            <p><strong>Fecha:</strong> 02/10/2024</p>
            <p><strong>Receptor:</strong> María Fernández</p>

        <h1 class="conBorde">Mensajes recibidos</h1>

            <p><strong>Tipo:</strong> Consulta privada</p>
            <p><strong>Texto:</strong> Claro, el departamento está ubicado en la calle Mayor y tiene 2 habitaciones. El precio es de 750€/mes. ¿Te gustaría agendar una visita?</p>
            <p><strong>Fecha:</strong> 01/10/2024</p>
            <p><strong>Emisor:</strong> Juan Pérez</p>
            <hr>
    
            <p><strong>Tipo:</strong> Otros</p>
            <p><strong>Texto:</strong> ¡Qué bien! ¿Tienes planes para hoy?</p>
            <p><strong>Fecha:</strong> 03/10/2024</p>
            <p><strong>Emisor:</strong> Sara González</p>
            <hr>
    
            <?php include 'footer.php'; ?>

   
