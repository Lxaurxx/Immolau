<!-- 
 Página formulario de registro
-->
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
<?php include 'search.php'; ?>

    <h2 class="titulospaginas3"> Registro de Nuevo Usuario ✅</h2>


<form action="respuestaregistro.php" id="registerForm" method="post" enctype="multipart/form-data" class="formulario-centrado">
    <!-- Campos del formulario con valores anteriores -->
    <label for="username"><i class="fa fa-user"></i> Nombre de usuario:</label><br>
    <input type="text" id="username" name="username" value="<?php echo isset($_GET['username']) ? htmlspecialchars($_GET['username']) : ''; ?>">
    <span class="mensaje-error" id="error-username"><?php echo isset($_GET['error_username']) ? $_GET['error_username'] : ''; ?></span><br><br>

    <label for="email"><i class="fa fa-envelope"></i> Correo electrónico:</label><br>
    <input type="text" id="email" name="email" value="<?php echo isset($_GET['email']) ? htmlspecialchars($_GET['email']) : ''; ?>">
    <span class="mensaje-error" id="error-email"><?php echo isset($_GET['error_email']) ? $_GET['error_email'] : ''; ?></span><br><br>

    <label for="password"><i class="fa fa-lock"></i> Contraseña:</label><br>
    <input type="password" id="password" name="password">
    <span class="mensaje-error" id="error-password"><?php echo isset($_GET['error_password']) ? $_GET['error_password'] : ''; ?></span><br><br>

    <label for="password2"><i class="fa fa-lock"></i> Repetir contraseña:</label><br>
    <input type="password" id="password2" name="password2">
    <span class="mensaje-error" id="error-password2"><?php echo isset($_GET['error_password2']) ? $_GET['error_password2'] : ''; ?></span><br><br>

        <label for="birthdate"><i class="fa fa-calendar"></i> Fecha de nacimiento (YYYY/MM/DD):</label><br>
        <input type="text" id="birthdate" name="birthdate">
        <span class="mensaje-error" id="error-birthdate"></span><br><br>

        <label for="sexo"><i class="fa fa-venus-mars"></i> Sexo:</label>
        <select id="sexo" name="sexo">
            <option value="">Seleccione su sexo</option>
            <option value="masculino">Masculino</option>
            <option value="femenino">Femenino</option>
            <option value="otro">Otro</option>
            <option value="prefiero_no_decirlo">Prefiero no decirlo</option>
        </select><span class="mensaje-error" id="error-sexo"></span>
        <br><br>

        <label for="city"><i class="fa fa-city"></i> Ciudad:</label><br>
        <input type="text" id="city" name="city"><br><br>

        <label for="pais"><i class="fa fa-flag"></i> País de Residencia:</label><br>
        <select id="pais" name="pais">
            <option value="">Seleccione su país</option>
            <option value="argentina">Argentina</option>
            <option value="brasil">Brasil</option>
            <option value="chile">Chile</option>
            <option value="colombia">Colombia</option>
            <option value="españa">España</option>
            <option value="mexico">México</option>
            <option value="peru">Perú</option>
            <option value="uruguay">Uruguay</option>
            <option value="venezuela">Venezuela</option>
        </select>
        <br><br>

        <label for="photo"><i class="fa fa-image"></i> Foto de perfil:</label><br>
        <input type="file" id="photo" name="photo" accept="image/*"><br><br>

        <input type="submit" value="Registrarse">
    </form>

    <?php include 'footer.php'; ?>

