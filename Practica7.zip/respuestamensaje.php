<?php
// Comprobamos si se han recibido los datos a través de GET
if (isset($_GET['tipo'], $_GET['asunto'], $_GET['mensaje'])) {
    // Recogemos los datos del formulario y aplicamos trim() para eliminar espacios en blanco al principio y al final
    $tipo = trim($_GET['tipo']);
    $asunto = trim($_GET['asunto']);
    $mensaje = trim($_GET['mensaje']);

    // Comprobamos si los campos están vacíos después de aplicar trim()
    if (empty($tipo) || empty($asunto) || empty($mensaje)) {
        // Si alguno de los campos está vacío después de eliminar los espacios en blanco, redirigimos con un error
        header("Location: mensaje.php?error=1");
        exit;
    }

    // Se define el destinatario (puede ser estático o dinámico, según lo necesites)
    $destinatario = "Maria López Fernández";  // Ejemplo estático

    // Fecha del envío (puedes generar la fecha actual)
    $fechaEnvio = date('d/m/Y');
} else {
    // Si faltan datos importantes, redirigimos con un error
    header("Location: mensaje.php?error=1");
    exit;
}
?>

<!-- 
Página respuesta mensaje a propietario
-->
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
<?php include 'search.php'; ?>

    <form action="anuncio.php" method="get" enctype="multipart/form-data">
     <h1 class="conBorde">Tu mensaje ha sido enviado correctamente</h1>
    
     <h2>Detalles del Mensaje</h2>
     <p><strong>Destinatario:</strong> <?php echo $destinatario; ?></p>
     <p><strong>Tipo de mensaje:</strong> <?php echo ucfirst($tipo); ?></p>  <!-- ucfirst() para poner la primera letra en mayúscula -->
     <p><strong>Asunto:</strong> <?php echo $asunto; ?></p>
     <p><strong>Mensaje:</strong> <?php echo nl2br($mensaje); ?></p>  <!-- nl2br() para convertir saltos de línea en <br> -->
     <p><strong>Fecha de Envío:</strong> <?php echo $fechaEnvio; ?></p>

    <input type="submit" value="Entendido">
</form>
<?php include 'footer.php'; ?>
