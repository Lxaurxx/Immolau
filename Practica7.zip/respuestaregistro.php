<?php
// respuestaregistro.php

// Obtener los datos del formulario
$username = trim($_POST['username']);
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$password2 = trim($_POST['password2']);
$birthdate = trim($_POST['birthdate']);
$sexo = trim($_POST['sexo']);
$city = trim($_POST['city']);
$pais = trim($_POST['pais']);

// Validación de errores
$errores = [];
if (empty($username)) {
    $errores['username'] = 'El nombre de usuario es obligatorio.';
}
if (empty($password)) {
    $errores['password'] = 'La contraseña es obligatoria.';
}
if ($password !== $password2) {
    $errores['password2'] = 'Las contraseñas no coinciden.';
}
if (empty($email)) {
    $errores['email'] = 'El correo electrónico es obligatorio.';
}
// Puedes añadir más validaciones aquí, como formato de email o verificación de la fecha de nacimiento

// Si hay errores, redirigir de vuelta al formulario con errores y datos previos
if (!empty($errores)) {
    $query_params = [
        'errores' => implode(' ', $errores),
        'username' => $username,
        'email' => $email,
        'error_username' => $errores['username'] ?? '',
        'error_email' => $errores['email'] ?? '',
        'error_password' => $errores['password'] ?? '',
        'error_password2' => $errores['password2'] ?? ''
    ];

    header("Location: registro.php?" . http_build_query($query_params));
    exit;
}

// Si no hay errores, mostrar confirmación del registro
?>
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
    <h2 class="titulospaginas3">Registro completado</h2>
    <p><strong>Nombre de usuario:</strong> <?php echo htmlspecialchars($username); ?></p>
    <p><strong>Correo electrónico:</strong> <?php echo htmlspecialchars($email); ?></p>
    <p><strong>Fecha de nacimiento:</strong> <?php echo htmlspecialchars($birthdate); ?></p>
    <p><strong>Sexo:</strong> <?php echo htmlspecialchars($sexo); ?></p>
    <p><strong>Ciudad:</strong> <?php echo htmlspecialchars($city); ?></p>
    <p><strong>País:</strong> <?php echo htmlspecialchars($pais); ?></p>
    <p><em>Su registro se ha completado con éxito.</em></p>

    <a href="index.php">Volver a la página principal</a>
</body>

<?php include 'footer.php'; ?>
