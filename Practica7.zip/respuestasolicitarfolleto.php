<!-- 
 Página respuesta solicitar folleto
-->
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
<?php include 'search.php'; ?>

   <div class="titulospaginas3">
    <h2>Confirmación de Solicitud</h2>
    <p>Gracias por tu solicitud. Se ha registrado correctamente tu solicitud de impresión de álbum.</p>
</div>
    <h4>Datos ingresados:</h4>
    <ul>
        <li><strong>Nombre completo:</strong> Luis Müller</li>
        <li><strong>Correo electrónico:</strong> luis.muller@gmail.com</li>
        <li><strong>Texto adicional:</strong> Texto de ejemplo </li>
        <li><strong>Calle:</strong> Calle Federico García Lorca</li>
        <li><strong>Número:</strong> 12</li>
        <li><strong>Piso:</strong> 1</li>
        <li><strong>Puerta:</strong> A</li>
        <li><strong>Código Postal:</strong> 03001</li>
        <li><strong>País:</strong> España</li>
        <li><strong>Provincia:</strong> Alicante</li>
        <li><strong>Localidad:</strong> Alicante</li>
        <li><strong>Teléfono:</strong> 612345678</li>
        <li><strong>Color de portada:</strong> #FF5733</li>
        <li><strong>Número de copias:</strong> 10</li>
        <li><strong>Resolución de fotos:</strong> 300 DPI</li>
        <li><strong>Anuncio seleccionado:</strong> Anuncio 1</li>
        <li><strong>Fecha de recepción:</strong> 12/10/2024</li>
        <li><strong>Impresión a color:</strong> A todo color</li>
        <li><strong>Impresión del precio:</strong> Con precio</li>
    </ul>

    <h4>Coste del folleto publicitario:</h4>
    <p><strong>20,00 €</strong></p>

    <p>Te contactaremos a través del correo electrónico proporcionado para cualquier consulta adicional.</p>

    <form action="perfil.php" method="get">
        <input type="submit" value="Entendido">
    </form>
</body>
<?php include 'footer.php'; ?>

   