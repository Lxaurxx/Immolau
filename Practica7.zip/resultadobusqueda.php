<!-- 
 Página resultados de la búsqueda
-->
<?php include 'head.php'; ?>
<?php include 'header2.php'; ?>

<body>
<?php include 'search.php'; ?>
<div class="titulospaginas3">
    <h2 class="titulospaginas3">Resultados de Búsqueda</h2>

   <!-- <p>A continuación se muestran los anuncios que coinciden con los criterios de búsqueda:</p> -->


   <?php
// Captura de los datos introducidos por el usuario
$tipoAnuncio = isset($_GET['tipo-anuncio']) ? htmlspecialchars($_GET['tipo-anuncio']) : '';
$tipoVivienda = isset($_GET['tipo-vivienda']) ? htmlspecialchars($_GET['tipo-vivienda']) : '';
$ciudad = isset($_GET['ciudad']) ? htmlspecialchars($_GET['ciudad']) : '';
$pais = isset($_GET['pais']) ? htmlspecialchars($_GET['pais']) : '';
$precio = isset($_GET['precio']) ? htmlspecialchars($_GET['precio']) : '';
$fechaPublicacion = isset($_GET['fecha-publicacion']) ? htmlspecialchars($_GET['fecha-publicacion']) : '';

// Mostrar los criterios de búsqueda introducidos por el usuario
echo "<h3>Criterios de búsqueda seleccionados</h3>";
echo "<p><strong>Tipo de anuncio:</strong> " . ucfirst($tipoAnuncio ?: 'No especificado') . "</p>";
echo "<p><strong>Tipo de vivienda:</strong> " . ucfirst($tipoVivienda ?: 'No especificado') . "</p>";
echo "<p><strong>Ciudad:</strong> " . ucfirst($ciudad ?: 'No especificado') . "</p>";
echo "<p><strong>País:</strong> " . ucfirst($pais ?: 'No especificado') . "</p>";
echo "<p><strong>Precio máximo:</strong> " . ($precio ? ucfirst($precio) . " €" : 'No especificado') . "</p>";
echo "<p><strong>Fecha de publicación:</strong> " . ucfirst($fechaPublicacion ?: 'No especificado') . "</p>";


?>
</div>
    <!-- Listado de resultados de búsqueda -->
    <ul class="formulario-centrado">
        <!-- Primer anuncio con enlace a la página de detalle -->
        
            <img src="https://www.elmueble.com/medio/2023/06/05/516876_00000000_639b4e57_230605105043_900x900.jpg" alt="Foto de la vivienda" width="250"><br>
            <strong>Título:</strong> Hermosa casa en el centro<br>
            <strong>Fecha de publicación:</strong> 21/04/2024<br>
            <strong>Ciudad:</strong> Madrid<br>
            <strong>País:</strong> España<br>
            <strong>Precio:</strong> €350,000<br>
            <a href="anuncio.php">Ver detalles</a>
      
        <br><br>

        <!-- Segundo anuncio con enlace a la página con el mensaje de error -->
       
            <img src="https://cf.bstatic.com/xdata/images/hotel/max1024x768/526339675.jpg?k=cc255a02b33ed84f410c1fdd3d395b1416b0830b46fc209c6d07f5ab3a581473&o=&hp=1" alt="Foto de la vivienda 2" width="250"><br>
            <strong>Título:</strong> Apartamento en zona turística<br>
            <strong>Fecha de publicación:</strong> 07/08/2024<br>
            <strong>Ciudad:</strong> Barcelona<br>
            <strong>País:</strong> España<br>
            <strong>Precio:</strong> €249 noche<br>
            <a href="errorbusqueda.php">Ver detalles</a>
        
        <br><br>
    </ul>
    <?php include 'footer.php'; ?>
