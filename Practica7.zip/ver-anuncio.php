<?php
include 'head.php';
include 'header2.php';

// Simula una base de datos con detalles de anuncios
$anuncios = [
    1 => [
        'tipo' => 'Venta',
        'tipo_vivienda' => 'Casa en la playa',
        'foto' => 'https://i.pinimg.com/736x/24/23/3e/24233e4a87d1be9df8aec8d3181b010b.jpg',
        'titulo' => 'Casa en la playa',
        'precio' => '450,000€',
        'texto' => 'Hermosa casa en la playa de Alicante, ideal para vacaciones familiares.',
        'fecha' => '12/04/2024',
        'ciudad' => 'Alicante',
        'pais' => 'España',
        'caracteristicas' => '3 habitaciones, 2 baños, frente al mar.',
        'miniaturas' => [
            'https://i.pinimg.com/736x/24/23/3e/24233e4a87d1be9df8aec8d3181b010b.jpg',
            'https://img.freepik.com/fotos-premium/angel-hermosa-casa-moderna-garaje_259150-32503.jpg?semt=ais_hybrid',
        ],
    ],
    2 => [
        'tipo' => 'Venta',
        'tipo_vivienda' => 'Casa de los años 90',
        'foto' => 'https://img.freepik.com/foto-gratis/casa-aislada-campo_1303-23773.jpg',
        'titulo' => 'Una casa de los años 90',
        'precio' => '350,000€',
        'texto' => 'Casa en Madrid con estilo de los años 90, en una zona tranquila.',
        'fecha' => '20/08/2024',
        'ciudad' => 'Madrid',
        'pais' => 'España',
        'caracteristicas' => '4 habitaciones, 3 baños, amplio jardín.',
        'miniaturas' => [
            'https://img.freepik.com/foto-gratis/casa-aislada-campo_1303-23773.jpg',
            'https://forbes.es/wp-content/uploads/2021/08/elon-musk-casa.jpeg',
        ],
    ],
    3 => [
        'tipo' => 'Venta',
        'tipo_vivienda' => 'Casa rural',
        'foto' => 'https://www.fotocasa.es/fotocasa-life/wp-content/uploads/2020/08/casa-campo-de-cuento.png',
        'titulo' => 'Una Casa rural',
        'precio' => '220,000€',
        'texto' => 'Casa rural en Murcia, ideal para una vida tranquila y natural.',
        'fecha' => '29/07/2024',
        'ciudad' => 'Murcia',
        'pais' => 'España',
        'caracteristicas' => '2 habitaciones, 1 baño, entorno rural.',
        'miniaturas' => [
            'https://www.fotocasa.es/fotocasa-life/wp-content/uploads/2020/08/casa-campo-de-cuento.png',
            'https://img.freepik.com/fotos-premium/cerca-hermosa-calle-muchas-casas_259150-32501.jpg',
        ],
    ],
];

// Obtén el ID del anuncio desde la URL
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

// Verifica si el anuncio existe
if (isset($anuncios[$id])) {
    $anuncio = $anuncios[$id];
} else {
    echo "Anuncio no encontrado.";
    exit;
}
?>

<main>
<?php include 'search.php'; ?>
<div class="anuncio">
<h1 class="titulospaginas3"><?php echo htmlspecialchars($anuncio['titulo']); ?></h1>


    <img src="<?php echo htmlspecialchars($anuncio['foto']); ?>" alt="Imagen principal del anuncio" width="600">
    <p><strong>Tipo de anuncio:</strong> <?php echo htmlspecialchars($anuncio['tipo']); ?></p>
    <p><strong>Tipo de vivienda:</strong> <?php echo htmlspecialchars($anuncio['tipo_vivienda']); ?></p>
    <p><strong>Precio:</strong> <?php echo htmlspecialchars($anuncio['precio']); ?></p>
    <p><strong>Descripción:</strong> <?php echo htmlspecialchars($anuncio['texto']); ?></p>
    <p><strong>Fecha:</strong> <?php echo htmlspecialchars($anuncio['fecha']); ?></p>
    <p><strong>Ciudad:</strong> <?php echo htmlspecialchars($anuncio['ciudad']); ?></p>
    <p><strong>País:</strong> <?php echo htmlspecialchars($anuncio['pais']); ?></p>
    <p><strong>Características:</strong> <?php echo htmlspecialchars($anuncio['caracteristicas']); ?></p>

    <h3>Fotos adicionales</h3>
    <div class="miniaturas">
        <?php foreach ($anuncio['miniaturas'] as $miniatura) : ?>
            <img src="<?php echo htmlspecialchars($miniatura); ?>" alt="Miniatura" width="250">
        <?php endforeach; ?>
    </div>
    <h2><a href="anadir-foto.php?id=<?php echo $id; ?>">Añadir foto a este anuncio</a></h2>
</div>
</main>

<?php include 'footer.php'; ?>